<?php
//phpinfo();

$purpose ='(1%杜*志;民"杜`伊?宁,a!b^c\\0&1|2|3{4}5)6[7]8.9+';
echo '['.$purpose.']<br>';

$forbiden="/[ ,`'\(\)\"?\\!$%^&*;\|\{\}\[\].]/";
$purpose = preg_replace($forbiden, '_', $purpose);
$purpose = str_replace('\\', '_', $purpose);
$purpose = str_replace('+', '_', $purpose);

echo '['.$purpose.']';
?>

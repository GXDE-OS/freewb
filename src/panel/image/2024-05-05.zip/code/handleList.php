<?php
	include_once "include/cookie.php";
	session_start();
	date_default_timezone_set("PRC");
	$key = 'freeime'.$_SESSION['zy_admin_id'].$_SESSION['zy_station_id'];
	if($_GET['info']==5)
	{//3 days
		echo "<script>setCookie('{$key}',1,4320);</script>";
		$_COOKIE[$key]=1;
	}

	include_once "include/dbtool.php";
	include "GetDiscard.php";
//	if(($_SESSION['zy_user']=='库管员'||$_SESSION['zy_user']=='会计') && (int)$_COOKIE[$key]!=1)
	if(($_SESSION['zy_user']=='库管员') && (int)$_COOKIE[$key]!=1)
	{//提醒做月度盘库
		$month = date('n');
		if( $month==1 )
		{
			$month = 12;
		}
		else
		{
			--$month;
		}
		$checked=getOption('InfoMonthCheck');
		$audit = ($_SESSION['zy_user']=='会计'?1:0);
		if( $month != (int)$checked )
		{
			//if($audit==0)//如果已提醒过库管员，就不再提醒会计
			//	updateOption('InfoMonthCheck',$month);
			$web="handleList.php?info=5&name={$_SESSION['zy_station_name']}&audit={$audit}";
			header("Location:{$web}");
		}
	}
?>
<meta http-equiv="refresh" url="handleList.php" content="600">
<?php
	include_once "head.php";
	include_once "include/const.php";
	if ($_SESSION['zy_admin_id'] == NULL)
	{
		echo "<script language=\"JavaScript\">window.location.href='../index.php';</script>";
	}
?>
<style>
h2{font:16px/1 Tahoma,Helvetica,Arial,"\5b8b\4f53",sans-serif;}
.barcode{left:300px;position: absolute;}

#auditInfoBox{
	width: auto;
	height:auto;
	overflow:auto;
	display: none;
	position: absolute;
	z-index: 500;
	top: 50%;
	left:0;

	padding-right:20px;
	padding-left:20px;
	-webkit-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
	background-color: #f6f6f6;
	border-radius:3px;
}
</style>
<script language="javascript">
const FLOW_WAIT_USER_PERMIT=0
const FLOW_WAIT_AUDIT_PERMIT=2
const FLOW_WAIT_ADMIN_PERMIT=3
const FLOW_USER_REJECT=1
const FLOW_AUDIT_REJECT=4
const FLOW_ADMIN_REJECT=6
const FLOW_ADMIN_PERMIT=5
</script>
<div id="auditInfoBox"></div>
<div id="infobox"></div>

<div class="right" id="rightContent"><br>

<?php
	DoMonthCheck($con);
	$forbiden="/[ ,`'\(\)\"?\\!$%^&*;\|\{\}\[\].]/";

	$table_width = '82%';
	if($_SESSION['zy_user']!='馆员')
	{
		echo "<br><br><br><center><label style='font-family:微软雅黑;font-size:16px;vertical-align:bottom;font-weight:500;color:blue'>待处理申请单</label></center>";
		echo "<table width={$table_width} align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0'>";
		echo "<form name='frm_barcode' onSubmit=\"return ajaxBarcode('{$_SESSION['zy_depart_name']}');\">";
		echo "<tr height='32px'>";
		echo "<td align=right><font color=gray>请扫条码或点[申请进度]处理</font> <input type='text' id='barcode' name='barcode' size=10 class='barcode2' value='' autofocus='autofocus '> </td>";
		echo "</tr></form></table>";
		echo "<table width={$table_width} align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0' >";
		echo "<tr bgcolor=#e6e6e6 height='40px;'><td><b>申请单号</b></td><td><b>库房</b></td><td><b>申请日期</b></td><td><b>申请用途</b></td><td><b>申请人</b></td><td><b>申请类别</b></td><td><b>申请进度</b></td></tr>";

		if($_SESSION['zy_user']=='主管' )
		{//a.permited=".FLOW_WAIT_ADMIN_PERMIT."
			$sql = "select a.task_id as id,a.permited as permited,a.method as method,a.purpose as purpose,a.st_id as st_id,a.claimant as claimant,a.applyTime as applyTime,a.id as pt_id,c.name as name,c.dbase as dbase,b.depart_id as dep_id,a.st_id as st_id,a.admin_vet as admin_vet,a.audit_vet as audit_vet,a.user_vet as user_vet from (permittask a inner join portal.member b on a.claimantId=b.id) inner join portal.stations c on a.st_id=c.id where ( a.permited=".FLOW_WAIT_ADMIN_PERMIT." or a.permited=".FLOW_ADMIN_PERMIT." or ((a.permited=".FLOW_WAIT_USER_PERMIT." or a.permited=".FLOW_WAIT_AUDIT_PERMIT.") and a.claimantid={$_SESSION['zy_admin_id']})) and b.depart_id={$_SESSION['zy_depart_id']}";
		}
		else if($_SESSION['zy_user']=='会计' )
		{//a.permited=".FLOW_WAIT_AUDIT_PERMIT."
			$sql = "select a.task_id as id,a.permited as permited,a.method as method,a.purpose as purpose,a.st_id as st_id,a.claimant as claimant,a.applyTime as applyTime,a.id as pt_id,c.name as name,c.dbase as dbase,b.depart_id as dep_id,a.admin_vet as admin_vet,a.audit_vet as audit_vet,a.user_vet as user_vet from (permittask a inner join portal.member b on a.claimantId=b.id) inner join portal.stations c on a.st_id=c.id where (a.permited=".FLOW_ADMIN_PERMIT." or a.permited=".FLOW_WAIT_ADMIN_PERMIT." or a.permited=".FLOW_WAIT_AUDIT_PERMIT." or (a.permited=".FLOW_WAIT_USER_PERMIT." and a.claimantid={$_SESSION['zy_admin_id']})) and b.depart_id={$_SESSION['zy_depart_id']}";
		}
		else if($_SESSION['zy_user']=='库管员' )
		{
			//得到库管员管理库房列表
			$sql = "select kulist from portal.member where id={$_SESSION['zy_admin_id']}";
			$result = mysqli_query($con,$sql);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$kulist = $row['kulist'];
			//审批环节、本部门、在其管理库房中
			$sql = "select p.task_id as id,p.permited as permited,p.method as method,p.purpose as purpose,p.st_id as st_id,p.claimant as claimant,p.applyTime as applyTime,p.id as pt_id,p.memo as memo,s.name as name,s.dbase as dbase,m.depart_id as dep_id,p.st_id as st_id,p.admin_vet as admin_vet,p.audit_vet as audit_vet,p.user_vet as user_vet,p.guest_vet as guest_vet from (permittask p inner join portal.member m on p.claimantId=m.id) inner join portal.stations s on p.st_id=s.id WHERE m.depart_id={$_SESSION['zy_depart_id']} and  ( p.permited=".FLOW_WAIT_USER_PERMIT." or p.permited=".FLOW_WAIT_AUDIT_PERMIT." or (p.permited=".FLOW_AUDIT_REJECT." and method='入库') or (p.permited=".FLOW_ADMIN_REJECT ." and method='入库')  or p.permited=".FLOW_WAIT_ADMIN_PERMIT." or p.permited=".FLOW_ADMIN_PERMIT.")  and (find_in_set(p.st_id,'{$kulist}'))";
		}
		else
		{//管理员
			$sql = "select a.task_id as id,a.permited as permited,a.method as method,a.purpose as purpose,a.st_id as st_id,a.claimant as claimant,a.applyTime as applyTime,a.id as pt_id,a.memo as memo,c.name as name,c.dbase as dbase,b.id as dep_id,a.st_id as st_id,a.admin_vet as admin_vet,a.audit_vet as audit_vet,a.user_vet as user_vet from (permittask a inner join portal.member b on a.claimantId=b.id) inner join stations c on a.st_id=c.id where find_in_set(a.st_id,b.kulist) and b.id={$_SESSION['zy_admin_id']} and ( a.permited=".FLOW_WAIT_USER_PERMIT." or a.permited=".FLOW_WAIT_AUDIT_PERMIT." or  a.permited=".FLOW_WAIT_ADMIN_PERMIT.')';
		}

		$sql.= " order by applyTime desc";
//echo $sql;
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
		mysqli_query($con,"start transaction");
		try
		{
			$result = mysqli_query($con,$sql);
		}
		catch(Exception $e)
		{
			logInfo($e->getMessage()."\r\n".$sql);
		}
		$num = mysqli_num_rows($result);
		$vet='';
		if($num>0)
		{
			for($i=0;$i<$num;$i++)
			{
				$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

				if($_SESSION['zy_user']=='主管' )
					$vet = $row['audit_vet'];
				else if($_SESSION['zy_user']=='会计' )
					$vet = $row['user_vet'];
				else if($_SESSION['zy_user']=='库管员' )
					$vet = $row['guest_vet'];
				else
				{
					$vet='';
				}

				
				$pos = mb_strpos($vet,'[');
				if($pos!==FALSE) $vet=mb_substr($vet,$pos+1);
				$pos = mb_strpos($vet,']');
				if($pos!==FALSE) $vet=mb_substr($vet,0,$pos);

				echo "<tr style='height:40px;text-lign:center;'><td>";
				$id = sprintf('%05d', $row['id']);
				echo $id;

				$overDays=getOptionDepart("overdays");
				if($overDays=='') $overDays=5;

				$earlier = strtotime($row['applyTime']);
				$later = strtotime(date("Y-m-d H:i:s"));
				//diff函数需PHP5.3以上
				$overTime = floor(($later-$earlier)/86400);
				//echo $overDays;
				$info2='需尽快处理。';
				if($row['method']=='出库'&&$overTime>$overDays)
				{//总体超时么？
					$img='sign_error.png';
					if($_SESSION['zy_user']=='库管员')
					{
							$info='';
							if($row['permited']==FLOW_WAIT_AUDIT_PERMIT)
							{
								$info="【会计】";
								$info2="请提醒{$info}处理";
							}
							else if($row['permited']==FLOW_WAIT_ADMIN_PERMIT)
							{
								$info="【主管】";
								$info2="请提醒{$info}处理";
							}
							else
								$info2='请尽快处理';
					}
					else if($row['permited']==FLOW_WAIT_AUDIT_PERMIT)
					{
						if($_SESSION['zy_user']=='会计')
						{
							$info='';
							$info2='请尽快处理';
						}
						else
						{//库管
							$img='error.png';
							$info="【会计】";
							$info2="请提醒{$info}处理";
						}
					}
					else if( $row['permited']==FLOW_WAIT_ADMIN_PERMIT)
					{
						if($_SESSION['zy_user']=='主管')
						{
							$info='';
							$info2="请尽快处理";
						}
						else
						{//库管
							$img='error.png';
							$info="【主管】";
							$info2="请提醒{$info}处理";
						}
					}
					echo " <img width=14px height=14px src='../images/{$img}' style='cursor:pointer;' align=AbsBottom onclick=alert2('申请已超时，{$info2}')>";
				}
				else
				{//总体未超时，本环节是否超时
					if($_SESSION['zy_user']=='主管' )
						$info = $row['audit_vet'];
					else if($_SESSION['zy_user']=='会计' )
						$info = $row['user_vet'];
					else if($_SESSION['zy_user']=='库管员' )
						$info = $row['guest_vet'];

					$info = substr($info,-19);
					$earlier = strtotime($info);
					$overTime = floor(($later-$earlier)/86400);
					if($overTime>2)
					{
						if( ($row['permited']==FLOW_WAIT_AUDIT_PERMIT && $_SESSION['zy_user']=='会计')||
						    ($row['permited']==FLOW_WAIT_ADMIN_PERMIT&& $_SESSION['zy_user']=='主管')||
						    ($row['permited']==FLOW_WAIT_USER_PERMIT&& $_SESSION['zy_user']=='库管员')
						   )
							echo " <img width=14px height=14px src='../images/error.png' style='cursor:pointer;' align=AbsBottom onclick=alert2('申请在本环节已超时，请尽快处理')>";
						else echo ' 　';
					}
					else echo ' 　';
				}

				echo "</td><td>";
				echo $row['name'];
				echo "</td><td>";
				echo substr($row['applyTime'],0,10);
				echo "</td><td>";
				if($row['method']=='出库')
				{
					$complex="purpose&constr={$row['purpose']}&st_id={$row['st_id']}&st_name={$row['name']}&index=1";
					echo "<span onclick=window.location.href='chart.php?{$complex}' style='color:maroon;cursor:pointer;'>".$row['purpose']."</span>";
				}
				else
				{
					echo '<font color=grey>入库</font>';
				}
				echo "</td><td>";

				$claimant=$row['claimant'];
				$claimant = preg_replace($forbiden, '_', $claimant);
				$claimant = str_replace('\\', '_', $claimant);

				if( $row['method']=='出库')
				{
					$complex="buyer&constr={$claimant}&dep_id={$row['dep_id']}&st_id={$row['st_id']}&st_name={$row['name']}&index=2";
					echo "<span onclick=window.location.href='chart.php?{$complex}' style='color:maroon;cursor:pointer;'>".$claimant."</span>";
				}
				else
					echo "<font color=black>".$claimant."</font></a>";

				echo "</td><td style='color:grey;'>";
				if($row['method']=='入库')
					echo '<font color=green>入库</font>';
				else
					echo '出库';

				echo "</td><td>";
				if( $row['permited']==FLOW_WAIT_USER_PERMIT )
				{
					$str =($_SESSION['zy_user']=="库管员")?"<font color=blue>待我审核</font>":"<font color=gray>待库管核</font>";
				}
				else if( $row['permited']==FLOW_WAIT_AUDIT_PERMIT )
				{
					$str =($_SESSION['zy_user']=="会计")?"<font color=blue>待我审核</font>":"<font color=gray>待会计核</font>";
				}
				else if( $row['permited']==FLOW_WAIT_ADMIN_PERMIT )
				{
					$str =($_SESSION['zy_user']=="主管")?"<font color=blue>待我审核</font>":"<font color=gray>待主管批</font>";
				}
				else if( $row['permited']==FLOW_ADMIN_PERMIT )
				{
					if($_SESSION['zy_user']=='库管员')
						$color='green';
					else
						$color='green';
					if($row['method']=='入库')
						$str ="<font color={$color}>申请待入库</font>";
					else
						$str ="<font color={$color}>申请待出库</font>";
				}
				else
				{
					$str ="<font color=red>代码异常:{$row['permited']}，请暂停并告开发人员。</font>";
				}

				if($row['method']=='入库' && ($row['permited']==FLOW_AUDIT_REJECT || $row['permited']==FLOW_ADMIN_REJECT))
				{
					if ($row['permited']==FLOW_AUDIT_REJECT)
					{
						$color='gray';
						if($_SESSION['zy_user']=='会计')
						{
							$str ='已退库管';
						}
						else
						{
							if($_SESSION['zy_user']=='库管员')
								$color='red';
							$str ='会计退回';
						}
					}
					else
					{
						$color='gray';
						if($_SESSION['zy_user']=='主管')
						{
							$str ='已退库管';
						}
						else
						{
							if($_SESSION['zy_user']=='库管员')
								$color='red';
							$str ='主管退回';
						}
					}

					echo "<a style='cursor: pointer;' onClick=\"return ajaxApplyInfo2('{$row['pt_id']}',{$row['id']},'{$claimant}','{$row['applyTime']}',{$row['dep_id']},{$row['st_id']},{$row['permited']},'{$row['memo']}','{$row['purpose']}','{$row['method']}','{$row['name']}','{$vet}')\"><font color={$color}>{$str}</font></a>";
				}
				else
				{
					echo "<a title=\"{$row['pt_id']}\" style='cursor:pointer;' onClick=\"return ajaxApplyInfo('{$row['pt_id']}',{$row['id']},{$row['dep_id']},{$row['st_id']},'{$claimant}','{$row['applyTime']}',{$row['permited']},'{$row['purpose']}','{$row['method']}','{$row['name']}','{$vet}');\" >{$str}</a>";
				}
				echo "</td></tr>";
			}
		}
		else
		{
			echo "<tr height=84><td colspan=7><span>无待处理的申请单</span></td></tr>";
		}
		if($result) mysqli_free_result($result);
		echo "</table><br><br>";
	}
		echo "<center><span style='font-family:微软雅黑;font-size:16px;vertical-align:bottom;font-weight:500;line-height:60px;color:green'>我的近期申请</span></center>";
		echo "<table width={$table_width} align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0' >";
	if($_SESSION['zy_user']=='库管员')
		echo "<tr bgcolor=#e6e6e6 height='36px;'><td><b>申请单号</b></td><td><b>申请日期</b></td><td><b>申请人</b></td><td><b>库房</b></td><td><b>出库用途</b></td><td><b>申请状态</b></td></tr>";
	else
		echo "<tr bgcolor=#e6e6e6 height='36px;'><td><b>申请单号</b></td><td><b>申请日期</b></td><td><b>库房</b></td><td><b>出库用途</b></td><td><b>申请状态</b></td></tr>";
	$sql = "select a.id as id,a.task_id as task_id,a.permited as permited,a.memo as memo,a.method as method,a.purpose as purpose,a.st_id as st_id,a.claimant as claimant,a.claimantId as claimantId,substr(a.guest_vet,-19,10) as applyTime,a.applyTime as export_date,c.name as name,c.dbase as dbase,a.st_id as st_id,b.depart_id as dep_id from (permittask a inner join portal.member b on a.claimantId=b.id) inner join portal.stations c on a.st_id=c.id where a.method!='入库' and a.claimantId={$_SESSION['zy_admin_id']} ";
	if($_SESSION['zy_user']!='馆员')
	{
		$sql.=" and ( a.permited=".FLOW_TASK_OVER;
		$sql.=" or a.permited=".FLOW_ADMIN_REJECT;
		$sql.=" or a.permited=".FLOW_USER_REJECT;
		$sql.=" or a.permited=".FLOW_AUDIT_REJECT.") ";

	}
	$sql.=" order by a.applyTime desc,a.id desc limit 7;";

//echo $sql;
	try
	{
		$result = mysqli_query($con,$sql);
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage()."\r\n".$sql);
	}
	$num = mysqli_num_rows($result);
	if($num>0)
	{
		for($i=0;$i<$num;$i++)
		{
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

			$claimant=$row['claimant'];
			$claimant = preg_replace($forbiden, '_', $claimant);
			$claimant = str_replace('\\', '_', $claimant);

			echo "<tr height='32px;' align=center><td>";
			echo sprintf('%05d',$row['task_id']);
			echo "</td><td>";
			echo substr($row['applyTime'],0,10);
			if($_SESSION['zy_user']=='库管员')
			{//非全电子流转
				echo "</td><td>";
				echo $claimant;
			}
			echo "</td><td>";
			echo $row['name'];
			echo "</td><td align=left>";
			echo '&nbsp;',$row['purpose'];
			echo "</td><td>";
			echo "<a style='cursor: pointer;' onClick=\"return ajaxApplyInfo2('{$row['id']}',{$row['task_id']},'{$claimant}','{$row['applyTime']}',{$row['dep_id']},{$row['st_id']},{$row['permited']},'{$row['memo']}','{$row['purpose']}','{$row['method']}','{$row['name']}','')\">";
			if($row['permited']==FLOW_WAIT_USER_PERMIT)
				echo "<font color=blue>待库管核</font>";
			else if($row['permited']==FLOW_WAIT_AUDIT_PERMIT)
				echo "<font color=maroon>待会计核</font>";
			else if($row['permited']==FLOW_WAIT_ADMIN_PERMIT)
				echo "<font color=maroon>待主管批</font>";
			else if($row['permited']==FLOW_USER_REJECT)
				echo "<font color=red>库管退回</font>";
			else if($row['permited']==FLOW_AUDIT_REJECT)
				echo "<font color=red>会计退回</font>";
			else if($row['permited']==FLOW_ADMIN_REJECT)
				echo "<font color=red>主管退回</font>";
			else if($row['permited']==FLOW_ADMIN_PERMIT)
				echo "<font color=maroon>主管已批</font>";
			else
				echo "<font color=green>申请完成</font>";
			echo "</a></td></tr>";
		}
	}
	else
	{
		echo "<tr height=84><td colspan=7><font color=black><span>还没提交过出库申请</span></font></td></tr>";
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);
	mysqli_close($con);
	echo "</table><br><br><br>";
	include "bottom.php";
	echo "</td></tr></table></div></body></html>";
	include "include/jilu_print.php";
?>

<?php include "include/cookie.php"; ?>
<script language="JavaScript">
function ajaxSetStation(sid,station,dbase,folder,code_folder,head,url)
{
	document.getElementById('btnReApply').disabled = true;
	// 拆分 cookie 字符串
	var cookieArr = document.cookie.split(";");
    var key='';
    // 循环遍历数组元素
    for(var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        /* 删除 cookie 名称开头的空白并将其与给定字符串进行比较 */
		key = cookiePair[0].trim();
		if(key=='' || key=='freeime_logined'||key=='depart'||key=='mfa_call'||key=='PHPSESSID')
			continue;

		document.cookie = key+"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/code;";
    }

	var num = document.getElementById('total_num').value;
	for(i=0;i<num;i++)
	{
		// @note 1
		setCookie(document.getElementById('sp_id'+i).value+sid,1,600);
		ruku_id=document.getElementById('ruku_id'+i).value;
		setCookie(ruku_id+sid,document.getElementById('amount'+ruku_id).value,600);
	}

	var data ="sid="+sid+"&station="+station+"&folder="+folder+"&code_folder="+code_folder+"&dbase="+dbase+"&url="+url;
	ajaxServer("7_7","include/switchStation.php","POST",data);
	return false;
}
function printBill(pt_id,task_id,dep_id,st_id,purpose,permit,method)
{
	CloseIt(1,0);
	var data = 'pt_id='+pt_id+'&task_id='+task_id+'&dep_id='+dep_id+'&st_id='+st_id+'&purpose='+purpose+'&permit='+permit+'&method='+method;
	ajaxServer("loading","include/printbill.php","get",data);
	return false;
}

function printBill2(data)
{
	data = data +'&url=handleList.php';
	ajaxServer("loading","include/printbill.php","get",data);
	return false;
}
function rePrintWaitImportBill(pt_id,task_id,dep_id,st_id,web)
{
	var data = 'pt_id='+pt_id+'&task_id='+task_id+'&dep_id='+dep_id+'&st_id='+st_id;
	ajaxServer("loading","include/printWaitImportBill.php","get",data);
	return false;
}

function rePrintApplyBill(data)
{
	ajaxServer("loading","include/printApplybill.php","get",data);
	return false;
}

function MessageBox2(info,what)
{
	var obj = document.getElementById('auditInfoBox');
	obj.style.height="210px";
	obj.style.width="400px";
	var btnExit="<input type='button' value='　返　回　'  onclick=\"CloseIt(2,'handleList.php')\">";
	var btnYes="<input type='button' value='　打　印　'  onclick=printBill2('" + what + "')>　　";
	if(what=='')
	{
		obj.innerHTML="<div class='close'><span onclick=CloseIt(2,'handleList.php') style='font-size:16px;'>✕</span></div><br><br><center><h3><?php echo $_SESSION['zy_title'];?></h3><br><br>"+info+"<br><br><br><br>"+btnExit+"<br></center><br>";
	}
	else
	{
		obj.innerHTML="<div class='close'><span onclick=CloseIt(2,'handleList.php') style='font-size:16px;'>✕</span></div><br><br><center><h3><?php echo $_SESSION['zy_title'];?></h3><br><br>"+info+"<br><br><br><br>"+btnYes+btnExit+"<br><br></center><br>";
	}
	CloseIt(0,0);
}

function setBillState(id,task_id,dep_id,st_id,state,method,purpose,print,claimant)
{

	var str='';
	if(state==FLOW_USER_REJECT || state==FLOW_AUDIT_REJECT || state==FLOW_ADMIN_REJECT)
	{
		str = prompt('请输入退回原因');
		if(typeof str == "undefined" || str == null || str=='')
		{
			return false;
		}
	}
	document.getElementById('btnReject').disabled=true;
	var data='id='+id+'&task_id='+task_id+'&reason='+str+'&state='+state+'&dep_id='+dep_id+'&st_id='+st_id+'&claimant='+claimant;

	if(method=='入库')
	{
		ajaxServer('1_1',"include/setImportBill.php","post",data);
	}
	else
	{//出库,需要打印，state为下个要到环节
		if( print==1||print==2 )
		{//如是除设置流程状态外，还需打印审批单
			data='id='+id+'&task_id='+task_id+'&purpose='+purpose+'&state='+state+'&dep_id='+dep_id+'&st_id='+st_id+'&claimant='+claimant+"&print="+print;
			ajaxServer('loading',"include/setOutbillPrint.php","get",data);
		}
		else
		{//不需打印的
			ajaxServer('1_1',"include/setOutbill.php","post",data);
		}
	}
}

function commitAfterPermit(id,task_id,claimant,dep_id,st_id,purpose,method,state,print)
{
	if( state!=FLOW_ADMIN_PERMIT && !confirm('请确认纸页申请单已审批，继续？'))
		return false;
	document.getElementById("btnConfirmProcess").disabled=true;
	data='id='+id+'&task_id='+task_id+'&claimant='+claimant+'&purpose='+purpose+'&dep_id='+dep_id+'&st_id='+st_id+'&print='+print+"&permit="+state;
	if(method=='入库')
	{
		ajaxServer('1_1',"include/ruku2.php","post",data);
	}
	else
	{
		ajaxServer('1_1',"include/checkout2.php","post",data);
	}
}

function ajaxApplyInfo(id,task_id,dep_id,st_id,claimant,applyTime,permit,purpose,method,st_name,dealer)
{//待处理申请单详情窗
	var data ="id=" +id + "&task_id=" + task_id +"&dep_id=" + dep_id +"&st_id=" + st_id + "&claimant=" + claimant +"&applyTime="+applyTime+"&permit="+permit+'&purpose='+purpose+'&method='+method+'&mode=0&st_name='+st_name+"&dealer="+dealer;
	document.getElementById('auditInfoBox').innerHTML='';
	ajaxServer("auditInfoBox","template/ajaxApplyTab.php","post",data);
	CloseIt(0,0);
	return false;
}
function ajaxApplyInfo2(id,task_id,claimant,applyTime,dep_id,st_id,permit,reason,purpose,method,st_name,dealer)
{//已完成申请单据详情
	var data ="id=" +id+"&task_id=" + task_id + "&claimant=" + claimant +"&applyTime="+applyTime+"&dep_id="+dep_id+"&st_id="+st_id;
	data = data + '&permit='+permit+'&reason='+reason+'&purpose='+purpose+'&method='+method+'&mode=1&st_name='+st_name+"&dealer="+dealer;
//alert(data);
	document.getElementById('auditInfoBox').innerHTML='';
	ajaxServer("auditInfoBox","template/ajaxApplyTab.php","post",data);
	CloseIt(0,0);
	return false;
}

function deleteTask(pt_id,st_id,task_id,)
{
	if( !confirm('确认作废并移除此入库申请么？'))
		return false;
	var data = "pt_id="+pt_id+"&st_id="+st_id+"&task_id="+task_id;

	ajaxServer("deleteTask","include/ajaxDeleteTask.php","post",data);
}
function CloseIt(close,url)
{
	var a = document.getElementById('auditInfoBox');
	var b = document.getElementById('backbox');
	if(close==1)
	{//关闭信息窗
		a.style.display="none";
		b.style.display="none";
		document.getElementById('barcode').value='';
		document.getElementById('barcode').focus();
	}
	else if(close==2)
	{//出库操作
		a.style.display="none";
		b.style.display="none";
		document.getElementById('barcode').value='';
		document.getElementById('barcode').focus();
		if(url!='' && url!=0)
			window.location.href=url;
	}
	else
	{//0=显示信息窗
		window.scrollTo(0,0);
		b.style.display="block";
		a.style.display="block";
	}
}

function ajaxBarcode(depart)
{
	var data = "depart="+depart+"&id="+document.getElementById('barcode').value;
	ajaxServer("6_6","include/ajaxBarcode.php","post",data);
	return false;
}
function showInfo(info1,info2,info3,info4)
{
	alert('审批详情：\r\n　　'+info1+'\r\n　　'+info2+'\r\n　　'+info3+'\r\n　　'+info4+'\r\n\r\n');
	return true;
}
function getWebParm(id)
{
	   var query = window.location.search.substring(1);
	   var vars = query.split("&");
	   for (var i=0;i<vars.length;i++) {
			   var pair = vars[i].split("=");
			   if(pair[0] == id){return pair[1];}
	   }
	   return(false);
}

function pad2(number)
 {
     return (number < 10 ? '0' : '') + number;
}

var k = getWebParm('info');
if(k)
{
	var d = new Date();
	var m = d.getFullYear() + "-" +(d.getMonth() +1)+"-"+d.getDate();
	m = m +" "+pad2(d.getHours())+":"+pad2(d.getMinutes())+":"+pad2(d.getSeconds());
	if(k==1)
		MessageBox2('入库申请正在审批，请完成后再新增','');
	else if(k==2)
		MessageBox2("入库申请已批，请完成入库后再新增",'');
	else if(k==3)
	{
		m = '<b>申请：</b>已提交库管审核 '+m;
		alert2(m);
	}
	else if(k==4)
	{
		m = '<b>申请：</b>已提交会计审核 '+m;
		alert2(m);
	}
	else if(k==5)
	{//提醒打印月度盘库表
		var info = getWebParm('audit')==1?"本月还未进行盘点<br>请<font color=blue>提醒</font>库管员及时盘点":"本月还未进行盘点<br>请先执行【月度盘点】"
		alert2("<center><font color=maroon>"+decodeURIComponent(getWebParm('name'))+"</font> "+info+"</center>");
	}
}
</script>


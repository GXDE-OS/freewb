<?php
//从入库表中更新库存表月初库存
header("Content-Type: text/html; charset=utf-8");
session_start();
include "conn/conn.php";
include "include/dbtool.php";
include "GetDiscard.php";
include "include/const.php";
//执行月初盘库检查

DoMonthCheck($con);

function GetTheDay($mdate)
{
   $firstday = date('Y-m-01', strtotime($mdate));
   $lastday = date('Y-m-d', strtotime("$firstday +1 month -1 day"));
   return array($firstday,$lastday);
 }

 //返回某库房某物品库存金额
function getKucunSpMoney($con,$st_id,$sp_id)
{
	//库存金额
	$money_amount = 0;
	$fields="jiage,shuliang";
	$sql = "select {$fields} from zy_spruku where st_id={$st_id} and sp_id = {$sp_id} and shuliang>0";

	mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
	try
	{
		$result = mysqli_query($con,$sql);
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage()."\r\n".$sql);
		die($e->getMessage());
	}

	while ($rs = mysqli_fetch_object($result))
	{
		$money_amount += $rs->shuliang * $rs->jiage;
	}
	if($result)
		mysqli_free_result($result);

	//待出库金额
	$fields="r.jiage as jiage,w.amount as shuliang";
	$sql = "select {$fields} from zy_spruku r inner join waithandlelist w on w.ruku_id=r.id  where w.st_id={$st_id} and w.sp_id = {$sp_id}";
	mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
	try
	{
		$result = mysqli_query($con,$sql);
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage()."\r\n".$sql);
		die($e->getMessage());
	}
	while ($rs = mysqli_fetch_object($result))
	{
		$money_amount += $rs->shuliang * $rs->jiage;
	}
	mysqli_query($con,'commit');
	if($result)
		mysqli_free_result($result);

	return $money_amount;
}

function MakeMonthTable($year,$month,$con)
{
	$NewPage = "<div style='page-break-after:always'></div>";
	$table = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>";
	$table_noborder= "<table width='848px' align='center' style=' text-align:center;' cellpadding='0' cellspacing='0' border='0' bordercolor='#c0c0c0'>";
	$title = "<tr bgcolor=#f0f0f0 height='36px' align='center'><td><b>序号</b></td><td><b>名称</b></td><td><b>月初数量</b></td><td><b>出库数量</b></td><td><b>入库数量</b></td><td><b>月末数量</b></td><td><b>月末金额(人民币)</b></td></tr>";

	$tail = "<tr height=48><td align='left' width=35%>会计主管：</td><td align='left' width=35%>　　会计：</td><td align='left' width=30%>库房管理员：</td></tr></table>";

	//本月执行，生成上月的库存结果
	if( $month==1 )
	{
		--$year;
		$month = 12;
	}
	else
	{
		--$month;
	}

	$amount =0;
	$pageNum=1;
	$pageNo = "<table width='848px' border=0 align='center'><tr align=right><td>第 {$pageNum} 页 共 @PageNum@ 页</td></tr></table>";
	$pstr =$pageNo;
	$pstr .= $table_noborder;
	$pstr = $pstr . "<br><center><b><h3>{$year}年{$month}月{$_SESSION['zy_station_name']}盘库情况表</h3></b>";

	$str = date('Y-m-d');

	$pstr = $pstr . "<tr><td align=left>单位：".$_SESSION['zy_depart_name']."</td><td align='right'>制表日期：{$str}</td></tr>";
	$pstr = $pstr . "</table>";
	$pstr = $pstr . $table;
	$pstr = $pstr . $title;

	//上月末、本月初的库存值,n=1..12月
	//如果n=10，则kucun10:10月末，11月初的库存量 kucun9:9月末，10月初的库存量
	if($month>1)
	{
		$mKey1 = sprintf("kucun%d",(int)$month-1);
		$mKey2 = sprintf("kucun%d",(int)$month);
	}
	else
	{
		//当前是1月份
		$mKey1 = "kucun12";
		$mKey2 = "kucun1";
	}
	//$mKey1 +=2;
	//$mKey2 +=2;

	//生成盘库月的月初和月末时间
	$str = sprintf("%d-%d-1",$year,$month);
	$date1 = Date($str);
	//echo $str.'<br>';
	//得到所计算月的最后1天
	$day = GetTheDay($str);
	//生成日期字符串
	//echo $day[1].'<br>';
	$date2 = $day[1];

	$i=0;
	$k=0;
	$n=0;
	$sum=0;

	$ps= getPageSize(TABLE_MONTH_CHECK);
	$firstPage =$ps[0];
	$otherPage = $ps[1];

	$dep_id=$_SESSION['zy_depart_id'];
	$st_id = $_SESSION['zy_station_id'];

	$fields="k.id,k.st_id,sp_id,kucun,kucun1,kucun2,kucun3,kucun4,kucun5,kucun6,kucun7,kucun8,kucun9,kucun10,kucun11,kucun12";
	$sql = "select {$fields},x.name as name from zy_spkucun k inner join zy_spxinxi x on x.id=k.sp_id where k.st_id={$st_id} and x.st_id={$st_id} order by k.sp_id";

	set_time_limit(0);
	mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
	try
	{
		$result = mysqli_query($con,$sql);
		while ($rs = mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			mysqli_query($con,"START TRANSACTION");
			$kucun = $rs['kucun'];
			$sp_id = $rs['sp_id'];

			//取得申领和已过期物品数量
			$waitNum = GetExtraNum($sp_id,'waithandlelist',$con,$dep_id,$st_id);
			$kucun +=$waitNum;
			//$expNum = GetExtraNum($sp_id,'expire',$con,$dep_id,$st_id);

			//上月初的库存值
			$kucun_yc = $rs[$mKey1];
			//上月末的库存值
			$kucun_ym = $rs[$mKey2];

			//从物品信息库中查物品名称
			$spname=$rs['name'];

			//当月出库总数量
			$sql = sprintf("select sp_id,`date`,sum(shuliang) as shuliang FROM `zy_spchuku` where st_id={$st_id} and sp_id=%d and `date`>='{$date1}' and `date`<='{$date2}' limit 1",$sp_id);
			$res = mysqli_query($con,$sql);
			$row = mysqli_fetch_array($res,MYSQLI_ASSOC);
			$MonthOut = $row['shuliang'];
			if($res) mysqli_free_result($res);
			//echo sp_id.'=['.$MonthOut.']<br>';
			if( $MonthOut=='') $MonthOut='0';

			//当月入库总数量,当月入库可能为0
			$sql = sprintf("select sp_id,`date`,sum(shuliang2) as shuliang FROM `zy_spruku` where sp_id=%d and st_id={$st_id} and `date`>='{$date1}' and `date`<='{$date2}' limit 1",$sp_id);
			$res = mysqli_query($con,$sql);
			$row=mysqli_fetch_array($res,MYSQLI_ASSOC);
			$MonthIn = $row['shuliang'];
			if($res) mysqli_free_result($res);
			if( $MonthIn=='') $MonthIn='0';

			//如果库存为0,申领出库数也为0,且本月即无入库也无出库，则在盘库表中不出现（已完全用完）
			if( $kucun==0 && $MonthOut=='0' && $MonthIn=='0' )
				continue;

			if( $kucun_yc==0 && $kucun_ym=='0' && $MonthOut=='0' &&  $MonthIn=='0' )
				continue;

			$kucun_ym2 = $kucun_yc + $MonthIn - $MonthOut;

			if( $k==0 )
			{//第一页
				if( $i == $firstPage )
				{//第一页满
					$i=0;
					$k=1;
					++$pageNum;
					$pstr = $pstr . "</table>";
					$pstr = $pstr . $table_noborder;
					//$pstr = $pstr . $tail;
					$pageNo = "<table width='848px' border=0 align='center'><tr align=right><td>第 {$pageNum} 页 共 @PageNum@ 页</td></tr></table>";
					$pstr = $pstr .$NewPage.$pageNo. "<br>";
					$pstr = $pstr . $table;
					$pstr = $pstr . $title;
				}
			}
			else if( $k==1 &&$i==$otherPage )
			{//第二及后面页满
					$i=0;
					++$pageNum;
					$pstr = $pstr . "</table>";
					$pstr = $pstr . $table_noborder;
					//$pstr = $pstr . $tail;
					$pageNo = "<table width='848px' border=0 align='center'><tr align=right><td>第 {$pageNum} 页 共 @PageNum@ 页</td></tr></table>";
					$pstr = $pstr .$NewPage.$pageNo."<br>" ;
					$pstr = $pstr . $table;
					$pstr = $pstr . $title;
			}

			++$i;
			++$n;
			$pstr = $pstr .  "<tr bgcolor=white height=36px;>";
			$pstr = $pstr .  "<td>$n</td>";
			$pstr = $pstr .  "<td align=left>　$spname</td>";

			$str = intval($kucun_yc);
			if($str != $kucun_yc) $str =$kucun_yc;//去掉.00
			$pstr = $pstr .  "<td>$str</td>";

			$str = intval($MonthOut);
			if($str != $MonthOut) $str=$MonthOut;//去掉.00
			$pstr = $pstr .  "<td>$str</td>";

			$str = intval($MonthIn);
			if($str != $MonthIn) $str=$MonthIn;//去掉.00
			$pstr = $pstr .  "<td>$str</td>";

			$str = intval($kucun_ym2);
			if($str != $kucun_ym2) $str=$kucun_ym2;//去掉.00
			if( $kucun_ym != $kucun_ym2 )
			{
				logInfo("{$spname}({$sp_id}) ym={$kucun_ym} ym2={$kucun_ym2}");
				$pstr.="<td><a style='text-decoration:none;' href=../../../code/include/correct.php?id={$rs['id']}&key={$mKey2}&value={$kucun_ym2}&mode=2&sp_id={$sp_id}&st_id={$st_id} onClick=\"if (confirm('确定要更正此条数据吗？')) return true; else return false;\"><font color=red><b>{$str}⚠</font></b></a></td>";
			}
			else
				$pstr.="<td>$str</td>";

			$sum+=$kucun_ym2;

			$money =0;
			$money = getKucunSpMoney($con,$st_id,$sp_id);
			$amount +=$money;

			$money = number_format($money,2,'.',',');
			$pstr = $pstr .  "<td align=center>{$money}</td>";

			$pstr = $pstr .  "</tr>";
			mysqli_query($con,"commit");
		}
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage()."\r\n".$sql);
	}

	if($n==0)
	{
		$pstr .= "<tr height='108px'><td colspan=11>上月库房没有数据，查库存<a href='/{$_SESSION['zy_code_folder']}/include/printStockList.php'>请点我</a>。</td></tr>";
	}
	else
	{
		$pstr .= "<tr bgcolor=#f1f1f1 height=36px; align=center>";
		$amount = number_format($amount,2);
		$pstr .= "<td colspan=2><b>合计</b></td><td colspan=4>数量：{$sum}</td><td>金额：{$amount}</td></tr>";
	}
	$pstr .= "</table>";

	if($result) mysqli_free_result($result);
	set_time_limit(30);

	$pstr = str_replace("@PageNum@",$pageNum,$pstr);

	$pstr = $pstr . $table_noborder;
	$pstr = $pstr . $tail;
	/////////////////////////////////////////////////////
	//生成盘库清单表
	/////////////////////////////////////////////////////
	if($n>0)
	{
		$pstr .= $NewPage;
		$pstr .=MakeTransTable($firstPage,$otherPage,0,$con,$dep_id,$st_id);
	}

	updateOption('InfoMonthCheck',$month);
	return $pstr;
}
//主程序段生成表格
	$ajax_print = false;
	if(isset($_GET['year']) && isset($_GET['month']))
	{
		$month=$_GET['month'];
		$year=$_GET['year'];
		++$month;
		if($month==13)
		{
			$month=1;
			++$year;
		}
	}
	else
	{
		$ajax_print=true;
		$month = date('n');//取当前不带前导0的月份
		$year = date('Y'); //4位年份
	}
	$str = MakeMonthTable($year,$month,$con);
	PrintTable($str,'',"monthcheck.html",PAPER_SYSTEM,$ajax_print);
?>

<?php
//handleList.php和applyList调用 申领物品列表模板
//state=0 ajaxApplyInfo(处理申请单)　state=1 ajaxApplyInfo2(已申请清单列表)
session_start();
$path = $_SERVER['PHP_SELF'];
if (strncmp($path, '/code/inc', 9) == 0) { //从include中调用
	include "../conn/conn.php";
	include_once "dbtool.php";
	include_once "const.php";
} else if (strncmp($path, '/code/template', 14) == 0) { //从template中调用
	include "../conn/conn.php";
	include_once "../include/const.php";
	include_once "../include/dbtool.php";
} else { //从code中调用
	include "conn/conn.php";
	include_once "include/dbtool.php";
	include_once "include/const.php";
}
date_default_timezone_set('PRC');
$permit = $_POST['permit'];
$st_id = $_POST['st_id'];
$task_id = $_POST['task_id'];
$id = $_POST['id'];
$method = $_POST['method'];

$cookie ="";
if($method=='出库' && ($permit==FLOW_USER_REJECT || $permit==FLOW_AUDIT_REJECT || $permit==FLOW_ADMIN_REJECT))
{
	$k=0;
	$sql = "select sp_id,sp_name from handlelist where id='{$id}' and st_id={$st_id} order by id";
	$result = mysqli_query($con,$sql);
	while($row = mysqli_fetch_object($result))
	{
		$sp_id = $row->sp_id;
		$cookie.= "<input type='hidden' id='sp_id{$k}' value='{$sp_id}'>";
		++$k;
	}
	$cookie.= "<input type='hidden' id='total_num' value='{$k}'>";
}

$claimant = $_POST['claimant'];
$applyTime = $_POST['applyTime'];
$dep_id = $_POST['dep_id'];
$warehouse = $_POST['st_name'];
$purpose = $_POST['purpose'];

$forbiden="/[ ,`'\(\)\"?\\!$%^&*;\|\{\}\[\].]/";
$claimant = preg_replace($forbiden, '_', $claimant);
$claimant = str_replace('\\', '_', $claimant);

$eletricFlow = getOptionDepart('eletricFlow', $con);
if ($eletricFlow == '') $eletricFlow = 0;

$reason = $_POST['reason'];
if ($reason == '') $reason = '无货';

$state = $_POST['mode'];

$width='94%';
$webstr = " <div class='close'><span style='font-size:16px;' onclick='return CloseIt(1,0);'>✕</span></div>";
$webstr .= "<table width=100% align=\"center\"  border=\"0\"><tr><td valign=\"middle\">";
$webstr .= "<table width=\"{$width};\" align=\"center\" valign=\"middle\" border=\"0\">";
if ($method == '入库')
	$webstr .= "<tr height=\"64px;\"><td valign=bottom align=\"center\" colspan=3><label id='title_audit' style='color:#555555;font-size:16px;font-weight:500;'>{$warehouse}<font color=green> 入库申请单</font></label></td></tr>";
else
	$webstr .= "<tr height=\"64px;\"><td valign=bottom align=\"center\" colspan=3><h3><label id='title_audit' style='color:#555555;font-weight:500'>{$warehouse}<font color=maroon> 出库申请单</font> ($purpose)</label></h3></td></tr>";

$dealer = $_POST['dealer'];
if ($dealer != '') $dealer = $str.'　来自：<font color=gray>' . $dealer . '</font>';

$str = substr($applyTime,0,10);
$webstr .= "<tr height=\"28px;\"><td align=\"left\" width=32%>申请人：<font color=gray>{$claimant}</font></td><td align=\"center\" width=32%>{$dealer}</td><td width=36% align=\"right\">申请日期：<font color=gray>{$str}</font>　</td></tr>";
$webstr .= "</table>";
$webstr .= "<table width='{$width}' align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1' bordercolor=gray >";

$str = ($method == '出库' && $state == APPLY_STATE_GOING) ? '<td>出后库存</td>' : '';
$str2 =($state == APPLY_STATE_GOING && $method == '入库') ? '<td>外币<br>单价</td><td>外币<br>币种</td><td>币种<br>比价</td>':'';
$webstr .= "<tr height=\"36px\" align=\"center\" bgcolor=#e6e6e6><td>序号</td><td>物品名称</td><td>品牌</td><td>型号</td><td>单位</td><td>数量</td>{$str}<td>过期日期</td>{$str2}<td>人民币<br>单价</td><td>总价小计</td>";

$expire = 0;
if ($state == APPLY_STATE_FINISH) { //调用来自申领记录列表
	if ($method == '入库') {
		$sql = "select a.rate as rate,a.curency as curency,a.jiage_other as jiage_other,a.jiage2 as jiage2,a.shuliang2 as shuliang2,a.date2 as sp_date,a.brand as sp_brand,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,a.st_id as st_id,a.sp_id as sp_id,b.name as sp_name,a.shuliang as amount from zy_spxinxi b inner join waitimport a where a.task_id={$task_id} and a.sp_id=b.id and a.st_id={$st_id} and b.st_id={$st_id} order by a.id";
	} else {
		$task_id = sprintf("%05s", $task_id);
		$sql = "select a.date2 as sp_date,a.brand as sp_brand,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,b.id as pt_id,b.ruku_id as ruku_id,b.sp_id as sp_id,b.sp_name as sp_name,b.amount as amount,a.dep_id as dep_id,a.st_id as st_id,k.kucun as kucun  from ( handlelist b inner join zy_spruku a on a.id=b.ruku_id) inner join zy_spkucun k on a.sp_id=k.sp_id where b.id='{$id}' and a.st_id={$st_id} and b.st_id={$st_id} and k.st_id={$st_id} order by b.id";
	}
	//echo $sql;
} else if ($state == APPLY_STATE_GOING) { //调用来自待处理申请清单表
	if ($method == '入库') {
		$sql = "select a.rate as rate,a.curency as curency,a.jiage_other as jiage_other,a.jiage2 as jiage2,a.shuliang2 as shuliang2,a.date2 as sp_date,a.brand as sp_brand,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,a.sp_id as sp_id,b.name as sp_name,a.shuliang as amount,a.shuliang2 as shuliang2,b.dep_id as dep_id,b.st_id as st_id from (zy_spxinxi b inner join waitimport a on a.sp_id=b.id)  where a.task_id={$task_id} and a.st_id={$st_id} and b.st_id={$st_id} order by a.id";
	} else { //出库
		$webstr .= "<td>备 注</td>";
		$sql = "select a.date2 as sp_date,a.brand as sp_brand,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,b.ruku_id as ruku_id,b.sp_id as sp_id,b.sp_name as sp_name,b.amount as amount,b.memo as memo,a.dep_id as dep_id,a.st_id as st_id,a.shuliang as kucun,k.kucun as kucun2  from ( waithandlelist b  inner join  zy_spruku a on a.sp_id=b.sp_id ) inner join zy_spkucun k on a.sp_id = k.sp_id where b.task_id={$task_id} and a.id=b.ruku_id and a.st_id={$st_id} and b.st_id={$st_id} and k.st_id={$st_id} order by b.sp_id";
	}
}
$webstr .= "</tr>";

if ($state == APPLY_STATE_GOING)
	$today = date("Y-m-d");
else
	$today = substr($applyTime, 0, 10);

$discount = getOptionDepart('discount', $con);
if ($discount == '') $discount = 1;

$money = 0;
$k = 0;
mysqli_query($con,"start transaction");
$result = mysqli_query($con, $sql);
if (!$result) die("Error:" . mysqli_error($con) . "<br>#{$sql}");
$ItemNum = mysqli_num_rows($result);

if ($ItemNum > 9)
{
	$webstr[0] = "\t";
}
$sp_name = '';
for ($i = 0; $i < $ItemNum; $i++)
{
	++$k;
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	$webstr .= "<tr height=\"36px;\" align=\"center\" style='color:gray;background-color:#f1f1f1'>";
	$webstr .= "<td>{$k}</td>";
	$webstr .= "<td style='color:black;'>{$row['sp_name']}</td>";
	$webstr .= "<td>{$row['sp_brand']}</td>";
	$webstr .= "<td>{$row['sp_model']}</td>";
	$webstr .= "<td>{$row['sp_unit']}</td>";

	$amount = intval($row['amount']);
	if ($amount != $row['amount']) $amount = $row['amount'];
	$webstr .= "<td>{$amount}</td>";
	
	//@note 带入此物品申领数量
	if($state == APPLY_STATE_FINISH && ($permit==FLOW_USER_REJECT || $permit==FLOW_AUDIT_REJECT || $permit==FLOW_ADMIN_REJECT))
	{
		$webstr .="<input type='hidden' id='ruku_id{$i}' value={$row['ruku_id']}>";
		$webstr .="<input type='hidden' id='amount{$row['ruku_id']}' value={$amount}>";
	}

	if ($method == '出库' && $state == APPLY_STATE_GOING)
	{ //仅正流转的出库申请显示库存
		//$kucun3=intval($row['kucun']);
		//if($kucun3!=$row['kucun'])
		//	$kucun3=$row['kucun'];
		if($sp_name!=$row['sp_name'])
		{
			$sp_name = $row['sp_name'];
			$kucun2 = intval($row['kucun2']);
			$kucun2 < 5 ? $color = 'red' : $color = 'green';
			if ($kucun2 != $row['kucun2']) $kucun2 = $row['kucun2'];
			$webstr .= "<td><font color=$color>{$kucun2}</font></td>";
		}
		else
		{
			$webstr .="<td>-</td>";
		}
		$kucun += $amount;

	}
	$e = $row['sp_date'] <= $today ? 1 : 0;
	if ($e == 1) $expire = 1;

	if ($e == 1) //expired
		$webstr .= "<td><font color=red>{$row['sp_date']}</font></td>";
	else
		$webstr .= "<td>{$row['sp_date']}</td>";

	if ($state == APPLY_STATE_GOING && $method == '入库')
	{
		if($row['curency']=='')
		{
			$color ='gray';
			$webstr .="<td style='color:{$color};'>-</td><td style='color:{$color};'>-</td><td style='color:{$color};'>-</td>";
		}
		else
		{
			if($row['curency']=='人民币')
			{
				$color='gray';
				$rate='-';
				$str='-';
				$curency ='-';
			}
			else
			{
				$color='blue';
				$rate=$row['rate'];
				$curency=$row['curency'];
				$str =number_format( $row['jiage_other']+$row['jiage2']/$row['shuliang2'],2);
			}
			$webstr .="<td style='color:{$color};'>{$str}</td><td style='color:{$color};'>{$curency}</td><td style='color:{$color};'>{$rate}</td>";
		}
	}
	$webstr .= "<td>" . number_format($row['sp_price'], 2) . "</td>";
	$sum = $row['amount'] * $row['sp_price'];

	$sum = round($e == 1 ? $row['sp_price'] * $row['amount'] * $discount : $row['sp_price'] * $row['amount'], 2);
	$money += $sum;
	$sum = number_format($sum, 2);
	$str = ($e == 1) ? '*' : '';
	$webstr .= "<td align=right>{$str}{$sum}　</td>";
	if ($state == APPLY_STATE_GOING && $method == '出库')
		$webstr .= "<td align=left>　{$row['memo']}</td>";
	$webstr .= "</tr>";
	if ($i == 0) {
		$dep_id = $row['dep_id'];
		$st_id = $row['st_id'];
	}
}
mysqli_query($con,"commit");
$money = number_format($money, 2);

//显示操作按钮
$webstr .= "</table>";
$webstr .= "<table width=\"{$width}\" align=\"center\" style=\"text-align:center;border-collapse:collapse;border:none\" border=\"0\" bordercolor=#c0c0c0>";
$webstr .= "<tr height=\"36px;\">";
$cols = '380px';
if ($state == APPLY_STATE_GOING && $method == '出库')
	$cols = '800px';
if ($state == APPLY_STATE_FINISH) { //调用来自申领记录
	if ($permit == FLOW_USER_REJECT || $permit == FLOW_AUDIT_REJECT || $permit == FLOW_ADMIN_REJECT) //申请退回
	{ //申请被退回
		$vet = getFlowerVets(FLOW_INFO_SIMPLE, $con, $id);
		if ($permit == FLOW_USER_REJECT) $str = '库管:' . $vet['user'];
		else if ($permit == FLOW_AUDIT_REJECT) $str = '会计:' . $vet['audit'];
		else $str = '主管:' . $vet['admin'];
		$webstr .= "<td align=left><b>　<font color=maroon>申请退回原因：</font></b>{$reason} <font color=gray>({$str})</font></td>";
	} else { //审批通过
		$dealer = "";
		$vet = getFlowerVets(FLOW_INFO_SIMPLE, $con, $id);
		$dealer .= "主管<font color=gray>({$vet['admin']})</font> ";
		$dealer .= "会计<font color=gray>({$vet['audit']})</font> ";
		if ($permit == FLOW_WAIT_USER_PERMIT)
			$dealer .= "库管<font color=gray>()</font> ";
		else
			$dealer .= "库管<font color=gray>({$vet['user']})</font> ";
		$dealer .= "经手人<font color=gray>({$vet['claimant']})</font>";

		$vet = getFlowerVets(FLOW_INFO_FULL, $con, $id);
		$dealer .= " <div class='headTooltip'><span class='tooltiptext2'> 流转详情 </span><span onclick=\"return showInfo('{$vet['guest']}','{$vet['user']}','{$vet['audit']}','{$vet['admin']}');\" style='cursor: pointer;color:grey;font-size:14px;'>✤</span></div>";

		if ($permit == FLOW_ADMIN_PERMIT || $permit == FLOW_TASK_OVER) {
			$info = "'green'><b>审批完成";
		} else {
			$info = "'maroon'><b>审批进度";
		}
		$webstr .= "<td align=left><font color={$info}：</b></font>{$dealer}</td>";
		$cols = '328px';
	}
} else { //调用来自申领处理
	$dealer = "";
	$vet = getFlowerVets(FLOW_INFO_SIMPLE, $con, $id);

	if ($vet['admin'] != '')
		$dealer .= "<font color=gray>主管({$vet['admin']})</font> ";
	if ($vet['audit'] != '')
		$dealer .= "<font color=gray>会计({$vet['audit']})</font> ";
	if ($vet['user'] != '')
		$dealer .= "<font color=gray>库管({$vet['user']})</font> ";

	$dealer .= "<font color=gray>经手人({$vet['claimant']})</font>";
	$vet = getFlowerVets(FLOW_INFO_FULL, $con, $id);
	$dealer .= " <div class='headTooltip'><span class='tooltiptext2'> 审批详情 </span><span onclick=\"return showInfo('{$vet['guest']}','{$vet['user']}','{$vet['audit']}','{$vet['admin']}');\" style='cursor: pointer; font-size:14px;color:grey;'/>✤</span></div>";
	$webstr .= "<td align=left><font color=maroon><b>审批进度：</b></font>{$dealer}</td>";
	$cols = '328px';
}
if ($expire == 1) {
	$webstr .= "<td align=right><b>合计</b><font color=gray>(含过期品折扣)：</font>{$money} 元<font color=grey>(人民币)</font>　</td>";
} else {
	$webstr .= "<td align=right><b>合计</b>：{$money} 元<font color=grey>(人民币)</font>　</td>";
}

$webstr .= "</tr></table><br><br><center>";
$webstr .= "<button onclick='return CloseIt(1,0);'>　返　 回　</button>　　";

if ($method == '出库' && ($_SESSION['zy_user'] == '馆员' || ($_SESSION['zy_user'] != '馆员' && $state == APPLY_STATE_FINISH))) { //为已结束出库单、未结束馆员出库申请单添加补打出库单按钮
	if (
		$_SESSION['zy_user'] == '馆员' && (
			($permit == FLOW_WAIT_USER_PERMIT) ||
			($permit == FLOW_WAIT_AUDIT_PERMIT) ||
			($permit == FLOW_ADMIN_PERMIT) ||
			($permit == FLOW_WAIT_ADMIN_PERMIT)
		)
	) { //馆员
		$url = "pt_id={$id}&st_id={$st_id}&task_id={$task_id}&purpose={$purpose}&claimant={$claimant}&station={$warehouse}&applyTime={$applyTime}";
		$webstr .= "<button onclick=\"rePrintApplyBill('{$url}');\">　补打申请单　</button>　　";
	} else if ($_SESSION['zy_user'] != '馆员' && $state == APPLY_STATE_FINISH && ($permit == FLOW_TASK_OVER)) {
		$url = "printBill('{$id}',{$task_id},{$dep_id},{$st_id},'{$purpose}',{$permit},'{$method}')";
		$webstr .= "<button onclick={$url}>　补打出库单　</button>　　";
	}
}

if($method=='出库' && ($permit==FLOW_USER_REJECT || $permit==FLOW_AUDIT_REJECT || $permit==FLOW_ADMIN_REJECT))
{
	$webstr .= "<button id='btnReApply' onclick='ajaxSetStation($st_id,\"{$warehouse}\",\"{$_SESSION['zy_dbase']}\",\"{$warehouse}\",\"{$_SESSION['zy_code_folder']}\",0,\"kucun.php\");'>　重新申领　</button>";
}


if ($_SESSION['zy_user'] != '馆员' && $state == APPLY_STATE_GOING) { //仅当审批流程到自己处时才能打单子
	if (($_SESSION['zy_user'] == '库管员' && $permit != FLOW_WAIT_USER_PERMIT && !$eletricFlow) ||
		($_SESSION['zy_user'] == '会计' && $permit == FLOW_WAIT_AUDIT_PERMIT) ||
		($_SESSION['zy_user'] == '主管' && $permit == FLOW_WAIT_ADMIN_PERMIT)
	) {
		if ($method == '出库') {
			$url="setBillState('{$id}',{$task_id},{$dep_id},{$st_id},{$permit},'{$method}','{$purpose}',2,'{$claimant}');";
			if($eletricFlow)
			{//如果电子流转
				$webstr .= "<button id='btnReject' onclick=\"{$url}\">　打印出库单　</button>　　";
			}
			else if ($_SESSION['zy_user'] == '库管员') {
				$webstr .= "<button id='btnReject' onclick=\"{$url}\">　补打出库单　</button>　　";
			}
		} else {//入库
			$url="rePrintWaitImportBill('{$id}',{$task_id},{$dep_id},{$st_id},'{$_SESSION['zy_web']}');";
			if($eletricFlow)
			{//电子流转
				$webstr .= "<button id='btnReject' onclick=\"{$url}\">　打印入库单　</button>　　";
			}
			else if($_SESSION['zy_user'] == '库管员') {
				$webstr .= "<button id='btnReject' onclick=\"{$url}\">　补打入库单　</button>　　";
			}
		}
	}
}

$print = $eletricFlow ? 0 : 1;
$MonthCheckFirst =false;
if ($_SESSION['zy_user'] != '馆员' && $state == APPLY_STATE_GOING) { //非来宾账号:主管、会计、库管员
	if ($_SESSION['zy_user'] == '库管员') 
	{
		$month = date('n');
		if( $month==1 )
		{
			$month = 12;
		}
		else
		{
			--$month;
		}
		$checked=getOption('InfoMonthCheck');
		if( $month != (int)$checked )
		{
			$MonthCheckFirst = true;
			$webstr .= "<button id='MonthCheckFirst' onclick=ajaxServer('loading','MonthCheck.php','get','');window.location.href='handleList.php';>　<font color=maroon>请先月度盘点</font>　</button>　　";
		}

		if ($permit == FLOW_WAIT_USER_PERMIT && $MonthCheckFirst==false) { //等库管审批——只有出库才有这个状态，入库直接等会计核了
			$webstr .= "<button id='btnReject' onclick='setBillState(\"{$id}\",{$task_id},{$dep_id},{$st_id},FLOW_USER_REJECT,\"{$method}\",\"{$purpose}\",0,\"{$claimant}\");'>　不通过，退申领人　</button>　　";
			$webstr .= "<button id='btnReject' onclick='setBillState(\"{$id}\",{$task_id},{$dep_id},{$st_id},FLOW_WAIT_AUDIT_PERMIT,\"{$method}\",\"{$purpose}\",$print,\"{$claimant}\");'>　通过，送会计审核　</button>　　";
		}
		if ($method == '入库' && $MonthCheckFirst==false) {
			$str = "commitAfterPermit('{$id}',{$task_id},'',{$dep_id},{$st_id},'','{$method}',$permit,$eletricFlow);";
			if ($permit != FLOW_ADMIN_PERMIT) { //在主管审批同意之前
				if (!$eletricFlow && $permit != FLOW_WAIT_USER_PERMIT) { //电子、纸页双审批
					if ($permit == FLOW_WAIT_AUDIT_PERMIT)
						$vet = FLOW_AUDIT_REJECT;
					else
						$vet = FLOW_ADMIN_REJECT;

					$webstr .= "<button id='btnReject' onclick='setBillState(\"{$id}\",{$task_id},{$dep_id},{$st_id},$vet,\"{$method}\",\"{$purpose}\",0,\"{$claimant}\");'>　书面已拒批，退回　</button>　　";
					$webstr .= "<button id='btnConfirmProcess' onClick={$str}>　<font color=maroon>书面已批准，入库</font>　</button> ";
				}
			} else { //主管已批
				$webstr .= "<button id='btnConfirmProcess' onClick={$str}>　<font color=maroon>电子已批准，入库</font>　</button>　　";
			}
		} else if($MonthCheckFirst==false){ //出库
			$str = "commitAfterPermit('{$id}',{$task_id},'{$claimant}',{$dep_id},{$st_id},'{$purpose}','{$method}',$permit,$eletricFlow);";
			if ($permit != FLOW_ADMIN_PERMIT) { //尚未到审批通过环节
				if (!$eletricFlow && $permit != FLOW_WAIT_USER_PERMIT) { //如果是电子纸质双流转
					if ($permit == FLOW_WAIT_AUDIT_PERMIT)
						$vet = FLOW_AUDIT_REJECT;
					else
						$vet = FLOW_ADMIN_REJECT;
					$webstr .= "<button id='btnReject' onclick='setBillState(\"{$id}\",{$task_id},{$dep_id},{$st_id},$vet,\"{$method}\",\"{$purpose}\",0,\"{$claimant}\");'>　书面已拒批，作废　</button>　　";
					$webstr .= "<button id='btnConfirmProcess' onClick={$str}>　<font color=maroon>书面已批准，出库</font>　</button>　　";
					//不打印，eletricFlow=0
				}
			} else { //审批通过，FLOW_ADMIN_PERMIT
				$webstr .= "<button id='btnConfirmProcess' onClick={$str}>　<font color=maroon>电子已批准，出库</font>　</button>　　";
			}
		}
	} else if ($_SESSION['zy_user'] == '主管' && $permit==FLOW_WAIT_ADMIN_PERMIT) {
		$str = sprintf("setBillState('%s',%d,%d,%d,%d,'%s','%s',0,'%s');", $id, $task_id, $dep_id, $st_id, FLOW_ADMIN_REJECT, $method, $purpose,$claimant);
		$webstr .= "<button id='btnReject' onclick={$str}>　不通过，退回　</button>　　";

		$str = sprintf("setBillState('%s',%d,%d,%d,%d,'%s','%s',0,'%s');", $id, $task_id, $dep_id, $st_id, FLOW_ADMIN_PERMIT, $method, $purpose,$claimant);
		$webstr .= "<button id='btnReject' onclick={$str}>　同意，退库管员　</button>　　";
	} else if ($_SESSION['zy_user'] == '会计' && $permit==FLOW_WAIT_AUDIT_PERMIT) //会计
	{
		$webstr .= "<button id='btnReject' onclick=setBillState('{$id}',{$task_id},{$dep_id},{$st_id}," . FLOW_AUDIT_REJECT . ",'{$method}','{$purpose}',0,\"{$claimant}\");>　不通过，退回　</button>　　";
		$webstr .= "<button id='btnReject' onclick=setBillState('{$id}',{$task_id},{$dep_id},{$st_id}," . FLOW_WAIT_ADMIN_PERMIT . ",'{$method}','{$purpose}',0,\"{$claimant}\");>　同意，送主管审批　</button>　　";
	}
} else if ($_SESSION['zy_user'] == '库管员' && $method == '入库' && $state == APPLY_STATE_FINISH) { //账号: 库管员、入库被退回
	$webstr .= "<button id='btnReject' onclick=\"deleteTask('{$id}',{$st_id},{$task_id})\">　作　 废　</button>　　";
	$webstr .= "<button id='btnReject' onclick=\"window.location.href='include/ruku_remit.php?$pt_id={$id}&st_id={$st_id}&task_id={$task_id}'\">　编　 辑　</button>　　";
}
$webstr .= "</center></td></tr></table><br><br><br><br>";
if ($result) mysqli_free_result($result);
mysqli_close($con);
echo $webstr,$cookie;
?>
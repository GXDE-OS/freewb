<?php
session_start();

	include_once "head.php";
	include "GetDiscard.php";
	DoMonthCheck($con);
	include_once "include/jstool.php";
	include_once "include/dbtool.php";
	include_once "include/const.php";
	date_default_timezone_set('PRC');
?>
<style>
.hide{display:none;}
#btnFloatReselect {
	display: block;
	position: fixed;
	top: 254px;
	right: 20px;
	z-index: 99;
	border: none;
	outline: none;
	background-color: #808080;
	box-shadow: 5px 5px 5px #888888;
	color: white;
	cursor: pointer;
	padding: 8px;
	padding-top:12px;
	padding-bottom:14px;
	line-height:16px;
	border-radius:3px;
}

#btnFloatReselect:hover
{
  background-color: orange;
}

#thumbox {
		height: auto;
		width: auto;
		overflow: auto;
		display: none;
		position: fixed;
		z-index: 500;
		top: 50%;
		left: 55%;

		-webkit-transform: translate(-50%, -50%);
		transform: translate(-50%, -50%);
		background-color: #f6f6f6;
		border-radius: 5px;
		padding-left: 14px;
		padding-right: 14px;
		padding-top: 14px;
		padding-bottom: 14px;
		box-shadow: 7px 7px 5px #808080;

	}
</style>

<button onclick="reSelect(<?php echo $_GET['view'];?>,1)" id="btnFloatReselect" ><label style='font-size:14px;'>↩</label><br>返<br>回<br>补<br>选</button>
<div id='backbox'></div>
<div id="stationbox">
	<br><div id='ajax_div_stations'></div>
</div>

<?php include_once "include/cookie.php"; ?>
<script language="JavaScript">
	const USE_MEMO = <?php echo USE_MEMO; ?>;
	function getTargetName()
	{
		var target_name,target_id=document.getElementById('target').value;
		document.getElementById('target_id').value = target_id;
		setCookie("target_id"+<?php echo $_SESSION['zy_station_id'];?>,target_id,600);
		var Options = document.getElementById("target").getElementsByTagName('option');
		for (var i = 0; i < Options.length; i += 1) {
			if (Options[i].value === target_id) {
				target_name = Options[i].innerHTML;
				break;
			}
		}
		document.getElementById('target_name').value = target_name;
		setCookie("target_name"+<?php echo $_SESSION['zy_station_id'];?>,target_name,600);
		return target_name;
	}
	function setTarget()
	{
		getTargetName();
		showStationWindow(0);
	}

	function getCookie(cookieName) {
        //获取所有的cookie "psw=1234we; rememberme=true; user=Annie"
        var totalCookie = document.cookie;
        //获取参数所在的位置
        var cookieStartAt = totalCookie.indexOf(cookieName + "=");
        //判断参数是否存在 不存在直接返回
        if (cookieStartAt == -1) {
            return;
        }
        //获取参数值的开始位置
        var valueStartAt = totalCookie.indexOf("=", cookieStartAt) + 1;
        //以;来获取参数值的结束位置
        var valueEndAt = totalCookie.indexOf(";", cookieStartAt);
        //如果没有;则是最后一位
        if (valueEndAt == -1) {
            valueEndAt = totalCookie.length;
        }
        //截取参数值的字符串
        var cookieValue = unescape(totalCookie.substring(valueStartAt, valueEndAt));
        return cookieValue;
    }

	function getPurpose(mode)
	{
		var i =document.getElementById('purpose').selectedIndex;
		if(document.getElementById('purpose').options[i].value=='物品移库')
		{
			var a= document.getElementById('stationbox');
			var b= document.getElementById('backbox');
			var c= document.getElementById('ajax_div_stations');
			var cookie = getCookie('target_id'+<?php echo $_SESSION['zy_station_id'];?>);
			var info="<br>物品要移往的库房：<select id='target' name='target' value=cookie>";
			<?php
				$pstr='';
				$sql = "select id,name from portal.stations where depart_id={$_SESSION['zy_depart_id']};";
				$result=mysqli_query($con,$sql);
				while($row=mysqli_fetch_object($result))
				{
					if($row->name==$_SESSION['zy_station_name'])
						continue;
					$pstr.="<option value={$row->id}";
					$pstr.=">{$row->name}";
					$pstr.="</option>";
				}
				$pstr.= "</select>"
			?>
			info = info +<?php echo '"'.$pstr.'"';?>;
			info=info.replace('<option value='+cookie,'<option value='+cookie+' selected')

			a.style.width="auto";
			a.style.height.height="auto";
			a.style.backgroundColor='#f6f6f6';
			c.innerHTML="<div class='close'><span onclick='return showStationWindow(0);' style='font-size:16px;'>✕</span></div><table border=0></tr><tr align=center><td width='10px'>　</td><td><font style='color:#606060;font-size:16px;font-weight:450;'><?php echo $_SESSION['zy_title'];?></font></td><td width='10px'>　</td></tr><tr height=8px></tr><tr><td></td><td>"+info+"</td><td></td></tr><tr height=28px></tr><tr><td colspan=3 align=center><button onclick=setTarget()>　确　定　</button>　　<button onclick=showStationWindow(0)>　返　回　</button></td></tr></table></center>";
			if(mode==1)
			{
				a.style.display='block';
				b.style.display='block';
			}
		}
	}

function reSelect(view,save)
{
	if(save)
	{
		var num = document.getElementById('ItemNum').value;
		if(num!='')
		{
			var ruku_id='';
			var amount='';
			for(i=0;i<num;i++)
			{
				//@note ruku_id_st_id
				ruku_id = document.getElementById('sp_id'+i).value+<?php echo $_SESSION['zy_station_id'];?>;
				amount = document.getElementById(i).value;
				if( amount==''||amount<=0 )
				{
					document.cookie = ruku_id+"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/code;";
				}
				else
				{
					setCookie(ruku_id,amount,600);
				}
				if(USE_MEMO)
				{
					ruku_id ='memo'+i+<?php echo $_SESSION['zy_station_id'];?>;
					setCookie(ruku_id,document.getElementById('memo'+i).value,600);
				}
			}
			setCookie("billno"+<?php echo $_SESSION['zy_station_id'];?>,document.getElementById('BillNo').value,600);
			setCookie("receiver"+<?php echo $_SESSION['zy_station_id'];?>,document.getElementById('receiver').value,600);
			setCookie("purpose"+<?php echo $_SESSION['zy_station_id'];?>,document.getElementById('purpose').value,600);
			setCookie("target_id"+<?php echo $_SESSION['zy_station_id'];?>,document.getElementById('target_id').value,600);
			setCookie("target_name"+<?php echo $_SESSION['zy_station_id'];?>,document.getElementById('target_name').value,600);
		}
	}
	if(view==0)
		window.location='kucun_new.php';
	else
		window.location='kucun_old.php';
	return false;
}

const MAX_INPUT_VARS=1200;
function updateTotal()
{
	var total = 0;
	var GoodsNum = document.getElementById('ItemNum').value;
	if(GoodsNum<1) return false;
	if(GoodsNum>MAX_INPUT_VARS)
	{
		alert(GoodsNum+' 待选项已超系统承载极限('+MAX_INPUT_VARS+')，请分批出库');
		reSelect(<?php echo $_GET['view'];?>,0);
	}

	var i=0,k=0,money =0,amount=0;
	var fruits=[],tmp='',key='',key1='',key2='', num=0;
	discount=document.getElementById('discount').value;
	key1=decodeURIComponent(document.getElementById('sp_name0').value);

	num = document.getElementById(0).value;
	if(num=='') num=0;
	money = document.getElementById('sp_price0').value * Number(num);
	e = document.getElementById('sp_expire0').value;
	if(e!=0)
		money = Math.round(discount*money * 100) / 100;
	else
		money = Math.round(money * 100) / 100;
	amount = Number(money);

	if(GoodsNum==1)
	{
		tmp='{"name":"'+key1+'","total":'+num+'}';
		fruits.push(JSON.parse(tmp));
		total =Number(total) +  Number(num);
	}
	else
	for( i=1; i<GoodsNum; i++)
	{
		money = document.getElementById('sp_price'+i).value * Number(document.getElementById(i).value);
		e = document.getElementById('sp_expire'+i).value;
		if(e!=0)
			money = Math.round(discount*money * 100) / 100;
		else
			money = Math.round(money * 100) / 100;
		amount = Number(amount) +  Number(money);

		key='sp_name'+i;
		key2=decodeURIComponent(document.getElementById(key).value);
		if(key1==key2)
		{
			num = Number(num)+Number(document.getElementById(i).value);
			if(i==Number(GoodsNum-1))
			{
				tmp='{"name":"'+key1+'","total":'+num+'}';
				fruits.push(JSON.parse(tmp));
				total =Number(total) +  Number(num);
			}
			continue;
		}

		tmp='{"name":"'+key1+'","total":'+num+'}';
		fruits.push(JSON.parse(tmp));
		total =Number(total) +  Number(num);

		key1=key2;
		num = Number(document.getElementById(i).value);
		if(i==Number(GoodsNum-1))
		{
			tmp='{"name":"'+key1+'","total":'+num+'}';
			fruits.push(JSON.parse(tmp));
			total =Number(total) +  Number(num);
		}
	}
	var rate = document.getElementById('rate').value;
	var m = amount/rate;
		m = m.toFixed(2);
		amount = amount.toFixed(2);

	hb = document.getElementById('hb').value;
	document.getElementById('goods').value = total;
	document.getElementById('curency').value = '<tr height=20px><td width=35% align=right><font color=yellow>人民币：</font></td><td align=right><font color=white>'+toThousands(amount)+'</font></td></tr><tr height=20px><td align=right><font color=yellow>'+hb+'：</font></td><td align=right><font color=white>'+toThousands(m)+'</font></td></tr>';
	getCheckoutNum(fruits);
}
function toThousands(num) {
	return num && (num
    .toString().indexOf('.') != -1 ? num.toString().replace(/(\d)(?=(\d{3})+\.)/g, function($0, $1) {
      return $1 + ",";
    }) : num.toString().replace(/(\d)(?=(\d{3}))/g, function($0, $1) {
      return $1 + ",";
    }));
}
function UpdateBill(id,max2)
{
	var input=document.getElementById(id);
	var obj = document.getElementById('goods');
	var num = input.value;
	if( Number(num) > Number(max2) )
	{
		input.value ='';
		obj.value =0;
		input.style.backgroundColor='white';
		input.style.border='1px inherit gray';
		input.style.borderRadius='2px';
		alert('输入值大于库存数，请重输');
		return false;
	}
	if(Number(num)>0)
	{
		input.style.color='red';
		input.style.borderRadius='0px';
		input.style.backgroundColor='yellow';
		input.style.border='1px dotted gray';
	}
	else
	{
		input.style.backgroundColor='white';
		input.style.border='1px solid gray';
		input.style.borderRadius='2px';
	}
	if(isNaN(Number(num,10)))
	{
		obj.value =0;
		input.style.color='red';
		alert('输入了非数字，请重输');
		return false;
	}
	else if(num==0)
	{
		input.style.color='gray';
	}
	updateTotal();
}
function myFocus(id)
{
	var obj=document.getElementById(id);
	if(obj.value=='0')
	{
		obj.value='';
	}
}
function validData()
{
	var CheckOutNum = document.getElementById('goods').value;
	var ItemNum = document.getElementById('ItemNum').value;
	var BillNo = document.getElementById('BillNo').value;
	var receiver=document.getElementById('receiver').value;
	var OutDate = document.getElementById('OutDate').value;
	var Department = document.getElementById('Department').value;
	var Footer = document.getElementById('Footer').value;
	var StationName = document.getElementById('StationName').value;
	var nobill = document.getElementById('nobill').value;
	var purpose = document.getElementById('purpose').value;

	//检查数据合法性
	if( receiver=='')
	{
		hand2();
		alert('请输入[领物人姓名]');
		document.getElementById('receiver').focus();
		return false;
	}
	var pattern = /[ .,/<>?\[\]\\`~!@#$%^&*();:'"+-]/;
	if(pattern.test(receiver))
	{
		alert('[领物人姓名]中不允许包含[空格]和标点符号！');
		document.getElementById('receiver').focus()
		return false;
	}

	if( purpose=='@@')
	{
		hand2();
		alert('请选择出库物品用途');
		document.getElementById('purpose').focus();
		return false;
	}
	if(Number(CheckOutNum)<=0)
	{
		hand2();
		alert('[物品数量]有误，请查');
		return false;
	}
	if( !isDate(OutDate,'-'))
	{
		alert('[出库日期]有误，请查'+OutDate);
		document.getElementById('OutDate').focus();
		return false;
	}
	updateTotal();
	hand();
	return false;
}

function MakeTable(guest,firstPage,otherPage,totalPage,doublePrint,curency)
{
	var CheckOutNum = document.getElementById('goods').value;
	var ItemNum = document.getElementById('ItemNum').value;
	var BillNo = document.getElementById('BillNo').value;
	var receiver=document.getElementById('receiver').value;
	var OutDate = document.getElementById('OutDate').value;
	var Department = document.getElementById('Department').value;
	var Footer = document.getElementById('Footer').value;
	var StationName = document.getElementById('StationName').value;
	var nobill = document.getElementById('nobill').value;
	var purpose = document.getElementById('purpose').value;

	//检查数据合法性
	if( receiver=='')
	{
		hand2();
		alert('请输入[领物人姓名]');
		document.getElementById('receiver').focus();
		return false;
	}

	if( purpose=='@@')
	{
		hand2();
		alert('请选择出库物品用途');
		document.getElementById('purpose').focus();
		return false;
	}

	if( !isDate(OutDate,'-'))
	{
		alert('[出库日期]有误，请查'+OutDate);
		document.getElementById('OutDate').focus();
		return false;
	}

	if(Number(CheckOutNum)<=0)
	{
		hand2();
		alert('[物品数量]有误，请查');
		return false;
	}

	var i=0;
	var str2 ='',tmp;
	var strMax ='';
	for(i=0; i<ItemNum; i++)
	{
	   str2 = document.getElementById(i).value;
	   if(isNaN(Number(str2,10)))
	   {
	   	hand2();
		alert(' 有物品[申领数量]不是数字，请查');
		return false;
	   }

	   tmp = Number(str2,10);
	   if( tmp<=0 ) continue;

	   strMax =document.getElementById('sp_amount'+i).value;
	   //alert(strMax);
	   if( tmp>Number(strMax,10) )
	   {
	   	  hand2();
	   	   var strName = decodeURIComponent(document.getElementById('sp_name'+i).value);
	   	   alert('['+strName+']申领数量大于库存量，请查');
	   	   return false;
	   }
	}
	hand2();

	//清除所有cookie函数
    var keys = document.cookie.match(/[^ =;]+(?=\=)/g);
    if(keys)
	{
        for(var i = keys.length; i--;)
		{
			if(keys[i]!='freeime_logined' && keys[i]!='depart' && keys[i]!='mfa_call' && keys[i]!='PHPSESSID')
        		document.cookie = keys[i] + '=0;expires=' + new Date(0).toUTCString();
		}
    }

	var data = "ItemNum="+document.getElementById('ItemNum').value;
	data = data + "&BillNo="+document.getElementById('BillNo').value;
	data = data + "&purpose="+document.getElementById('purpose').value;
		data = data + "&Department="+document.getElementById('Department').value;
		data = data + "&receiver="+document.getElementById('receiver').value;
	if(purpose=='物品移库')
	{
		data = data + "&target_id=" +document.getElementById('target_id').value;
		data = data + "&target_name=" +document.getElementById('target_name').value;
	}
	for(i=0; i<ItemNum; i++)
	{
		str = document.getElementById(i).value;
		if( Number(str)<=0 ) continue;
		if( str[0]=='0') str = str.substr(1);
		data = data + "&" + i + "=" + str;

		str = document.getElementById('id'+i).value;
		data = data + "&id" + i +"=" + str;

		str = document.getElementById('sp_id'+i).value;
		data = data + "&sp_id" + i +"=" + str;

		str = document.getElementById('sp_name'+i).value;
		data = data + "&sp_name" + i +"=" + str;

		str = document.getElementById('memo'+i).value;
		data = data + "&memo" + i +"=" + str;
	}
	document.getElementById('btnCheckoutSubmit').disabled = true;
	//if(document.getElementById('eletricFlow').value==1) //纯电子流转不用显示进度窗
	//	ajaxServer('checkout_guest_silent',"include/checkguest.php","post",data);
	//else
		ajaxServer('checkout_guest',"include/checkguest.php","post",data);
	return false;
}

function showPic(mode,ware,dep_id,st_id,ruku_id)
{
	var data = "mode="+mode+'&ware='+ware+'&dep_id='+dep_id+'&st_id='+st_id+'&ruku_id='+ruku_id;
	ajaxServer('thumbox','include/ajaxGetPicUrl.php','get',data);
	return false;
}
</script>

<?php
	if(date('m')==12 && date('d')==31 ) //预防编号跨年的问题
		$BillNo='';
	else
		$BillNo = $_COOKIE['BillNo'.$_SESSION['zy_station_id']];
	if($BillNo=='')	$BillNo=getUpdateOption("applyNo",$con);
	$receiver = $_COOKIE['receiver'.$_SESSION['zy_station_id']];

	$doublePrint=getOptionDepart("doublePrint",$con);
	if($doublePrint=='') $doublePrint=0;

	$curency = getOptionDepart("curency",$con);
	if($curency=='') $curency='美元';

	$eletricFlow = getOptionDepart('eletricFlow',$con);
	if($eletricFlow=='') $eletricFlow=0;
	echo "<input type='hidden' name='eletricFlow' id='eletricFlow' value={$eletricFlow}>";

?>
<div id="thumbox">
	<div id='ajax_div_thumb'></div>
</div>
<!--startprint-->
<div class="right" id="rightContent"" id="right">
<br>
<form action="" method="post" name="checkout2" id="checkout2">
<br><center>待出库物品合计：<input size=5 name='goods' id="goods" value=0 disabled> 件<input size=8 type='hidden' id="curency">
　　领物人: <?php if($_SESSION['zy_user']!='库管员') echo "<input value='{$_SESSION['zy_user_name']}' tabindex=0  type='text' size=8 id='receiver' name='receiver' readonly style='background-color:#e6e6e6;' >"; else echo "<input value='{$receiver}' tabindex=1 autocomplete='on' type='text' size=8 id='receiver' name='receiver' autofocus='autofocus'>"; ?>
<input type='hidden' id='target_id' name='target_id' value=<?php echo $_COOKIE['target_id'.$_SESSION['zy_station_id']];?>>
<input type='hidden' id='target_name' name='target_name' value='<?php echo $_COOKIE['target_name'.$_SESSION['zy_station_id']]?>'>

　　<select id="purpose" name="purpose" tabindex=2 onChange=getPurpose(1)>
    <option value="@@">选择出库用途</option>
    <?php
    	$item= array("公务接待","对外赠礼","集体伙食","办公领用","俱乐部活动");
		if($_SESSION['zy_user']=='库管员'||$_SESSION['zy_user']=='会计')
		{
			$item[]="盘亏";
			$item[]="报废";
			$item[]="其他";
		 	$item[]="物品移库";
		}
		else
		{//主管、馆员
			$item[]="其他";
		}
    	$purpose = $_COOKIE['purpose'.$_SESSION['zy_station_id']];
    	for($i=0;$i<count($item);$i++)
    	{
    		$sel = '';
    		if( $item[$i]==$purpose ) $sel = " selected";
    		echo "<option value={$item[$i]} $sel>{$item[$i]}</option>";
    	}
   	?>
</select>
　　申领单号:<input type='text' style='background-color:#e6e6e6;'  size=5 id='BillNo' name='BillNo' value=<?php echo $BillNo;?> readonly>
　　出库日期:<input readonly tabindex=0 type='text' style='background-color:#e6e6e6;'  size=10 id="OutDate" name="OutDate" value="<?php echo date('Y-m-d'); ?>">　
	　<button onclick="return validData()"  style="cursor:pointer;color:maroon;font-weight:450;font-size:13px;">　<img id='hideit' src="../images/accept.png" width=16px hwight=16px style="cursor:pointer; vertical-align:-0.25em;">&nbsp点我继续　</button></center>
	<table align="center" style=" text-align:center;border-collapse:collapse;" cellpadding="0" cellspacing="0" border="0">
	<tr height=6px></tr></table>
	<table width=80% align="center" style=" text-align:center;border-collapse:collapse;" cellpadding="0" cellspacing="0" border="1" bordercolor="#c0c0c0">
	<tr bgcolor=#e6e6e6 height="36px;"><td width=40><b>序号</b></td><td width=150><b>物品名称</b></td><td width=90><b>品牌</b></td><td width=90><b>型号</b></td><td width=60><b>单位</b></td><td width=80><b>单价</b></td><td width=80><b>库存</b></td><td width=110><b>过期日期</b></td><?php if(USE_MEMO) echo"<td width=110><b>备注</b></td>";?><td width="100px;" bgcolor=#ffffd8><b>申领数量</b></td></tr>

<?php
	$ItemNum = $_POST['TotalItem']; //物品总数
	$expire =0;
	$e=0;
	$discount = getOptionDepart('discount',$con);
	if($discount=='')
	{
		$discount = 1;
		updateOptionDepart('discount',1,$con);
	}
	$page = getPageSize(TABLE_CHECKOUT,$ItemNum);

	$k = 0;
	$m = 0;
	$today = date("Y-m-d");
	for($i=0;$i<$ItemNum;$i++)
	{
		$str = 'p_chk'.$i;
		$chk = $_POST[$str];
		if( $chk == 0 ) continue;

		if($m==0)
		{
			$m=1;
			$color='#f8f8f8';
		}
		else
		{
			$m=0;
			$color='#ffffe8';
		}

		$str = 'p_id'.$i;
		$sp_id = $_POST[$str];
		$str = 'p_name'.$i;
		$spname = $_POST[$str];

		mysqli_query($con,'begin');
		$fields="id,brand,model,jiage,jiage2,shuliang,unit,date2,box";
		$sql = "select {$fields} from zy_spruku where st_id={$_SESSION['zy_station_id']} and sp_id = {$sp_id} and shuliang>0 order by date2";

		mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
		try
		{
			$result = mysqli_query($con,$sql);
		}
		catch(Exception $e)
		{
			logInfo($e->getMessage()."\r\n".$sql);
			die($e->getMessage());
		}
		$thumbnail=getOption('thumbnail',$con)==1;
		while ($rs = mysqli_fetch_object($result))
		{
			$amount = intval($rs->shuliang);
			if( $amount != $rs->shuliang) $amount = $rs->shuliang;

		   	$e = $rs->date2<$today?1:0;

			echo "<tr height=\"36px;\" bgcolor={$color}><td>";
			echo $k+1;
			if($thumbnail)
				echo "</td><td><span style='cursor:hand;color:maroon' onmouseenter=showPic(1,'{$_SESSION['zy_dbase']}',{$_SESSION['zy_depart_id']},{$_SESSION['zy_station_id']},{$rs->id}) onmouseleave=showPic(0,'{$_SESSION['zy_dbase']}',{$_SESSION['zy_depart_id']},{$_SESSION['zy_station_id']},{$rs->id})>";
			else
				echo "</td><td><span>";
			echo urldecode($spname);
			echo "</span></td><td>";
			echo $rs->brand;
			echo "</td><td>";
			echo $rs->model;
			echo "</td><td>";
			echo $rs->unit;
			echo "</td><td>";
			echo number_format($rs->jiage,2);
			echo "</td><td>";
			echo $amount;//当前物品库存
			echo "</td><td>";
		   	if($e==1)
		   	{
		   		$expire = 1;
				echo "<font color=red>{$rs->date2}</font>";
			}
			else
			{
				echo $rs->date2;
			}
			echo "</td>";
			if(USE_MEMO)
			{
				echo "<td align=left>";
				$tmp = 'memo'.$k.$_SESSION['zy_station_id'];
				$value = $_COOKIE[$tmp];
				$tmp = 'memo'.$k;
				printf("&nbsp;<input type='text' name='%s' id='%s' value='%s' tabindex=5 size=13>",$tmp,$tmp,$e==1?'　过期品':$value);
				echo "</td>";
			}
			else
			{
				$tmp = 'memo'.$k;
				printf("&nbsp;<input type='hidden' name='%s' id='%s' value='%s' tabindex=5 size=13>",$tmp,$tmp,$e==1?' 过期品':'');
			}
			//@note ruku_id_st_id
			$u=$_COOKIE[$rs->id.$_SESSION['zy_station_id']];
			if($u=='')
			{
				$style='color:gray;';
				$u=0;
			}
			else
			{
				$style='color:red; background-color:yellow;border-style: dotted;border-color:gray;border-width:1px';
			}
			echo "<td>";
			//物品申领数量
			$u2 =intval($u);
			if($u2!=$u)
				printf('<input tabindex=5 onfocus="myFocus(%d)" style="%s" autocomplete="off" value="%0.2f" size=5 id=%d name=%d onkeyup="UpdateBill(%d,\'%.2f\')" >',$k,$style,$u,$k,$k,$k,$amount);
			else
				printf('<input tabindex=5 onfocus="myFocus(%d)" style="%s" autocomplete="off" value=%d size=5 id=%d name=%d onkeyup="UpdateBill(%d,\'%.2f\')" >',$k,$style,$u,$k,$k,$k,$amount);
			//库存库物品id
			$tmp = 'id'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%d>",$tmp,$tmp,$sp_id);
			//物品id
			$tmp = 'sp_id'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%d>",$tmp,$tmp,$rs->id);
			//物品名称
			$tmp = 'sp_name'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%s>",$tmp,$tmp,$spname);
			//物品品牌
			$tmp = 'sp_brand'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%s>",$tmp,$tmp,$rs->brand);
			//物品型号
			$tmp = 'sp_model'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%s>",$tmp,$tmp,$rs->model);
			//物品单位
			$tmp = 'sp_unit'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%s>",$tmp,$tmp,$rs->unit);
			//是否过期
			$tmp = 'sp_expire'.$k;
			printf("<input type='hidden' name='%s' id='%s' value='%s'>",$tmp,$tmp,$e);
			//物品单价(已含物品分摊运费等)
			$tmp = 'sp_price'.$k;
			printf("<input type='hidden' name='%s' id='%s' value='%s'>",$tmp,$tmp,$rs->jiage);

			//物品分摊运费等
			//$tmp = 'sp_2price'.$k;
			//printf("<input type='hidden' name='%s' id='%s' value='%s'>",$tmp,$tmp,$rs->jiage2);

			//物品存放位置
			$tmp = 'sp_box'.$k;
			printf("<input type='hidden' name='%s' id='%s' value='%s'>",$tmp,$tmp,$rs->box);
			//物品库存数量，出库前校验
			$tmp = 'sp_amount'.$k;
			printf("<input type='hidden' name='%s' id='%s' value=%.2f>",$tmp,$tmp,$amount);
			++$k;
			echo "</td></tr>";
		}
		mysqli_query($con,'commit');
		if($result) mysqli_free_result($result);

	}

	echo "<div id='myid' class='hide'><input type='text' size=1 name='ItemNum' id='ItemNum' value={$k}></div>";
	echo "<input type='hidden' id='PrintList' name='PrintList' value=''>";

	$nobill = getOption('nobill',$con);
	if($nobill=='') $nobill=0;

	echo "<input type='hidden' name='nobill' id='nobill' value={$nobill}>";

	//结算货币
	echo "<input type='hidden' id='hb' name='hb' value={$curency}>";
	//过期折扣
	echo "<input type='hidden' id='discount' name='discount' value={$discount}>";
	//报表标题
	echo "<input type='hidden' id='Department' name='Department' value={$_SESSION['zy_depart_name']}>";
	//报表页脚
	echo "<input type='hidden' id='Footer' name='Footer' value={$_SESSION['zy_depart_name']}>";
	$rate = getOptionDepart('exRate',$con);
	if($rate=='') $rate=1;

	//当月汇率
	echo "<input type='hidden' id='rate' name='rate' value={$rate}>";
	//当前库房名称
	echo "<input type='hidden' id='StationName' name='StationName' value={$_SESSION['zy_station_name']}>";
	mysqli_close($con);

	if(USE_MEMO)
		$cols=10;
	else
		$cols=9;

	if($_SESSION['zy_user']=='馆员')
		echo "<tr height = 40><td colspan = {$cols}>注：打印申请单时<font color=blue>选择不打页眉、页脚</font>，找库管员打印出库领物单</td>";
	else
		echo "<tr height = 40><td colspan = {$cols}>注：打印领物单时<font color=blue>选择不打页眉、页脚</font>，会计、领导签批(交费)后，找库管员领取</td>";

	include_once "include/slider.php";
?>
</tr></table></form><br><br>
</div>
<script language="JavaScript">
	function getCheckoutNum(fruitTotal)
	{
		var k=0;
		var str='<table border=0 width=70%>';
		var slider=document.getElementById("slider");
		fruitTotal.forEach(item => {
			if( item.total>0)
			{
				if(k==maxLine)
				{
					slider.style.height=window.innerHeight+"px";
				}
				else if(k<maxLine)
				{
					slider.style.height="auto";
				}
				str =str +  "<tr height='24px;' style='color:white;'><td>"+(k+1)+'.'+decodeURIComponent(item.name)+ '</td><td>'+item.total+'</td></tr>';
				++k;
			}
			});

		var title ="<br><center><font color=yellow><h3>";
		var info='';
		if(document.getElementById('purpose').value=='物品移库')
		{
			title = title + '待移往<font color=white><b>'+getTargetName()+'</b></font>物品明细';
		}
		else
		{
			title = title + "欲申领物品数量明细";
		}
		title = title+"</h3></font><center>";
		if( k>0 )
		{
			str = str+"<tr height=32px><td colspan=2 align=right><font color=yellow>共 <font color=white>"+k+"</font> 种 <font color=white>"+document.getElementById('goods').value+"</font> 件</font></td></tr>";
			str = str+"</table><table width=72%>"+document.getElementById('curency').value+"</table>";
		}
		else
		{
			str = "还未输入出库物品数量<br><br>";
		}
		if(document.getElementById('goods').value>0)
		{
			url="　　<input type='button' id='btnCheckoutSubmit' onclick=MakeTable(<?php echo ($_SESSION['zy_user']=='库管员'?0:1);echo ','.$page[0].','.$page[1].','.$page[2].','.$doublePrint.',\"'.$curency.'\"';?>) value=' 无误继续 '>";
		}
		else
			url='';

		slider.innerHTML=title+str+"<br><center><input type='button' onclick=hand2() value=' 返回编辑 '>"+url+"</center><br>";
	}
	EventUtil.addHandler(hideit,'click',hand);
	getPurpose(0);
	updateTotal();
</script>
<?php
echo "</body></html>";
?>

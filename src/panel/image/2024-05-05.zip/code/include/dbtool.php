<?php
include_once "const.php";
function logInfoDbase($con,$act)
{
	$time = date("Y-m-d H:i:s");
	$sql="insert into audit values(0,{$_SESSION['zy_admin_id']},'{$act}','{$time}',{$_SESSION['zy_depart_id']},{$_SESSION['zy_station_id']})";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		logInfo(mysqli_error($con));
	}
}
function getWaitImportList($con,$task_id)
{
	$xls_mode = $_SESSION['ajaxInputXls'];
	$pstr= "<table width=96% align='center' style='text-align:center;border-collapse:collapse;border:1px solid #c0c0c0' border='1'>";
	$pstr.= "<tr height=36px align='center' bgcolor=#e0e0e0>";
	$pstr.= "<td>序号</a>";
	$pstr.= "<td title='点物品名查详细'>名称</td>";
	$pstr.= "<td>品牌</td>";
	$pstr.= "<td>规格型号</td>";
	$pstr.= "<td>数量</td>";
	$pstr.= "<td>单位</td>";
	$pstr.= "<td>单价<br>(外币)</td>";
	$pstr.= "<td>外币<br>币种</td>";
	$pstr.= "<td>外币<br>比价</td>";
	$pstr.= "<td>单价<br>(人民币)</td>";

	$pstr.= "<td>采购日期</td>";
	$pstr.= "<td>过期日期</td>";
	if($xls_mode)
		$str='选择';
	else
		$str='编辑';

	$pstr.= "<td>{$str}<input  type='checkbox' id='chkAll' onclick='return checkAll();'/></td>";
	$pstr.= "</tr>";
	$k = 0;

	$sql = "select a.id as id,a.task_id as task_id,b.name as name,b.dep_id as dep_id,b.st_id as st_id,a.sp_id as sp_id,a.brand as brand,a.model as model,a.jiage as jiage,a.jiage_other as jiage_other,a.jiage2 as jiage2,a.curency as curency,a.rate as rate,a.unit as unit,a.shuliang2 as shuliang2,a.box as box,a.orderDate as date,a.date2 as date2,a.madeDate as madeDate,a.source as source,a.orderBill as orderNo,a.memo as memo from waitimport a inner join zy_spxinxi b on a.sp_id = b.id where a.st_id={$_SESSION['zy_station_id']} and b.st_id={$_SESSION['zy_station_id']} ";

	if($task_id==0||$task_id=='')
	{//新增的入库
		$task_id=0;
		$sql.=" and a.task_id not in (select p.task_id from permittask p where p.st_id={$_SESSION['zy_station_id']} and p.permited!=7)";
	}
	else
	{//编辑退回申请
		$sql.=" and a.task_id={$task_id}";
	}

	if(!$xls_mode )
	{
		$sql .= " order by id desc";
	}
//logInfo($sql);
	$k=0;
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	$orderno='';
	$pstr.= "<!--startprint-->";
	if($result)
	{
		$waitnum = mysqli_num_rows($result);
		if($xls_mode)//xls
			$k=1;
		else
			$k=$waitnum;
		$amount=0;
		$k2=0;
		$once=0;
		$empty=1;
		while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			if($once==0)
			{
				$task_id=$row['task_id'];
				$once=1;
				$empty=0;
			}
			if($orderno=='')
				$orderno = $row['orderNo'];
			if(!$xls_mode)
			{
				++$k2;
				$pstr.= "<tr height=36px><td>{$k}<input type='hidden' id={$k2}></td><td>";
			}
			else
			{
				$pstr.= "<tr height=36px;><td>{$k}</td><td>";
			}
			//$query=$_SERVER['QUERY_STRING']==''?"":"?{$_SERVER['QUERY_STRING']}";
			//$web = urlencode($query);

			//$url=$xls_mode?'ruku_xls.php':'ruku.php';
			//$str = sprintf("<a onclick='ShowIt(1)' href='rukujilu.php?p=1&pn=100&id=%d&url={$url}%s'><font color=maroon>%s</font></a>",$row['sp_id'],$web,$row['name']);
			//$pstr.= $str;
			$pstr.=$row['name'];
			$pstr.= "</td>";
			$pstr.= "<td>".$row['brand']."</td>";
			$pstr.= "<td>".$row['model']."</td>";
			$str = intval($row['shuliang2']);
			if($str!=$row['shuliang2']) $str=$row['shuliang2'];
			$pstr.= "<td>".$str."</td>";
			$pstr.= "<td>".$row['unit']."</td>";

			$price_last =$row['jiage_other']+round($row['jiage2']/$row['shuliang2'],2);
			if($row['curency']=='人民币')
			{
				$pstr.= "<td>-</td>";
				$pstr.= "<td>-</td>";
				$pstr.= "<td>-</td>";
				$pstr.= "<td>".number_format($price_last,2)."</td>";
			}
			else
			{
				$pstr.= "<td>".number_format($price_last,2)."</td>";
				$pstr.= "<td>".$row['curency']."</td>";
				$pstr.= "<td>".$row['rate']."</td>";
				$pstr.= "<td>".number_format($price_last*$row['rate'],2)."</td>";
			}

			$pstr.= "<td>".$row['date']."</td>";
			$pstr.= "<td>".$row['date2']."</td><td align=center>";

			$m=$xls_mode?$k:$k2;
			if(!$xls_mode)
			{
				$price = $row['jiage_other'];
				$brand = str_replace("'","\\'",$row['brand']);
				$model = str_replace("'","\\'",$row['model']);

				$str = sprintf("'%s','%s','%s',%d,'%s',%f,%f,'%s','%s','%s','%s','%s','%s','%s',%f",$row['name'],rawurlencode($brand), rawurlencode($model),$row['shuliang2'], rawurlencode($row['unit']),$price,$row['jiage2'],$row['source'], rawurlencode($row['box']),$row['madeDate'],$row['date'],$row['date2'], rawurlencode($row['memo']),$row['curency'],$row['rate']);
				$pstr.= "<a style='cursor: pointer;' onclick=ajaxEditInfo({$row['id']},{$row['st_id']},{$str})><font color=blue>编辑</font> ";
			}
			$pstr.="<a style='cursor: pointer;' onclick='ajaxRemove({$row['id']},{$row['st_id']},{$row['task_id']})'><font color=blue>移除</font></a><input type='checkbox' name='waitImport'/><input type='hidden' id='waitImport{$m}' value={$row['id']} /></td>";
			$pstr.= "</tr>";
			if($xls_mode)
				++$k;
			else
				--$k;
		}
	}
	if($empty)
	{
		$str = $xls_mode?'批量导入':'录入';
		$pstr.= "<tr height=84px><td colspan=13><font color=gray>等待{$str}物品信息</font></td></tr>";
	}
	$pstr.= "<!--endprint--></table><br>";
	$pstr.= "<input type='hidden' size=1 id ='waitnum' name='waitnum' value={$waitnum}>";
	$str = number_format($amount,2);
	$pstr.= "<input type='hidden' size=1 id ='totalmoney' name='totalmoney' value={$str}>";
	$pstr.= "<input type='hidden' size=1 id ='depart_name' name='depart_name' value='{$_SESSION['zy_depart_name']}'>";
	$pstr.= "<input type='hidden' size=1 id ='station_name' name='station_name' value='{$_SESSION['zy_station_name']}'>";
	if($result) mysqli_free_result($result);

	if($xls_mode)
		$pstr.="<script>document.getElementById('task_id_xls').value='{$task_id}';</script>";
	if( $orderno!='')
		$pstr.="<script>document.getElementById('orderBill').value='{$orderno}';</script>";

	$pstr.="<script>document.getElementById('task_id').value='{$task_id}';</script>";

	$ret = array();
	if($empty) $task_id=0;
	$ret['task_id']=$task_id;
	$ret['info']=$pstr;
	$ret['orderBill']=$orderno;

	return $ret;
}
function logInfo($info)
{
	$path = $_SERVER['PHP_SELF'];
	if( strncmp($path,'/code/inc',9)==0 )
	{//从include中调用
		$file='../../data/error_log.txt';
	}
	else if(strncmp($path,'/code/template',14)==0)
	{//从template中调用
		$file='../../data/error_log.txt';
	}
	else
	{//从code中调用
		$file='../data/error_log.txt';
	}
	$str = '时间：'.date("Y-m-d H:i:s")."\r\n" ;
	$str.= '数据库：'.$_SESSION['zy_dbase']."\r\n" ;
	$str.= "单位：{$_SESSION['zy_depart_name']}({$_SESSION['zy_depart_id']})_{$_SESSION['zy_station_name']}({$_SESSION['zy_station_id']})({$_SESSION['zy_dbase']})\r\n";
	$str.= "用户：{$_SESSION['zy_user']}({$_SESSION['zy_admin_id']})\r\n";
	$str.= "文件：{$path}\r\n信息：{$info}\r\n\r\n";
	if( $_SESSION['winOs']==1 ) $file= iconv("UTF-8", "GB2312//IGNORE",$file);
	file_put_contents($file, $str, FILE_APPEND);
}
function encodeURI($str)
{
	$revert = array('%21'=>'!', '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')');
	return strtr(rawurlencode($str), $revert);
}
function ReloadList($con,$st_id=-1)
{//为selectPage重新加载数据列表
	if($st_id==-1||$st_id=='') $st_id= $_SESSION['zy_station_id'];
	$sql= "select id,name from zy_spxinxi where st_id={$st_id} order by CONVERT(name using gbk)";
	$result = mysqli_query($con,$sql);
	$first = 1;
	$str ='';

	if($result)
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		if($first===0)
			$str .= ",\r\n";
		else
			$first = 0;
		$str .= "{\r\n";
		$str .= "  id : ". $row['id'].",\r\n";
		$str .= "  name : '". $row['name']."'\r\n";
		$str .= " }\r\n";
	}
	if($result) mysqli_free_result($result);
	return $str;
}
function GetExtraNum($sp_id,$table,$con=-1,$dep_id=-1,$st_id=-1)
{//统计申请出库表中指定商品数量
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}
	if($table=='expire')
		$sql = "select sum(shuliang) as num from `{$table}` where st_id={$st_id} and sp_id='{$sp_id}'";
	else
		$sql = "select sum(amount) as num from `{$table}` where st_id={$st_id} and sp_id='{$sp_id}'";

	$sql.=" lock in share mode";
	mysqli_query($con,"start transaction");
	$result = mysqli_query($con,$sql);
	 $num = mysqli_num_rows($result);
	 if($num>0)
	 {
		 $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		 $num = $row['num'];
	 }
	 mysqli_query($con,"commit");
	 if($result) mysqli_free_result($result);
	 if($local) mysqli_close($con);
	 return $num;
}

function MakeTransTable($firstPage,$otherPage,$trans=1,$con=-1,$dep_id=-1,$st_id=-1)
{//库存详单表
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];

	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}
	$NewPage = "<div style='page-break-after:always'></div>";
	$table = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>";
	$table_noborder= "<table width = '848px' align='center' style=' text-align:center;' cellpadding='0' cellspacing='0' border='0' bordercolor='#c0c0c0' >";
	$title = "<tr bgcolor=#f0f0f0 height='36px' align='center'><td><b>序号</b></td><td><b>名称</b></td><td><b>品牌</b></td><td><b>规格型号</b></td><td><b>单价</b></td><td><b>库存数量</b></td><td><b>单位</b></td><td><b>过期日期</b></td><td><b>存放位置</b></td></tr>";
	$tail = "<tr height=48><td align='left' width=32%>移交人：</td><td align='left' width=32%>接收人：</td><td align='left'>监交人：<font color=gray>(会计主管或会计)</font></td></tr></table>";

	$amount =0;
	$pstr = $table_noborder;
	$pstr = $pstr . "<tr height='20px;' algin='left'>";
	if($trans==1)
		$pstr = $pstr . "<br><center><b><h3>{$_SESSION['zy_station_name']} 库房移交物品详表</h3></b></tr>";
	else
		$pstr = $pstr . "<br><center><b><h3>{$_SESSION['zy_station_name']} 库房物品详表（供盘点用）</h3></b></tr>";
	date_default_timezone_set("PRC");
	$str = date('Y-m-d');

	$item = $trans==1?"移交日期":"制表日期";
	$pstr = $pstr . "<tr><td align=left>单位：".$_SESSION['zy_depart_name']."</td><td align=center>金额合计：@@AMOUNT@@ 元 (人民币)</td><td align='right'>{$item}：{$str}</td></tr>";
	$pstr = $pstr . "</table>";
	$pstr = $pstr . $table;
	$pstr = $pstr . $title;

	$i=0;
	$k=0; //第一页
	$n=0;
	$m=0;
	$limit = getOptionPortal('maxLimits');
	if($limit==''||$limit==0) $limit = 4096;
	set_time_limit(0);
	mysqli_query($con,"start transaction");
	//创建临时表
	$tableName = "zy_{$_SESSION['zy_depart_id']}_{$_SESSION['zy_station_id']}_{$_SESSION['zy_admin_id']}_transfer";
	$fields="id,sp_id,brand,model,jiage,shuliang,unit,date2,box,st_id";
	$sql = "create temporary table `{$tableName}` as select {$fields} from zy_spruku where st_id={$st_id} limit {$limit}";

	$errLog='../../data/error_log.txt';
	if( $_SESSION['winOs']==1 )
	$errLog= iconv("UTF-8", "GB2312//IGNORE",$errLog);

	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		file_put_contents($errLog, $str, FILE_APPEND);
		mysqli_close($con);
		echo $str;
		exit;
	}
	//@note maketranstable
	//将等待出库表waithandlelist中所有数据叠加到transfer中,但不更新库存表
	remitData(-1,0,$tableName,$con,$dep_id,$st_id);
	$fields="x.name as name,t.st_id as st_id,sp_id,brand,model,jiage,shuliang,unit,date2,box";
	$sql = "select {$fields} from `{$tableName}` t inner join zy_spxinxi x on t.sp_id=x.id where t.st_id={$st_id} and x.st_id={$st_id} and shuliang>0 order by t.sp_id limit {$limit}";
	//order by convert(x.name using GBK)";

	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		file_put_contents($errLog, $str, FILE_APPEND);
		mysqli_close($con);
		echo $str;
		exit;
	}
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		if( $k==0 )
		{//第一页
			 if( $i == $firstPage )
			 {//第一页满
			 	$i=0;
			 	$k=1;
				$pstr = $pstr . "</table>";
				$pstr = $pstr .$NewPage. "<br><br>";
				$pstr = $pstr . $table;
				$pstr = $pstr . $title;
			 }
		}
		else if( $i==$otherPage )
		{//第二及后面页满
				$i=0;
				$pstr = $pstr . "</table>";
				$pstr = $pstr .$NewPage. "<br><br>" ;
				$pstr = $pstr . $table;
				$pstr = $pstr . $title;
		}

		++$i;
		++$n;
		$pstr = $pstr .  "<tr bgcolor=white height=36px;>";
		$pstr = $pstr .  "<td>$n</td>";
		$pstr = $pstr .  "<td align=left>　{$row['name']}</td>";
		$pstr = $pstr .  "<td>{$row['brand']}</td>";
		$pstr = $pstr .  "<td>{$row['model']}</td>";
		$pstr = $pstr .  "<td>{$row['jiage']}</td>";

		$str = intval($row['shuliang']);
		if( $str != $row['shuliang'] ) $str=$row['shuliang'];
		$pstr = $pstr .  "<td>{$str}</td>";
		$pstr = $pstr .  "<td>{$row['unit']}</td>";

		$money = round($row['shuliang']*$row['jiage'],2);
		$amount +=$money;
		$money = number_format($money,2,".",",");
		$pstr = $pstr .  "<td>{$row['date2']}</td>";
		$pstr = $pstr .  "<td>{$row['box']}</td>";
		$pstr = $pstr .  "</tr>";
	}

	set_time_limit(30);
	mysqli_query($con,"commit");
 	$pstr = $pstr . "</table>";
	$amount = number_format($amount,2,".",",");
 	$pstr = str_replace("@@AMOUNT@@",$amount,$pstr);
	 if($trans==1)
	 {
		$pstr = $pstr . $table_noborder;
		$pstr = $pstr . $tail;
	}
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);

	return $pstr;
}

function getItemStockDetail($sp_id,$con=-1)
{
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_error($con));
		$local=true;
	}
	$show_png='';
	$img_click='';
	$img_hint="♻未上传图片";
	$img_cursor='point';
	//上传缩略图的宽度
	$bmp_size = getOptionPortal('bmp_size_width');
	if($bmp_size=='')
	{
		$bmp_size=192;
		updateOptionPortal('bmp_size_width',$bmp_size,$con);
	}
	if( getOption('thumbnail',$con)==1 )
	{
		if($_SESSION['zy_user']=='库管员')
		{
			$img_hint="♻点击更换图片";
			$img_cursor='cursor:hand;';
			$show_png = "<td>图片<span style='color:grey;cursor:pointer;' onclick=alert('点击图片更换、上传物品缩略图')>✤</span></td>";
		}
		else
		{
			$show_png = "<td>图片</td>";
		}
	}

	$table = "<table width =92% align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>";
	$head="<tr height=32px bgcolor=#ffffe8><td>序号</td>{$show_png}<td>品牌</td><td>型号</td><td>库存</td><td>单位</td><td>存放位置</td><td>经手人</td><td>采购日期</td><td>入库日期</td><td>过期日期</td></tr>";
	$sql="select x.name as name,r.id,r.brand,r.model,r.unit,r.shuliang,r.date2,r.box,r.operator,r.date,r.orderDate from zy_spruku r inner join zy_spxinxi x on r.sp_id=x.id where x.id={$sp_id} and r.st_id={$_SESSION['zy_station_id']} and x.st_id={$_SESSION['zy_station_id']} and r.shuliang>0 order by r.date2 limit 32";

	$sp_name=$sp_id;
	$result=mysqli_query($con,$sql);
	$i=0;
	$pstr= $table.$head;
	$today = date('Y-m-d');
	$row_height=48;

	while($row=mysqli_fetch_object($result))
	{
		++$i;
		if($i==1) $sp_name=$row->name;
		$shuliang = intval($row->shuliang);
		if($shuliang!=$row->shuliang) $shuliang=$row->shuliang;

		if($row->date2<$today)
			$date_color='red';
		else
			$date_color='grey';

		if($show_png!='')
		{
			$bmp_file="../../gallery/{$_SESSION['zy_dbase']}/{$_SESSION['zy_depart_id']}/{$_SESSION['zy_station_id']}_{$row->id}.jpg";
			if($_SESSION['zy_user']=='库管员')
			{
				$img_click="onclick=Thumb('{$_SESSION['zy_dbase']}',{$_SESSION['zy_depart_id']},{$_SESSION['zy_station_id']},{$row->id},{$sp_id},{$bmp_size},";
			}

			if(file_exists($bmp_file))
			{
				if($img_click!='') $img_click.="1)";
				$img="<td><div id='thumb{$row->id}'><img {$img_click} src='{$bmp_file}?".rand(0,1000)."' style='width:64px;height:{$row_height}px;img-align:middle;{$img_cursor}' title='{$img_hint}'></div></td>";
			}
			else
			{
				if($img_click!='') $img_click.="0)";
				//$img="<td><div id='thumb{$row->id}'><img {$img_click} src='../../gallery/link_break.png?8' style='width:24px;height:24px;img-align:middle;{$img_cursor}' {$img_hint}>♻选择上传图片</div></td>";
				$img="<td><div id='thumb{$row->id}'><img {$img_click} src='../../gallery/none.png?8' style='cursor:hand;display:none'><span {$img_click} style='{$img_cursor}'>{$img_hint}</span></div></td>";
			}
		}
		else
		{
			$img='';
		}
		$pstr.="<tr style='height:{$row_height}px;color:grey;'><td><span style='valign=middle;text-algin:center;'>{$i}</span></td>{$img}<td style='color:black;'>{$row->brand}</td><td>{$row->model}</td><td style='color:blue;'>{$shuliang}</td><td>{$row->unit}</td><td>$row->box</td><td>{$row->operator}<td>{$row->orderDate}</td><td>{$row->date}</td><td style='color:{$date_color};'>{$row->date2}</td></tr>";
	}

	$title="<div class='close'><span onclick='showStationWindow(0);document.getElementById(\"seek\").focus();' style='font-size:16px;'>✕</span></div>";
	$title .= "<br><center><span style='font-family:微软雅黑;color:black;font-size:16px;font-weight:600;'>物品 {$sp_name} 库存详情表</span><span style='color:grey;font-size:14px;'>(按Esc返回)</span></center><br>";
	$pstr = $title.$pstr;
	if($i==0)
	{
		$pstr.="<tr height=72px><td colspan=7>物品无库存</td></tr>";
	}
	$pstr.="</table><br></br><br>";
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
	return $pstr;
}

function MakeStockTable($firstPage,$otherPage,$stocklist=0,$con=-1,$dep_id=-1,$st_id=-1)
{//生成库存表（打印当前库存表stacklist=1)
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_error($con));
		$local=true;
	}
	$NewPage = "<div style='page-break-after:always'></div>";
	$table = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>";
	$table_noborder= "<table width = '848px' align='center' style=' text-align:center;' cellpadding='0' cellspacing='0' border='0' bordercolor='#c0c0c0'>";
	$tail = "<tr height=48><td align='left' width=32%>移交人：</td><td align='left' width=32%>接收人：</td><td align='left'>监交人：<font color=gray>(会计主管或会计)</font></td></tr></table>";
	$tail2 = "<tr height='20px'><td align=left>单位：".$_SESSION['zy_depart_name']."</td><td align='right'>移交日期：</td></tr></table>";
	$monthNow = date('n');
	$title = "<tr height='36px' align='center' bgcolor=#f1f1f1><td><b>序号</b></td><td><b>物品名称</b></td><td><b>当前库存</b></td>";
	for($i=1;$i<$monthNow;$i++)
		$title .= "<td>{$i}月底</td>";
	$yearNow=date('Y')-1;
	for(;$i<=12;$i++)
		$title .= "<td>{$yearNow}年<br>{$i}月底</td>";
	$webstr = $table_noborder;
	if($stocklist==0)
		$webstr.="<tr><td colspan=2><h3>{$_SESSION['zy_depart_name']} {$_SESSION['zy_station_name']}库房移交表</h3></td></tr>";
	else
		$webstr.="<tr><td><h3>{$_SESSION['zy_depart_name']} {$_SESSION['zy_station_name']}库存表</h3></td></tr>";

	date_default_timezone_set("PRC");
	$str = date('Y-m-d');
	if($stocklist==0)
		$webstr .= "<tr height='20px'><td align=left>单位：".$_SESSION['zy_depart_name']."</td><td align='right'>移交日期：{$str}</td></tr>";
	else
		$webstr .= "<tr height='20px'><td align=right>日期：{$str}</td></tr>";

	$webstr .= "</table>";
	$webstr.= $table;
	$webstr.= $title;
	$i=0;
	$k=0; //第一页
	$n=0;
	$m=0;

	$sql="select r.sp_id as sp_id,x.name as name,r.kucun as kucun,r.kucun1 as kucun1,r.kucun2 as kucun2,r.kucun3 as kucun3,r.kucun4 as kucun4,r.kucun5 as kucun5,r.kucun6 as kucun6,r.kucun7 as kucun7,r.kucun8 as kucun8,r.kucun9 as kucun9,r.kucun10 as kucun10,r.kucun11 as kucun11,r.kucun12 as kucun12 from zy_spkucun r inner join zy_spxinxi x on r.sp_id=x.id where r.st_id={$st_id} and x.st_id={$st_id} and r.kucun>0 order by r.sp_id";//convert(name using GBK)";
	$result = mysqli_query($con,$sql);
	if( !$result ) echo $sql.' : '.mysqli_error($con).'<br>';
	$num=mysqli_num_rows($result);
	while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		if( $k==0 )
		{//第一页
			 if( $i == $firstPage )
			 {//第一页满
			 	$i=0;
			 	$k=1;
				$webstr = $webstr . "</table>";
				if($stocklist==0)
				{
					$webstr = $webstr . $table_noborder;
					//$webstr = $webstr . $tail;
				}
				$webstr = $webstr .$NewPage. "<br><br>";
				$webstr = $webstr . $table;
				$webstr = $webstr . $title;
			 }
		}
		else if( $i==$otherPage )
		{//第二及后面页满
			$i=0;
			$webstr = $webstr . "</table>";
			if($stocklist==0)
			{
				$webstr = $webstr . $table_noborder;
				//$webstr = $webstr . $tail;
			}
			$webstr = $webstr .$NewPage. "<br><br>" ;
			$webstr = $webstr . $table;
			$webstr = $webstr . $title;
		}
		++$i;
		++$n;
		$webstr .= "<tr height='36px;' align='center'>";
		$webstr .= "<td>{$n}</td>";
		$webstr .= "<td align=left>　{$row['name']}</td>";

		$waitNum = GetExtraNum($row['sp_id'],'waithandlelist',$con,$dep_id,$st_id);
		$kucun = $row['kucun'] + $waitNum;
		$str = intval($kucun);
		if($str!=$kucun) $str=$kucun;
		$webstr .= "<td>{$str}</td>";

		for($d=1;$d<13;$d++)
		{
			$str = intval($row['kucun'.$d]);
			if($str!=$row['kucun'.$d]) $str=$row['kucun'.$d];
			$webstr .= "<td>{$str}</td>";
		}
		$webstr .= "</tr>";
	}
	if($n==0)
	{
		$webstr .= "<tr height='136px;' align='center'>";
		$webstr .= "<td colspan=15>没有数据</td></tr>";
	}
	$webstr.= "</table>";
	if($stocklist==0)
		$webstr.=$table_noborder.$tail.$NewPage;
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
	return $webstr;
}
function getPageSize($tableType,$ItemNum=0,$paperMode=PAPER_SYSTEM)
{//默认横向
	if($paperMode==PAPER_SYSTEM)
	{
		$paperLayout = getOptionDepart('paperLayout');
		$paperLayout = $paperLayout==''?1:$paperLayout;
	}
	else if($paperMode==PAPER_FORCE_LANDSCAPE)
		$paperLayout=1;
	else
		$paperLayout=0;

	$pageSize = array();
	switch($tableType)
	{
		case TABLE_IMPORT://物品入库
			$paperLayout=1;//强制横向
			$pageSize[0] = $paperLayout==1?11:24;
			$pageSize[1] = $paperLayout==1?15:29;
			break;
		case TABLE_CHECKOUT://物品出库
			$pageSize[0] = $paperLayout==1?13:26;
			$pageSize[1] = $paperLayout==1?17:31;
			break;
		case TABLE_QUERY_IMPORT://入库查询报表
			$pageSize[0] = $paperLayout==1?16:29;
			$pageSize[1] = $paperLayout==1?17:30;
			break;
		case TABLE_QUERY_CHECKOUT://出库查询报表
			$pageSize[0] = $paperLayout==1?17:29;
			$pageSize[1] = $paperLayout==1?18:30;
			break;
		case TABLE_TRANSFORM://库房移交
		 	$paperLayout=0;//强制竖版
			$pageSize[0] = $paperLayout==1?16:29;
			$pageSize[1] = $paperLayout==1?16:30;
			break;
		case TABLE_MONTH_CHECK://月度盘点
		 	$paperLayout=0;//强制竖版
			$pageSize[0] = $paperLayout==1?12:27;
			$pageSize[1] = $paperLayout==1?15:29;
			break;
		case TABLE_APPLY://馆员申请
			$pageSize[0] = $paperLayout==1?11:24;
			$pageSize[1] = $paperLayout==1?15:29;
			break;
		case TABLE_MONTH_VERIFY://盘点校验
			$pageSize[0] = $paperLayout==1?13:28;
			$pageSize[1] = $paperLayout==1?16:30;
			break;
		case TABLE_EXPIRE://将过期物品表
			$pageSize[0] = $paperLayout==1?15:29;
			$pageSize[1] = $paperLayout==1?17:30;
			break;
		default:
			$pageSize[0] = $paperLayout==1?13:28;
			$pageSize[1] = $paperLayout==1?16:30;
			break;
	}
	$pageSize[2]=0;
	if($ItemNum>0)
	{//计算总页数并存于$pageSize[2]中
		if( $ItemNum<=$pageSize[0])
		{
			$pageSize[2] = 1;
		}
		else if( $ItemNum - $pageSize[0] +1 <= $pageSize[0])
		{//加1行是签名行，有些没签名也不单独处理了
			$pageSize[2] = 2;
		}
		else
		{
			$pageSize[2] = intval(($ItemNum - $pageSize[0])/$pageSize[1])+1;//+1是首页
			++$pageSize[2]; //如果没有满页，上面的除法去掉1行需加上
		}
	}
	return $pageSize;
}
function makeCodebar($pt_id,$FileName)
{
	if($pt_id=='') return false;
	if( $_SESSION["winOs"]==1 )
	{
		$FileName= iconv("UTF-8", "GB2312//IGNORE",$FileName);
	}
	if (is_file ($FileName))
	{
		unlink ($FileName); //存在，就删除
	}

	// Including all required classes
	require_once('../../Classes/barcode/BCGFontFile.php');
	require_once('../../Classes/barcode/BCGColor.php');
	require_once('../../Classes/barcode/BCGDrawing.php');

	// Including the barcode technology
	require_once('../../Classes/barcode/BCGcode39.barcode.php');

	// Loading Font
	$font = new BCGFontFile('../../Classes/barcode/font/Arial.ttf', 12);

	// Don't forget to sanitize user inputs
	$text = $pt_id;

	// The arguments are R, G, B for color.
	$color_black = new BCGColor(0, 0, 0);
	$color_white = new BCGColor(255, 255, 255);

	$drawException = null;
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	try {
	    $code = new BCGcode39();
	    $code->setScale(1); // Resolution
	    $code->setThickness(30); // Thickness
	    $code->setForegroundColor($color_black); // Color of bars
	    $code->setBackgroundColor($color_white); // Color of spaces
	    $code->setFont($font); // Font (or 0)
	    $code->parse($text); // Text
	} catch(Exception $exception) {
	    $drawException = $exception;
	}

	/* Here is the list of the arguments
	1 - Filename (empty : display on screen)
	2 - Background color */
	$drawing = new BCGDrawing($FileName, $color_white);
	if($drawException) {
	    $drawing->drawException($drawException);
	} else {
	    $drawing->setBarcode($code);
	    $drawing->draw();
	}

	// Draw (or save) the image into PNG format.
	$drawing->finish(BCGDrawing::IMG_FORMAT_PNG);
	return true;
}
function download($file_name,$save_name)
{
	//以只读和二进制模式打开文件
	$file = fopen ( "{$file_name}", "rb" );
	//这是一个文件流格式的文件
	Header ( "Content-type: application/octet-stream" );
	//请求范围的度量单位--字节
	Header ( "Accept-Ranges: bytes" );
	//Content-Length是指定包含于请求或响应中数据的字节长度
	Header ( "Accept-Length: " . filesize (  "{$file_name}" ) );
	//用来告诉浏览器，文件是可以当做附件被下载，下载后的文件名称为$save_name该变量的值。
	if($save_name=='') $save_name=$file_name;
	Header ( "Content-Disposition: attachment; filename=" . $save_name );
	header("Access-Control-Allow-Origin: *"); // 允许任意域名发起的跨域请求
	//读取文件内容并直接输出到浏览器
	echo fread ( $file, filesize ( "{$file_name}" ) );
	fclose ( $file );
}

function is_utf8($string)
{
    return preg_match('%^(?:
          [\x09\x0A\x0D\x20-\x7E]            # ASCII
        | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
        |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
        | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
        |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
        |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
        | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
        |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
    )*$%xs', $string);
}

function switchStation($st_id)
{//切换用户正在操作的库房
	session_start();
	$path = $_SERVER['PHP_SELF'];
	if( strncmp($path,'/code/inc',9)==0)
	{//从include中调用
		include "../conn/conn.php";
	}
	else
	{//从code中调用
		include "conn/conn.php";
	}

	$link=@mysqli_select_db($con,"portal");
	if(!$link)
	{
		die("找不到数据库");
	}
	$GLOBALS['_SESSION']['zy_station_id'] = $st_id;
	mysqli_query($con,"start transaction");
	$sql = "select name,dbase,folder,code_folder from stations where id={$st_id} lock in share mode";
//echo $sql;
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

	$GLOBALS['_SESSION']['zy_station_name'] = $row['name'];
	$GLOBALS['_SESSION']['zy_dbase'] = $row['dbase'];
	$GLOBALS['_SESSION']['zy_folder'] = $row['folder'];
	$GLOBALS['_SESSION']['zy_code_folder'] = $row['code_folder'];
	//切换默认库房
	if($result) mysqli_free_result($result);
	$sql = "update member set st_id={$st_id} where id={$_SESSION['zy_admin_id']}";
	mysqli_query($con,$sql);
	mysqli_query($con,"commit");

}

function toCSV(array $data, array $colHeaders = array(), $asString = false)
{
	$stream = ($asString)? fopen("php://temp/maxmemory", "w+"): fopen("php://output", "w");

	if (!empty($colHeaders))
	{
		fputcsv($stream, $colHeaders);
	}

	foreach ($data as $record)
	{
		fputcsv($stream, $record);
	}

	if ($asString)
	{
		rewind($stream);
		$returnVal = stream_get_contents($stream);
		fclose($stream);
		return $returnVal;
	}
	else
	{
		fclose($stream);
	}
}
function exportCSV($data,$tableheader,$file_name='csv文件.csv')
{
	//$tableheader = array('姓名', '性别', '年龄', '学院', '班级');
	/*表格数据*/
	/*$data = array(
		array('小王', '男', '20', '计算机科学与技术', '1001'),
		array('小王', '男', '20', '计算机科学与技术', '1001'),
		array('小王', '男', '20', '计算机科学与技术', '1001'),
		array('小王', '男', '20', '计算机科学与技术', '1001'),
	);*/
	$tablelength = count($tableheader);

	/*输入到CSV文件 解决乱码问题*/
	$html = "\xEF\xBB\xBF";

	/*输出表头*/
	foreach ($tableheader as $value) {
		$html .= $value . ",";
	}
	$html .= "\r\n";

	/*输出内容*/
	foreach ($data as $value) {
		for ($i = 0; $i < $tablelength; $i++) {
			$html .= $value[$i] . ",";
		}
		$html .= "\r\n";
	}

	/*输出CSV文件*/
	header("Content-type:text/csv");
	header("Content-Disposition:attachment; filename={$file_name}");
	echo $html;
}

function is_date($str_time)
{
	$result = strtotime($str_time);
	if(empty($result))
	{
		try {
		    $date = new DateTime($str_time);
		} catch (Exception $e) {
		    return false;
		}
	}
	return true;
}

function getDefPass($role,$pass_file="password.txt",$local=0)
{//从tools/tempalte/paaword.txt中获取各角色默认口令
	session_start();
	$path = $_SERVER['PHP_SELF'];
	if( strncmp($path,'/code/inc',9)==0 )
	{//从include中调用
	  $file ="../../tools/template/{$pass_file}";
	}
	else if( strncmp($path,'/code/',6)==0 )
	{//从code中调用
		$file ="../tools/template/{$pass_file}";
	}
	else if( strncmp($path,'/tools/login',11)==0 )
	{//从tools中调用
		$file ="template/{$pass_file}";
	}
	else if( strncmp($path,'/tools/temp',10)==0 )
	{//tools/template
		$file =$pass_file;
	}
	else if( strncmp($path,'/tools/',6)==0 )
	{//从tools中调用
		$file ="template/{$pass_file}";
	}
	else
	{//index或login调用，版本信息
		$file ="tools/template/{$pass_file}";
	}

	$pass = '123';
	if(is_file($file))
	{
		$a = file_get_contents($file);
		$data = json_decode($a,true);

		//echo $a."<br>".$role."<br>";
		//var_dump($data);

		if( $data[$role]!="" )
		{
			$pass = $data[$role];
		}
	}
	if($pass_file=='password.txt')
	{
		$str = $pass;
	}
	else
	{
		$str =str_crypt($pass,"DECODE");
	}
	if( $local=='999') MessageBox($str);
	return($str);
}
function setDefPass($role,$new_pass,$pass_file="password.txt")
{
	if($new_pass=='') return 1;
	session_start();
	$path = $_SERVER['PHP_SELF'];
	if( strncmp($path,'/code/inc',9)==0 )
	{//从include中调用
	  $file_name ="../../tools/template/{$pass_file}";
	}
	else if( strncmp($path,'/code/',6)==0 )
	{//从code中调用
		$file_name ="../tools/template/{$pass_file}";
	}
	else if( strncmp($path,'/tools/lo',8)==0 )
	{//从tools中调用
		$file_name ="template/{$pass_file}";
	}
	else
	{//tools/template
		$file_name =$pass_file;
	}

	if( $_SESSION['winOs']==1 ) $file_name= iconv("UTF-8", "GB2312//IGNORE",$file_name);

	$m_pass = $new_pass;
	if($pass_file=="super.txt")
		$m_pass = str_crypt($new_pass);
	if(is_file($file_name))
	{
		$a = file_get_contents($file_name);
		$data = json_decode($a,true);
		if( $data[$role]!="" )
		{
			$data[$role]=$m_pass;
			$b = json_encode($data);
		}
		else
		{
			$b =sprintf('{"%s":"%s",',$role,$m_pass);
			$a[0]='';
			$b.=$a;
		}
	}
	else
	{
		$b =sprintf('{"%s":"%s"}',$role,$m_pass);
	}

	file_put_contents($file_name,$b);
}

function str_crypt($string, $operation = 'ENCODE', $key = 'freeime', $expiry = 0)
{
	$ckey_length = 0;
	// 随机密钥长度 取值 0-32;
	// 加入随机密钥，可以令密文无任何规律，即便是原文和密钥完全相同，加密结果也会每次不同，增大破解难度。
	// 取值越大，密文变动规律越大，密文变化 = 16 的 $ckey_length 次方
	// 当此值为 0 时，则不产生随机密钥

	$key = md5($key ? $key : 'key'); //这里可以填写默认key值
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) :
	substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya . md5($keya . $keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) :sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb),0, 16) . $string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for ($i = 0; $i <= 255; $i++)
	{
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for ($j = $i = 0; $i < 256; $i++)
	{
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for ($a = $j = $i = 0; $i < $string_length; $i++)
	{
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if ($operation == 'DECODE')
	{
		if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) &&
		    substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc . str_replace('=', '', base64_encode($result));
	}
}
function SetPass($userId,$role)
{
	$pass = getDefPass($role);
	$path = $_SERVER['PHP_SELF'];
	if( strncmp($path,'/code/inc',9)==0)
	{//从include中调用
		include "../conn/conn.php";
	}
	else if( strncmp($path,'/tools',6)==0)
	{//从tools/template中调用
		include "../../code/conn/conn.php";
	}
	else
	{//从code中调用
		include "conn/conn.php";
	}

	$sql = "update portal.member set loginpass='{$pass}' where id={$userId}";
	$result = mysqli_query($con,$sql);
	if($result)
	{
		return $pass;
	}
	else
	{
		return false;
	}
	mysqli_close($con);
}
function getUpdateOption($key,$con=-1,$dep_id=-1,$st_id=-1)
{
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	$local=false;
	if($con==-1)
	{
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm",$_SESSION['zy_dbase']);
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}
	mysqli_query($con,"start transaction");
	//锁定当前库所有配置项，独占写
	$sql = "select name from config where st_id={$st_id} limit 1 for update";
	$result = mysqli_query($con,$sql);
	if(strtolower($key)!='billnoyear')
	{
		$sql = "select value from config where st_id={$st_id} and name='{$key}' limit 1";
		$result = mysqli_query($con,$sql);
		if(!$result)
		{
			$value='';
		}
		else
		{
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$value = $row['value'];
		}
	}

 	if($value=='')
	{
		if($key=='applyNoImport')
		{
			$value = (int)sprintf("%d0001",date('Y'));
		}
		else
		{
			$value=1;
		}
	}

	//检查是否跨年了
	$sql = "select value from config where dep_id={$dep_id} and st_id=-1 and name='BillNoYear' limit 1";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$billYear='';
	}
	else
	{
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$billYear = $row['value'];
	}
	if($result) mysqli_free_result($result);

	//每年自动从1重新编号
	if($billYear!=date('Y'))
	{
		$billYear = date('Y');
		updateOptionDepart("BillNoYear","{$billYear}",$con,$dep_id);

		//复位入库申请单号`
		if($key=='applyNoImport')
		{
			$value = (int)sprintf("%d0001",date('Y'));
		}
		else
		{
			//本部门所有库房均自动复位
			$sql = "update config set value=1 where (name='LastInBillNo' or name='LastBillNo' or name='applyNo' ) and  dep_id={$dep_id};";
			$result = mysqli_query($con,$sql);
			if(!$result)
			{
				$str = mysqli_error($con) . "\r\n{$sql}";
				logInfo($str);
				mysqli_close($con);
				echo $str;
				exit;
			}
			$value = 1;
		}
	}

	if(strtolower($key)=='billnoyear')
		$value = $billYear;
	else//在此处更新申请号是为防止并发冲突
		updateOption($key,(int)$value+1,$con,$dep_id,$st_id,1);
		//这块嵌套事务，里层会commit外层并更新

	mysqli_query($con,"commit");
	if($local) mysqli_close($con);

	return $value;
}

function getOptionMember($key,$con=-1,$lockMode='readShare')
{
	$local=false;
	if($con==-1)
	{
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm",$_SESSION['zy_dbase']);
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "select {$key} from portal.member where id={$_SESSION['zy_admin_id']} limit 1";

	if($lockMode=='readShare')
		$sql.=" lock in share mode";
	else
		$sql.=" for update";

//echo $sql."<br>";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		echo mysqli_error($con).'<br';
		$value='';
	}
	else
	{
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$value = $row[$key];
	}
	mysqli_query($con,"commit");
//echo '['.$value.']';
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
	return $value;
}
function updateOptionMember($key,$value,$con=-1)
{//更新系统级
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "update portal.member set {$key}={$value} where id={$_SESSION['zy_admin_id']}";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\nstation:{$_SESSION['$_zy_station_id']} user:{$_SESSION['zy_admin_id']}\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	mysqli_query($con,"commit");
	if($local) mysqli_close($con);
}

function getOption($key,$con=-1,$dep_id=-1,$st_id=-1,$lockMode='readShare')
{
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	$local=false;
	if($con==-1)
	{
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm",$_SESSION['zy_dbase']);
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "select value from config where st_id={$st_id} and name='{$key}' limit 1";

	if($lockMode=='readShare')
		$sql.=" lock in share mode";
	else
		$sql.=" for update";

//echo $sql."<br>";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$value='';
	}
	else
	{
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$value = $row['value'];
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
	return $value;
}
function updateOption($name,$value,$con=-1,$dep_id=-1,$st_id=-1,$transaction=0)
{//更新库房级配置
	$local=false;
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,$dbase);
		if(!$link) die("连接数据库出错：".mysqli_error($con));
		$local=true;
	}

	if($transaction==0)
	mysqli_query($con,"start transaction");
	$sql = "select value from config where name='{$name}' and st_id={$st_id} limit 1 lock in share mode";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	$num = mysqli_num_rows($result);
	if($result) mysqli_free_result($result);

	if($num>0)
		$sql = "update config set value={$value} where name='{$name}' and st_id={$st_id}";
	else
		$sql="insert into config(name,value,dep_id,st_id,memo) values('{$name}',{$value},{$dep_id},{$st_id},'')";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		if($transaction==0)
		mysqli_query($con,"rollback");
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	if($transaction==0)
	mysqli_query($con,"commit");
	if($local) mysqli_close($con);
}

function getOptionPortal($key,$con=-1)
{
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "select value from portal.config where name='{$key}' limit 1 lock in share mode";
	$result = mysqli_query($con,$sql);
	if(!$result) $value='';
	else
	{
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$value = $row['value'];
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);

	return $value;
}
function updateOptionPortal($name,$value,$con=-1)
{//更新系统级
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "select value from portal.config where name='{$name}' limit 1 lock in share mode";
	$result = mysqli_query($con,$sql);
	$num = mysqli_num_rows($result);
	if($num>0)
		$sql = "update portal.config set value={$value} where name='{$name}'";
	else
		$sql="insert into portal.config(name,value,memo) values('{$name}',{$value},'')";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	mysqli_query($con,"commit");
	if($local) mysqli_close($con);
}

function getOptionDepart($key,$con=-1,$dep_id=-1,$st_id=-1,$lockMode='readShare')
{//获取部门级参数
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	$local=false;
	if($con==-1)
	{
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm",$_SESSION['zy_dbase']);
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}
	mysqli_query($con,"start transaction");
	$sql = "select value from config where dep_id={$dep_id} and st_id=-1 and name='{$key}' limit 1";

	if($lockMode=='readShare')
		$sql.=" lock in share mode";
	else
		$sql.=" for update";

	$result = mysqli_query($con,$sql);
	if($result===FALSE)
	{
		$value='';
	}
	else
	{
		$row = mysqli_fetch_object($result);
		$value = $row->value;
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
	return $value;
}

function updateOptionDepart($name,$value,$con=-1,$dep_id=-1)
{//更新部门级配置
	$local=false;
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm","portal");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}

	$sql = "select value from config where name='{$name}' and dep_id=$dep_id and st_id=-1 limit 1 lock in share mode";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}

	$num = mysqli_num_rows($result);
	if($num>0)
		$sql = "update config set value='{$value}' where name='{$name}' and dep_id=$dep_id";
	else
		$sql="insert into config(name,value,dep_id,st_id,memo) values('{$name}','{$value}',{$dep_id},-1,'')";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		$str = date("Y-m-d H:i:s") . "\r\n错误：" . mysqli_error($con) . "\r\n{$sql}\r\n";
		logInfo($str);
		mysqli_close($con);
		echo $str;
		exit;
	}
	mysqli_query($con,"commit");
	if($local) mysqli_close($con);
}

function removeBomUtf8($s)
{
	if( substr($s,0,3)== chr(hexdec("EF")).chr(hexdec("BB")).chr(hexdec("BF")))
	{
		return substr($s,3);
	}
	else
	{
		return $s;
	}
}

function getDiscaredData($con,$print=0)
{
	$width = $print==1?'95%':'75%';
	$title = "<tr bgcolor='#e6e6e6' height='36px;'><td><b>序号</b></td><td><b>物品名称</b></td><td><b>数量</b></td><td><b>单位</b></td><td><b>规格</b></td><td><b>单价</b></td><td><b>总价</b></td><td><b>过期日期</b></td></tr>";
	$table = "<table width={$width} align='center'  style='text-align:center;border-collapse:collapse;' border='1' bordercolor='#c0c0c0'>";
	$table_noborder = "<table width={$width} align='center' style='text-align:center;border-collapse:collapse;' border=0>";
	$newPage = "<div style='page-break-after:always'></div>";

	$pstr = '';
	if($print==1)
	{
		$pstr .=$newPage;
	}
	$pstr.=$table_noborder;
	$pstr.="<tr height=36px><td align=left><span style='color:black;'>下列物品已经过了保质期</span></td></tr></table>";

	$pstr.=$table;
	$pstr.=$title;

	$m=0;
	$c=0;
	$pageNum=1;
	$TotalMoney = 0;
	$TotalOutNum = 0;
	$date2 = date("Y-m-d");

	mysqli_query($con,"start transaction");
	$sql = "select r.id as ruku_id,r.sp_id as sp_id,r.shuliang as shuliang,r.shuliang2 as shuliang2,r.jiage2 as jiage2,r.jiage as jiage,r.date2 as date2,r.model as model,r.unit as unit,x.name as name from zy_spruku r inner join zy_spxinxi x on x.id=r.sp_id where r.st_id={$_SESSION['zy_station_id']} and x.st_id={$_SESSION['zy_station_id']} and date(r.date2)<='{$date2}' and shuliang>0";
//echo $sql;
	$result = mysqli_query($con,$sql);
	$row_num = mysqli_num_rows($result);
	if($print==1)
	$ps= getPageSize(TABLE_EXPIRE,$row_num,PAPER_FORCE_PORTRAIT);
	if( $row_num>0 )
	{
		$i=0;
		while($rs = mysqli_fetch_object($result))
		{
			if($print==1 && ($m==0 && $c==$ps[0]) || ($m==1 && $c==$ps[1]) )
			{
				$m = 1;
				$c = 0;
				++$pageNum;
				if($pageNum<=$ps[2])
				{
					$pstr.= "</table>".$newPage.$table.$title;
				}
			}
			++$i;
			++$c;
			$TotalOutNum +=$rs->shuliang;

			$price = $rs->jiage;
			$Money = $price * $rs->shuliang;
			$TotalMoney += $Money;

			$pstr.= "<tr height='42px;'><td width='60px;'>";
			$pstr.= $i;
			$pstr.= "</td><td>";
			$pstr.= $rs->name;
			$pstr.= "</td><td>";
			$str = intval($rs->shuliang);
			if($str!=$rs->shuliang) $str=$rs->shuliang;
			$pstr.= $str;
			$pstr.= "</td><td>";
			$pstr.= $rs->unit;
			$pstr.= "</td><td>";
			$pstr.= $rs->model;
			$pstr.= "</td><td align=center>";
			$pstr.= number_format($price,2)."　";
			$pstr.= "</td><td align=right>";
			$pstr.= number_format($Money,2)."　";
			$pstr.= "</td><td>";
			$pstr.= $rs->date2;
			$pstr.= "</td></tr>";
		}//end_while
		$TotalMoney = number_format($TotalMoney,2);
		$pstr.= "</table>";
		$pstr.=$table_noborder;
		$pstr.= "<tr height=36px><td align=right><b>合计：</b>{$TotalMoney} 元（人民币）</td></tr></table>";
	}//endif
	else
	{
		$pstr.= "<tr height=128><td colspan=9><font color=gray>库内暂无过期物品</font></td></tr></table>";
	}
	mysqli_query($con,"commit");
	mysqli_free_result($result);
	return $pstr;
}

function getDiscardingData($con,$print=0)
{
	if(isset($_GET['expire']))
	{
		$ms = $_GET['expire'];
	}
	else
	{
		$preWarnMonth = getOptionDepart('preWarnMonth',$con,$_SESSION['zy_depart_id'],$_SESSION['zy_$station_id']);
		if($preWarnMonth == '')
		{
			$preWarnMonth=3;
			updateOptionDepart('preWarnMonth',$preWarnMonth,$con,$_SESSION['zy_depart_id'],$_SESSION['zy_$station_id']);
		}
		$ms = $preWarnMonth;
	}
	if(!is_numeric($ms)) $ms = 3;

	$width = $print==1?'95%':'75%';
	$table = "<table width={$width} align='center' style='text-align:center;border-collapse:collapse;' border='1' bordercolor='#c0c0c0'>";

	$table_noborder = "<table width={$width} align='center' style='text-align:center;border-collapse:collapse;' border='0'>";
	$title = "<tr bgcolor='#e6e6e6' height='36px;'><td><b>序号</b></td><td><b>物品名称</b></td><td><b>数量</b></td><td><b>单位</b></td><td><b>规格</b></td><td><b>单价</b></td><td><b>总价</b></td><td><b>过期日期</b></td></tr>";
	$newPage = "<div style='page-break-after:always'></div>";

	$pstr='';

	$pstr.=$table_noborder;
	$pstr.="<tr height=60px><td align=center colspan=2><h3><span onclick='ajaxGetStations();' style='cursor:pointer;color:maroon;'>{$_SESSION['zy_station_name']}</span><span> 临期物品</span></h3></td></tr>";
	$pstr.="<tr height='38px'>";
	if($print==0)
	{
		$pstr.="<td align=left width=75%><span>下列物品将在<input type='input' id='range' name='range' size=2 value='{$ms}'>个月内过期</span></td>";
		$pstr.="<td algin=right><button onClick='return mfresh()' value='点击查询'>　重新查询　</button> ";
		$pstr.="<button onclick=doPrint() id='btnPrint'>　打印报表　</button></td>";
	}
	else
	{
		$pstr.="<td align=left width=70%>下列物品将在未来{$ms}个月过保质期</td>";
		$pstr.="<input type='hidden' id='range' name='range' value='{$ms}'>";
		$date = date('Y-n-d');
		$pstr.="<td align=right>打印日期：{$date}</td>";
	}
	$pstr.="</tr></table>";

	$pstr.=$table;
	$pstr.=$title;

	$date1 = date("Y-m-d");
	$date2 = date("Y-m-d",strtotime("+{$ms} month"));

	mysqli_query($con,"start transaction");
	$sql = "select k.id as id,r.sp_id as sp_id,r.shuliang as shuliang,r.shuliang2 as shuliang2,r.jiage as jiage,r.jiage2 as jiage2,r.unit as unit,r.model as model,r.date2 as date2 from zy_spkucun k,zy_spruku r where r.st_id={$_SESSION['zy_station_id']} and k.st_id={$_SESSION['zy_station_id']} and r.sp_id=k.sp_id and r.shuliang>0 and r.date2>'{$date1}' and r.date2<='{$date2}' order by r.date2 limit 1024";

	$result = mysqli_query($con,$sql);
	$i=0;
	$m=0;
	$c=0;
	$TotalOutNum=0;
	$TotalMoney=0;
	$pageNum=1;
	$waitnum = mysqli_num_rows($result);

	if($date!='')
	$ps= getPageSize(TABLE_EXPIRE,$waitnum,PAPER_FORCE_PORTRAIT);

	if( $waitnum>0 )
	{
		while ($rs = mysqli_fetch_object($result))
		{
			$sp_id = $rs->sp_id;
			if($date1!='' && ($m==0 && $c==$ps[0]) || ($m==1 && $c==$ps[1]) )
			{
				$m = 1;
				$c = 0;
				++$pageNum;
				if($pageNum<=$ps[2])
				{
					$pstr.= "</table>".$newPage.$table.$title;
				}
			}
			++$i;
			++$c;

			$amount = intval($rs->shuliang);
			if($amount!=$rs->shuliang) $amount=$rs->shuliang;
			$TotalOutNum +=$amount;

			$price = $rs->jiage + $rs->jiage2/$rs->shuliang2;
			$Money = $price * $amount;
			$TotalMoney += $Money;
			$date2 = $rs->date2;

			$sqlSp = "select name from zy_spxinxi where st_id={$_SESSION['zy_station_id']} and id={$sp_id}";
			$resultSp = mysqli_query($con,$sqlSp);
			$rowSp = mysqli_fetch_array($resultSp,MYSQLI_ASSOC);
			$spname = $rowSp['name'];
			$pstr.= "<tr height='36px;'><td width='60px;'>";
			$pstr.= $i;
			$pstr.= "</td><td>";
			$pstr.= $spname."		";
			$pstr.= "</td><td>";

			$pstr.= $amount;
			$pstr.= "</td><td>";

			$pstr.= $rs->unit;
			$pstr.= "</td><td>";
			$pstr.= $rs->model;
			$pstr.= "</td><td align=center>";
			$pstr.= number_format($price,2)."　";
			$pstr.= "</td><td align=right>";
			$pstr.= number_format($Money,2)."　";
			$pstr.= "</td><td>";
			$pstr.= $date2;
			$pstr.= "</td></tr>";
		}//end_while
		$TotalMoney = number_format($TotalMoney,2);
		$pstr.= "</table>";
		$pstr.=$table_noborder;
		$pstr.= "<tr height=36px><td align=right><b>合计：</b>{$TotalMoney} 元（人民币）</td></tr></table>";
	}//endif
	else
	{
		$pstr.= "<tr height=128><td colspan=9><font color=gray>指定时间内无将过期物品</font></td></tr></table>";
	}
	mysqli_query($con,"commit");

	if($result) mysqli_free_result($result);
	return $pstr;
}
function getCsvData($fileName)
{
	if( $_SESSION['winOs']==1 )
	{
		$fileName= iconv("UTF-8", "GB2312//IGNORE",$fileName);
	}

	$str = file_get_contents($fileName);
	$str = removeBomUtf8($str);

	//"1,123,123.45" -> 1123123.45
	$str = preg_replace('/(")(\d+),(\d+),(.*)(")/','${2}${3}${4}',$str);

	//"1,123.45" -> 1123.45
	$str = preg_replace('/(")(\d+),(.*)(")/','${2}${3}',$str);
	$str = str_replace('"""',"\\\"",$str);

	$needle = "\r\n";
	$pos = strpos($str,$needle);
	if($pos==false)
	{
		$needle = "\n";
	}
		

	$da = explode($needle,$str);
	$data = array();
	for($i=0;$i<count($da);$i++)
	{
		if(strlen($da[$i])<4) continue;
		$a = explode(",",$da[$i]);
		$data[]=$a;
	}
	//print_r($data);
	return $data;
}

function remitData($task_id,$updateKucun=1,$target='zy_spruku',$con=-1,$dep_id=-1,$st_id=-1)
{//将待出库数据返回给相关数据表
	if($dep_id==-1) $dep_id=$_SESSION['zy_depart_id'];
	if($st_id==-1) $st_id=$_SESSION['zy_station_id'];
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$dbase}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}
	mysqli_query($con,"START TRANSACTION");
	if($task_id==-1)
		$sql = "select * from waithandlelist where ";
	else
		$sql = "select * from waithandlelist where task_id={$task_id} and ";
	$sql.=" st_id={$st_id} lock in share mode";
	$result = mysqli_query($con,$sql);
	if(!$result)
	{
		logInfo("Error:".mysqli_error($con)."\r\n##{$sql}");
		mysqli_close($con);
		exit;
	}
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		$sp_id =$row['sp_id'];
		$ruku_id = $row['ruku_id'];
		$shuliang =$row['amount'];

		//更新库存表
		if($updateKucun)
		{
			$sql2 = "select * from zy_spkucun where st_id={$st_id} and sp_id={$sp_id} lock in share mode";
			$result_S_kucun = mysqli_query($con,$sql2);
			if(!$result_S_kucun)
			{
				logInfo( $sql2.' : '.mysqli_error($con)."\r\n");
				exit( $sql2.' : '.mysqli_error($con).'<br>');
			}
			$count = mysqli_num_rows($result_S_kucun);
			if ($count != 0)
			{
				$sql2 = " update zy_spkucun set kucun=kucun+{$shuliang} where st_id={$st_id} and sp_id={$sp_id} ";
				$result_U_kucun = mysqli_query($con,$sql2);
				if(!$result_U_kucun) 
				{
					logInfo( $sql2.' : '.mysqli_error($con)."\r\n");
					exit( $sql2.' : '.mysqli_error($con).'<br>');
				}
			}
			else
			{//这种情况应该不会发生
				exit( 'Error : '.mysqli_error($con).'<br>');
			}
		}
		//@note remit数据
		//更新出库时物品记录的入库数量
		$sql2 = "update {$target} set shuliang=shuliang+{$shuliang} where st_id={$st_id} and id={$ruku_id}";
		$result2 = mysqli_query($con,$sql2);
		if(!$result2)
		{ 
			logInfo( $sql2.' : '.mysqli_error($con)."\r\n");
			exit( $sql2.' : '.mysqli_error($con).'<br>');
		}
	}
	mysqli_query($con,"commit");
	if($result_S_kucun) mysqli_free_result($result_S_kucun);
	if($result) mysqli_free_result($result);
	if($local) mysqli_close($con);
}
//审批后，将待入库物品电子入库
function Import($billno,$con,$dep_id,$st_id,$permit_id,$task_id)
{
	mysqli_query($con,"START TRANSACTION");
	if($billno!='')
	{
		//更新物品入库单号
		$sql = "update waitimport set BillNo = '{$billno}' where st_id={$st_id} and task_id={$task_id}";
		$result = mysqli_query($con,$sql);
		if(!$result)
		{
			mysqli_query($con,"rollBack");
			logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql);
			mysqli_close($con);
			exit;
		}
	}
	$sql = "select id,sp_id,shuliang from waitimport where st_id={$st_id} and task_id={$task_id} lock in share mode";
	$result = mysqli_query($con,$sql);
	//将waitimport表中数据逐条移至zy_spruku表中
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		//更新库存表
		$id = $row['id'];
		$sp_id =$row['sp_id'];
		$shuliang =$row['shuliang'];
		$sql_S_kucun = "select kucun from zy_spkucun where sp_id={$sp_id} and st_id={$st_id} lock in share mode";
		//echo $sql_S_kucun."<br>";

		$result_S_kucun = mysqli_query($con,$sql_S_kucun);
		$count = mysqli_num_rows($result_S_kucun);
		if ($count != 0)
		{
			$row_S_kucun = mysqli_fetch_array($result_S_kucun,MYSQLI_ASSOC);
			$kucun = $row_S_kucun['kucun'];
			$kucun += $shuliang;
			$sql_U_kucun = " update zy_spkucun set kucun={$kucun} where sp_id={$sp_id} and st_id={$st_id} ";
			$result_U_kucun = mysqli_query($con,$sql_U_kucun);
			if(!$result_U_kucun)
			{
				mysqli_query($con,"rollBack");
				logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql_U_kucun);
				mysqli_close($con);
				exit;
			}
		}
		else
		{
			$sql_I_kucun = "insert into zy_spkucun (sp_id,kucun,dep_id,st_id,kucun1,kucun2,kucun3,kucun4,kucun5,kucun6,kucun7,kucun8,kucun9,kucun10,kucun11,kucun12) values({$sp_id},{$shuliang},{$dep_id},{$st_id},0,0,0,0,0,0,0,0,0,0,0,0)";
			$result_I_kucun = mysqli_query($con,$sql_I_kucun);
			if(!$result_I_kucun) die("Error:".mysqli_error($con));
			if(!$result_I_kucun)
			{
				mysqli_query($con,"rollBack");
				logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql_I_kucun);
				mysqli_close($con);
				exit;
			}
		}
		//更新入库表
		$date = date('Y-m-d');
		$sql = "update waitimport set `date`='{$date}' where st_id={$st_id} and task_id={$task_id}";
		$result_s=mysqli_query($con,$sql);
		if(!$result_s)
		{
			mysqli_query($con,"rollBack");
			logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql);
			mysqli_close($con);
			exit;
		}

		$fields = "sp_id,jiage,jiage_other,jiage2,shuliang,shuliang2,`date`,orderDate,date2,brand,model,unit,box,madeDate,source,orderBill,BillNo,memo,dep_id,st_id,keeper,amount,operator,curency,rate";
		$sql_S_kucun = "insert into zy_spruku({$fields}) select {$fields} from waitimport where waitimport.id={$id}";
		$result_s=mysqli_query($con,$sql_S_kucun);
		if(!$result_s)
		{
			mysqli_query($con,"rollBack");
			logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql_S_kucun);
			mysqli_close($con);
			exit;
		}

		//从waitimport中删掉此条记录，也可以移完后统一truncate掉
		$sql_S_kucun = "delete from waitimport where id = {$id};";
		//echo $sql_S_kucun;
		$result_s = mysqli_query($con,$sql_S_kucun);
		if(!$result_s)
		{
			mysqli_query($con,"rollBack");
			logInfo('Error:dbtool.import'.mysqli_error($con)."\r\n".$sql_S_kucun);
			mysqli_close($con);
			exit;
		}
	}
	if($result_S_kucun) mysqli_free_result($result_S_kucun);
	if($result) mysqli_free_result($result);
	mysqli_query($con,"commit");
}

function getFlowerVets($mode=FLOW_INFO_NULL,$con=-1,$id=-1)
{//取各审批环节信息
	$vets = array('admin'=>'','audit'=>'','user'=>'','guest'=>'','claimant'=>'');
	if($mode==FLOW_INFO_NULL) return $vets;
	$local=false;
	if($con==-1)
	{
		$dbase = $_SESSION['zy_dbase'];
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm","portal");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$local=true;
	}

	$sql = "select claimant,admin_vet,audit_vet,user_vet,guest_vet from permittask where id='{$id}'";

	$result = mysqli_query($con,$sql);
	$row=mysqli_fetch_object($result);
	if($mode==FLOW_INFO_FULL)
	{
		$t = strip_tags($row->admin_vet);
		$t = str_replace("'","",$t);
		$t =str_replace("\"","",$t);
		$vets['admin'] = $t;

		$t = strip_tags($row->audit_vet);
		$t = str_replace("'","",$t);
		$t =str_replace("\"","",$t);
		$vets['audit']= $t;

		$t = strip_tags($row->user_vet);
		$t = str_replace("'","",$t);
		$t =str_replace("\"","",$t);
		$vets['user'] = $t;

		$t = strip_tags($row->guest_vet);
		$t = str_replace("'","",$t);
		$t =str_replace("\"","",$t);
		$vets['guest'] = $t;

		$vets['claimant'] = $row->claimant;

		if($result) mysqli_free_result($result);
		if($local) mysqli_close($con);
		return $vets;
	}
	//FLOW_INFO_SIMPLE
	$vet = $row->admin_vet;
	$pos = mb_strpos($vet,'[');
	if($pos!==FALSE) $vet=mb_substr($vet,$pos+1);
	$pos = mb_strpos($vet,']');
	if($pos!==FALSE) $vet=mb_substr($vet,0,$pos);
	$vets['admin']=$vet;

	$vet = $row->user_vet;
	$pos = mb_strpos($vet,'[');
	if($pos!==FALSE) $vet=mb_substr($vet,$pos+1);
	$pos = mb_strpos($vet,']');
	if($pos!==FALSE) $vet=mb_substr($vet,0,$pos);
	$vets['user']=$vet;

	$vet = $row->audit_vet;
	$pos = mb_strpos($vet,'[');
	if($pos!==FALSE) $vet=mb_substr($vet,$pos+1);
	$pos = mb_strpos($vet,']');
	if($pos!==FALSE) $vet=mb_substr($vet,0,$pos);
	$vets['audit']=$vet;

	$vet = $row->guest_vet;
	$pos = mb_strpos($vet,'[');
	if($pos!==FALSE) $vet=mb_substr($vet,$pos+1);
	$pos = mb_strpos($vet,']');
	if($pos!==FALSE) $vet=mb_substr($vet,0,$pos);
	$vets['guest']=$vet;

	$vets['claimant']=$row->claimant;
	if($result) mysqli_free_result($result);
	return $vets;
}

function getMoneyMark($skey)
{
	$array = array("泰铢"=>"฿","里拉"=>"₤","比索"=>"₱","日元"=>"¥","法郎"=>"₣","韩元"=>"₩","卢布"=>"руб","欧元"=>"€","英镑"=>"￡","美元"=>"＄","港币"=>"＄","兰特"=>"R","雷亚尔"=>"R$","加元"=>"＄","新元"=>"＄");

	foreach( $array as $key=>$value)
	{
		if($key==$skey) return $value;
	}
	return false;
}

function getWaitImportBill($pt_id,$task_id,$dep_id,$st_id,$con=-1)
{//从待入库表生成出库单表供打印之用
	session_start();

	$local = false;
	if($con==-1)
	{
		$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
		if(!$con) die( "连接服务器出错：".mysqli_connect_error());
		mysqli_query($con,"SET NAMES 'utf8'");
		$link=mysqli_select_db($con,"{$_SESSION['zy_dbase']}");
		if(!$link) die("连接数据库出错：".mysqli_connect_error());
		$local=true;
	}

	$newPage = "</table><div style='page-break-after:always'></div><br>";
	$mTable = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>\r\n";
	$mHead = "<tr height='36px' align='center' bgcolor=#e0e0e0><td><b>序号</b></td><td><b>名称</b></td><td><b>品牌</b></td><td><b>规格型号</b></td><td><b>数量</b></td><td><b>单位</b></td><td><b>单价<br>(外币)</b></td><td><b>外币<br>币种</b></td><td><b>外币<br>比价</b></td><td><b>单价<br>(人民币)</b></td><td><b>小计<br>人民币</b></td><td><b>过期日</b></td><td width=16%><b>备注</b></td></tr>\r\n";
	$table_noborder= "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0'>";
	$tail = $table_noborder . "<tr height='42px' align=center><td width=25%>会计主管：@ADMIN@</td><td width=25%>会计：@AUDIT@</td><td width=25%>库管员：@USER@</td><td width=25%>经手人：@BUYER@</td></tr></table>";

	$doublePrint = getOptionDepart("doublePrint",$con);
	if($doublePrint=='') $doublePrint=0;

	$year = date("Y");
	$month = date("m");
	$day = date("d");
	$FileName = "../../data/temp/{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}.png";
	if(makeCodebar($pt_id,$FileName))
		$str = "<img src='{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}.png'>";
	else
		$str='';
	$sql = "select s.name as station,d.name as depart from portal.stations s inner join portal.department d on s.depart_id=d.id where s.id={$st_id};";

	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_object($result);
	$station = $row->station;
	$depart = $row->depart;

	//echo $sql;

	$pageNum=1;
	$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
	$pstr =$pageNo;
	$curency = getOptionDepart('curency',$con);
	if($curency=='') $curency='美元';

	$hb_name = getMoneyMark($curency);
	if($hb_name===false) $hb_name="¤";

	$pstr .= "<center>{$str}<br><br><b><h3>{$depart}库房入库单</h3></b>（ @SN@ ）</center>";
	$pstr.= $table_noborder;
	$pstr.= "<tr height='32px' valign=bottom><td align='left' width=33%><b>库房：</b>{$station}</td><td width=20% align='center'>入库日期：{$year}-{$month}-{$day}<td width=33% align='right'>{$year} 第　　　号</td></tr>";
	$pstr .= "<tr height=4px></tr></table>";
	$pstr.= $mTable;
	$pstr.= $mHead;
	$sql = "select a.id as id ,b.name as name,b.dep_id as dep_id,b.st_id as st_id,a.sp_id as sp_id,a.unit as unit,a.jiage as jiage,a.jiage2 as jiage2,a.jiage_other as jiage_other,a.curency as curency,a.rate as rate,a.model as model,a.brand as brand,a.shuliang2 as shuliang2,a.box as box,a.date as date,a.date2 as date2,a.memo as memo from waitimport a inner join zy_spxinxi b on a.sp_id = b.id where b.st_id={$st_id} and a.task_id={$task_id}";
	//echo $sql;
	$result = mysqli_query($con,$sql);
	$waitnum = mysqli_num_rows($result);
	$amount=0;
	$m=0;
	$c=0;
	$k=0;
	$sum=0;
	$pageNum=1;
	$ps= getPageSize(TABLE_IMPORT,$waitnum);
	$firstPage =$ps[0];
	$otherPage = $ps[1];
	$totalPage = $ps[2];

	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
		{
			$m = 1;
			$c = 0;
			++$pageNum;
			if($pageNum<=$totalPage)
			{
				$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
				$pstr.= "</table>".$newPage.$pageNo.$mTable.$mHead;
			}
		}
		++$k;
		++$c;

		$pstr.= "<tr height=\"36px;\"><td>{$k}</td><td>";
		$pstr.= $row['name'];
		$pstr.= "</td>";
		$pstr.= "<td>".$row['brand']."</td>";
		$pstr.= "<td>".$row['model']."</td>";
		$str = intval($row['shuliang2']);
		if($str!=$row['shuliang2']) $str=$row['shuliang2'];
		$sum+=$str;

		$pstr.= "<td>".$str."</td>";
		$pstr.= "<td>".$row['unit']."</td>";
		if($row['curency']=='人民币')
		{
			$price_last =$row['jiage'];
			$pstr.= "<td>-</td>";
			$pstr.= "<td>-</td>";
			$pstr.= "<td>-</td>";
			$pstr.= "<td>".number_format($price_last,2)."</td>";
			$price_last = $row['shuliang2']*$row['jiage'];
			$amount += $row['jiage_other']*$row['shuliang2']+$row['jiage2'];
		}
		else
		{
			$price_last =$row['jiage_other']+round($row['jiage2']/$row['shuliang2'],2);
			$pstr.= "<td>".number_format($price_last,2)."</td>";//外币单价
			$pstr.= "<td>".$row['curency']."</td>";
			$pstr.= "<td>".$row['rate']."</td>";
			$pstr.= "<td>".number_format($row['jiage'],2)."</td>";//人民币单价
			$price_last = $row['jiage']*$row['shuliang2'];//人民币价格小计
			$amount += $row['jiage_other']*$row['rate']*$row['shuliang2']+$row['jiage2']*$row['rate'];
		}

		//$amount +=$price_last;
		$pstr.= "<td>".number_format($price_last,2)."</td>";//人民币价格小计

		$pstr.= "<td>".$row['date2']."</td>";
		if(USE_MEMO)
			$pstr.= "<td align=left>　{$row['memo']}</td></tr>";
		else
			$pstr.= "<td></td></tr>";
		$pstr.= "</tr>";
	}
	$m = intval($sum);
	if($m!=$sum) $m=$sum;

	$ret = array();
	$ret['sum_total'] = $sum;
	$ret['money_total'] = $amount;

	$amount = number_format($amount,2);
	$pstr.="<tr height=36px bgcolor=#f1f1f1 align=center><td colspan=4><b>合计</b></td><td colspan=5>数量合计：{$m}</td><td colspan=4>金额总计：{$amount} 元（人民币）</td></tr>";

	if($result) mysqli_free_result($result);
	$pstr.=  "</table>";

	$pstr.=   $tail;
	$pstr = str_replace('@PageNum@',$pageNum,$pstr);

	$eletricFlow = getOptionDepart('eletricFlow',$con);
	if($eletricFlow=='') $eletricFlow=0;
	if($eletricFlow)
		$vet = getFlowerVets(FLOW_INFO_SIMPLE,$con,$pt_id);
	else
		$vet=getFlowerVets();
	$pstr = str_replace('@BUYER@',$vet['claimant'],$pstr);
	$pstr = str_replace('@USER@',$vet['user'],$pstr);
	$pstr = str_replace('@ADMIN@',$vet['admin'],$pstr);
	$pstr = str_replace('@AUDIT@',$vet['audit'],$pstr);

	$y = str_replace('@SN@','<b>第二联　库管存</b>',$pstr) ;
	$m = str_replace('@SN@','<b>第三联　经手人</b>',$pstr) ;
	$pstr = str_replace('@SN@','<b>第一联　会计存</b>',$pstr) ;

	if($doublePrint!=0 && ($pageNum%2)==1 )
	{//双面打印且总页数为奇数页
		$extra=   "<p>　　".$newPage;
		$pstr = $pstr . $newPage . $extra . $y . $newPage . $extra . $m . $extra ;
	}
	else
	{
		$pstr = $pstr . $newPage .$y .$newPage. $m ;
	}
	if($local) mysqli_close($con);

	$ret['info'] = $pstr;
	return $ret;
}

//从待出库表生成出库单表供打印之用
function getWaitCheckoutBill($pt_id,$task_id,$purpose,$con,$dep_id,$st_id,$claimant='')
{
	$NewPage = "<div style='page-break-after:always'></div>";
	$table = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' border='1' bordercolor='#c0c0c0'>";
	$table_noborder= "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0' bordercolor='#c0c0c0'>";
	$title = "<tr height='36px' align='center'  bgcolor=#f1f1f1><td><b>序号</b></td><td><b>名称</b></td><td><b>品牌</b></td><td><b>规格型号</b></td><td><b>数量</b></td><td><b>单位</b></td><td width=16%><b>备注</b></td></tr>";
	$tail = $table_noborder . "<tr height=32 valign=bottom align=center><td width=25%>会计主管：@ADMIN@</td><td  width=25%>会计：@AUDIT@</td><td width=25%>库管员：@USER@</td><td width=25%>经手人：@BUYER@</td></tr></table><p>";

	$today = date('Y');
	$str = date('Y-m-d');
	$pageNum=1;
	$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
	$webstr =$pageNo;

	$FileName = "../../data/temp/{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}.png";
	if(makeCodebar($pt_id,$FileName))
		$webstr.= "<center><img src='{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}.png'><br><br><b><h3>{$_SESSION['zy_depart_name']}领物单（{$purpose})</h3></b>（ @SN@ ）<br></center>";
	else
		$webstr.= "<center><br><br><b><h3>{$_SESSION['zy_depart_name']}领物单（{$purpose})</h3></b>（ @SN@ ）<br></center>";

	mysqli_query($con,"start transaction");
	$sql = "select name from portal.stations where id='{$st_id}';";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_object($result);
	$station = $row->name;

	$webstr = $webstr . $table_noborder;
	$webstr = $webstr . "<tr height='38px;' valign=bottom><td align='left' width=23%>库房：{$station}</td><td align='center' width=20%>出库：{$str}</td><td width=32% align='center'>金额：@MM@ 元 (人民币)</td><td align='right' width=25%>{$today}年 第　　　号</td></tr>";
	$webstr .= "<tr height=4px></tr></table>";
	$webstr = $webstr . $table;
	$webstr = $webstr . $title;
	$str =':';

	$sql="select a.brand as sp_brand,a.box as sp_box,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,b.memo as memo,b.ruku_id as ruku_id,b.sp_id as sp_id,b.sp_name as sp_name,b.amount as amount from waithandlelist b inner join zy_spruku a where b.st_id={$st_id} and b.task_id={$task_id} and a.sp_id=b.sp_id and a.id=b.ruku_id order by b.id";
	$result = mysqli_query($con,$sql);
	if(!$result) die("Error:".mysqli_error($con)."<br>{$sql}");
	$ItemNum = mysqli_num_rows($result);
	$k = 0;
	$m = 0;
	$c = 0;
	$sum_total=0;
	$doublePrint = getOptionDepart("doublePrint",$con);
	$ps= getPageSize(TABLE_CHECKOUT,$ItemNum);
	$firstPage =$ps[0];
	$otherPage = $ps[1];
	$totalPage = $ps[2];

	for($i=0; $i<$ItemNum; $i++)
	{
		if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
		{
			$m = 1;
			$c = 0;
			++$pageNum;
			if($pageNum<=$totalPage)
			{
				$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr><tr height=2px></tr></table>";
				$webstr.= "</table>".$NewPage.$pageNo.$table.$title;
			}
		}
		++$k;
		++$c;
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$webstr = $webstr . "<tr  height='36px;' align='center'><td>{$k}</td>";
		$webstr = $webstr . "<td>{$row['sp_name']}</td>";
		$webstr = $webstr . "<td>{$row['sp_brand']}</td>";
		$webstr = $webstr . "<td>{$row['sp_model']}</td>";
		$str2 = intval($row['amount']);
		if($str2!=$row['amount']) $str2=$row['amount'];
		$sum_total+=$str2;

		$webstr = $webstr . "<td>{$str2}</td>";
		$webstr = $webstr . "<td>{$row['sp_unit']}</td>";

		if(USE_MEMO)
			$webstr.= "<td align=left>　{$row['memo']}</td></tr>";
		else
			$webstr.= "<td></td></tr>";
	}
	$webstr = $webstr . "</table>";
	$webstr = $webstr . $tail;
	$webstr = $webstr . $NewPage;
	if($doublePrint==1 && $pageNum%2==1 )
	{//双面打印且总页数为奇数页
		$webstr.=   "<p>　　".$NewPage;
	}
	if($result) mysqli_free_result($result);

	$eletricFlow = getOptionDepart('eletricFlow',$con);
	if($eletricFlow=='') $eletricFlow=0;

	if($eletricFlow)
		$vet = getFlowerVets(FLOW_INFO_SIMPLE,$con,$pt_id);
	else
		$vet=getFlowerVets();

	$webstr = str_replace('@BUYER@',$vet['claimant'],$webstr);
	$webstr = str_replace('@USER@',$vet['user'],$webstr);
	$webstr = str_replace('@ADMIN@',$vet['admin'],$webstr);
	$webstr = str_replace('@AUDIT@',$vet['audit'],$webstr);
	$webstr = str_replace('@PageNum@',$pageNum,$webstr);

	//一式三联
	$str = $webstr;
	$a = str_replace('@SN@','<b>第二联　库管存</b>',$str);
	$webstr .=  $a;
	$a = str_replace('@SN@','<b>第三联　经手人</b>',$str);
	$webstr .=  $a;
	$webstr = str_replace('@SN@','<b>第一联　会计存</b>',$webstr);

	$sql = "select sum(amount) as t_num from waithandlelist where st_id={$st_id} and task_id={$task_id};";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_object($result);
	$t_num = $row->t_num;
	$t_num = $t_num==intval($t_num)?$t_num:number_format($row->t_num,2);

	$pageNum=1;
	$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
	$webstr .=$pageNo;

	$webstr .= "<br><br><center><b><h3>{$station}出库申请结算单（{$purpose})</h3></b><font color=gray>( 本单不用签批，交费/出库后交出纳、会计 )</font><br><br>";
	$webstr = $webstr . "<table width = '848' style=' text-align:left;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0'>";
	$webstr = $webstr . "<tr height='28px;' algin='left' valign=bottom>";
	$today = date('Y-m-d');
	$webstr = $webstr . "<td align=left><b>出库日期：</b>{$today}</td>";

	$str2 = intval($t_num);
	if($str2!=$t_num) $str2=$t_num;
	$webstr = $webstr . "<td align=center><b>总 件 数：</b>{$str2}</td>";
	$webstr = $webstr . "<td align=center>领 物 人：{$claimant}</td>";
	$today = date('Y');
	$webstr = $webstr . "<td align=right><b>申领单号：</b>{$today}-{$task_id}</td></tr>";
	$webstr .= "<tr height=4px></tr></table>";
	$webstr = $webstr . "<table width = '848' align='center' style=' text-align:center;border-collapse:collapse;border:1px solid' cellpadding='0' cellspacing='0' border='1' bordercolor='#c0c0c0'>";
	$title2 =  "<tr height='36px' align='center'><td><b>序号</b></td><td><b>物品名称</b></td><td><b>品牌</b></td><td><b>型号</b></td><td><b>出库数量</b></td><td><b>单位</b></td><td><b>单价</b></td><td><b>总价小计</b></td><td><b>存放位置</b></td></tr>";
	$webstr = $webstr . $title2;

	$str =':';
	$k = 0;
	$sum = 0;
	$m = 0;
	$c = 0;
	$discount = getOptionDepart('discount',$con,$dep_id,$st_id);
	if($discount=='') $discount=1;
	$rate = getOptionDepart('exRate',$con,$dep_id,$st_id);
	if($rate=='') $rate=1;
	$expire = 0;
	$buyer = '';
	$today = date("Y-m-d");
	$sql="select a.brand as sp_brand,a.box as sp_box,a.model as sp_model,a.unit as sp_unit,a.jiage as sp_price,a.date2 as date2,b.ruku_id as ruku_id,b.sp_id as sp_id,b.sp_name as sp_name,b.amount as amount from waithandlelist b inner join zy_spruku a where  b.st_id={$st_id} and b.task_id={$task_id} and a.sp_id=b.sp_id and a.id=b.ruku_id order by b.id";
	$result = mysqli_query($con,$sql);
	if(!$result) die("Error:".mysqli_error($con)."<br>{$sql}");
	$ItemNum = mysqli_num_rows($result);
	for($i=0; $i<$ItemNum; $i++)
	{
		if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
		{
			$m = 1;
			$c = 0;
			++$pageNum;
			$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
			if($ItemNum-$k>=1) $webstr.= "</table>".$NewPage.$pageNo.$table.$title2;
		}
		++$k;
		++$c;
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

		$e = $row['date2']<$today?1:0;
		if($e==1) $expire=1;
		$webstr = $webstr . "<tr  height='36px;' align='center'><td>{$k}</td>";
		$webstr = $webstr . "<td>{$row['sp_name']}</td>";
		$webstr = $webstr . "<td>{$row['sp_brand']}</td>";
		$webstr = $webstr . "<td>{$row['sp_model']}</td>";
		$str2 = intval($row['amount']);
		if($str2!=$row['amount']) $str2=$row['amount'];
		$webstr = $webstr . "<td>{$str2}</td>";
		$webstr = $webstr . "<td>{$row['sp_unit']}</td>";

		$webstr = $webstr . "<td align=center>".number_format($row['sp_price'],2)."　</td>";
		$str = $row['sp_price']*$row['amount'];
		$str *= $e==1?(float)$discount:1;
		$sum += $str;

		$str = $row['sp_price']*$row['amount'];
		$str = $e==1?'*'.number_format($str*(float)$discount,2):number_format($str,2);
		$webstr = $webstr . "<td align=center>{$str}　</td>";

		$webstr = $webstr . "<td>{$row['sp_box']}</td></tr>";
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);

	$ret = array();
	$ret['sum_total']=$sum_total;
	$ret['money_total']=$sum;

	$us =$sum>0?number_format($sum/$rate,2):0;
	$rmb = number_format($sum,2);
	$webstr =str_replace('@MM@',number_format($sum,2),$webstr);
	$webstr =str_replace('@PageNum@',$pageNum,$webstr);

	$curency = getOptionDepart('curency',$con);
	if($curency=='') $curency='美元';
	if($expire==1)
		$webstr = $webstr . "<tr height=36px;><td colspan=4><b>人民币合计</b><font color=gray>(含过期品折扣)：</font> {$rmb} 元</td><td colspan=3><b>折合{$curency}</b>：{$us} 元</td><td colspan=2>本月汇率：{$rate}</td></tr>";
	else
		$webstr = $webstr . "<tr height=36px;><td colspan=4><b>人民币合计</b>：{$rmb} 元</td><td colspan=3><b>折合{$curency}</b>：{$us} 元</td><td colspan=2>本月汇率：{$rate}</td></tr>";

	$webstr = $webstr . "</table>";
	$ret['info']=$webstr;

	return $ret;
}
//根据申领单号得到申领单打印内容
function getApplyPrintText($con,$pt_id,$st_id,$task_id,$station,$claimant,$applyTime,$purpose)
{
	$sql="select w.sp_name as sp_name, w.amount as shuliang,r.brand as brand,r.model as model,r.date2 as date2,r.box as box,r.jiage as jiage,r.unit as unit from waithandlelist w inner join zy_spruku r on w.ruku_id=r.id where w.task_id={$task_id} and w.st_id={$st_id} and r.st_id={$st_id}";

	$result = mysqli_query($con,$sql);
	$num = mysqli_num_rows($result);

	$FileName = "../../data/temp/{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}.png";
	if(makeCodebar($pt_id,$FileName))
		$barcode = "<img src='{$FileName}'>";
	else
		$barcode='';
	$NewPage = "<div style='page-break-after:always'></div>";
	$title = "<tr height='36px' align='center'><td><b>序号</b></td><td><b>物品名称</b></td><td><b>品牌</b></td><td><b>型号</b></td><td><b>出库数量</b></td><td><b>单位</b></td><td><b>单价</b></td><td><b>总价</b></td><td><b>备注</b></td></tr>";
	$table = "<table width = '848px' align='center'  style='text-align:center;border-collapse:collapse;border:1px solid' border='1' bordercolor='#c0c0c0'>";
	$doublePrint = getOptionDepart("doublePrint",$con);
	if($doublePrint=='') $doublePrint=0;
	$ps= getPageSize(TABLE_APPLY,$num);
	$firstPage =$ps[0];
	$otherPage = $ps[1];
	$totalPage = $ps[2];

	$k = 0;
	$m=0;
	$c=0;
	$pageNum=1;
	$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
	$pstr =$pageNo;
	$pstr .= "<center>{$barcode}<br><br><br><b><h3>{$station}物品申领清单（{$purpose}）</h3></b>";
	$pstr.= "<table width='848px' style=' text-align:left;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0'>";
	$pstr.= "<tr height='36px;' algin='left'>";
	$billYear = substr($applyTime,0,10);
	$pstr.= "<td algin='left'><b>申领日期：</b>{$billYear}</td>";
	$pstr.= "<td align=center><b>总 件 数：</b>@SUM_TOTAL@</td>";
	$pstr.= "<td algin=center><b>申 领 人：</b>{$claimant}</td>";
	$billYear = substr($applyTime,0,4);
	$pstr.= "<td align=right><b>申领单号：</b>{$billYear}-{$task_id}</td></tr></table>";

	$pstr.= $table . $title;
	$discount = getOptionDepart('discount',$con);
	if($discount=='')
	{
		$discount = 1;
		updateOptionDepart('discount',1,$con);
	}
	$today = date("Y-m-d");
	$expire =0;
	$e=0;
	$total=0;
	$sum_total=0;

	for($i=0;$i<$num;$i++)
	{
		if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
		{
			$m = 1;
			$c = 0;
			++$pageNum;
			if($pageNum<=$totalPage)
			{
				$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr><tr height=2px></tr></table>";
				$pstr.= "</table>".$NewPage.$pageNo.$table.$title;
			}
		}
		++$k;
		++$c;
		$rs = mysqli_fetch_object($result);
		$amount = intval($rs->shuliang);
		if( $amount != $rs->shuliang) $amount = $rs->shuliang;
		$sum_total+=$amount;

		$e = $rs->date2<$today?1:0;
		if($e==1) $expire=1;
		$pstr.= "<tr height=\"38px;\"><td>";
		$pstr.= $i+1;
		$pstr.= "</td><td>";
		$pstr.= $rs->sp_name;
		$pstr.= "</td><td>";
		$pstr.= $rs->brand;
		$pstr.= "</td><td>";
		$pstr.= $rs->model;
		$pstr.= "</td><td>";
		$pstr.= $amount;
		$pstr.= "</td><td>";
		$pstr.= $rs->unit;
		$pstr.= "</td><td>";
		$pstr.= number_format($rs->jiage,2);
		$pstr.= "</td><td>";

		$money = $e==1?$rs->jiage*$amount*$discount:$rs->jiage*$amount;
		$total+=$money;
		$money = number_format($money,2);
		$pstr.= $e==1?$money.'*':$money;
		$pstr.= "</td><td>";
		$pstr.=$e==1?'过期品':'';
		$pstr.= "</td></tr>";
	}
	if($result) mysqli_free_result($result);

	$ret=array();
	$ret['money_total']=$total;
	$ret['sum_total']=$sum_total;

	$curency = getOptionDepart("curency",$con);
	if($curency=='') $curency='美元';
	$rate = getOptionDepart('exRate',$con);
	if($rate=='') $rate=1;

	$m = number_format($total/$rate,2);
	if($expire!=0)
		$tmp = "(含过期品折扣)";
	else
		$tmp='';

	$total = number_format($total,2);
	$pstr .= "<tr height='36px'><td colspan=4><b>人民币合计{$tmp}：</b>{$total} 元</td><td colspan=3><b>折合{$curency}：</b>{$m} 元</td><td colspan=2>本月汇率：{$rate}</td></tr>";
	$pstr.= "</table>";

	$pstr =str_replace('@SUM_TOTAL@',"{$sum_total}",$pstr);
	$pstr =str_replace('@PageNum@',"{$pageNum}",$pstr);
	$pstr.= "<table width = '848px;' style=' text-align:right;' cellpadding='0' cellspacing='0' border='0'>";
	$pstr.= "<tr height='32px;''><td>{$_SESSION['zy_depart_name']}制 </td></tr></table><p>";

	$ret['info']=$pstr;
	return $ret;
}

//通过出库、入库单号重打出入库单
function getPrintText($billno,$mode,$st_id,$year2='',$buyer='')
{
	session_start();
	$con=mysqli_connect("127.0.0.1","root","dzmaadzm");
	if(!$con) die( "连接服务器出错：".mysqli_connect_error());
	mysqli_query($con,"SET NAMES 'utf8'");

	$dbase = $_SESSION['zy_dbase'];
	$link=mysqli_select_db($con,"{$dbase}");
	if(!$link) die("连接数据表出错：".mysqli_connect_error());

	$NewPage = "<div style='page-break-after:always'></div>";
	$table = "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;border:1px solid' border='1' bordercolor='#c0c0c0'>";
	$table_noborder= "<table width = '848px' align='center' style='text-align:center;border-collapse:collapse;' cellpadding='0' cellspacing='0' border='0' bordercolor='#c0c0c0'>";
	$doublePrint = getOptionDepart("doublePrint",$con);
	if($doublePrint=='') $doublePrint=0;

	$result = mysqli_query($con,"select name from portal.stations where id={$st_id}");
	if($result)
	{
		$row = mysqli_fetch_object($result);
		$station_name = $row->name;
		mysqli_free_result($result);
	}
	if(strlen($billno)!=5)
	{//新号
		$bn = substr($billno,4);
		$year = substr($billno,0,4);
		$sql="select id,task_id from permittask where billno='{$billno}' and st_id={$st_id} and method='{$mode}'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_object($result);
		$vet = getFlowerVets(FLOW_INFO_SIMPLE,$con,$row->id);
		$pt_id = $row->id;
		$task_id = $row->task_id;
		if($result) mysqli_free_result($result);
	}
	else
	{
		$bn=$billno;
		$year =substr($year2,0,4);
		$task_id=$billno;
	}
	$FileName = "../../data/temp/{$pt_id}.png";
	if(makeCodebar($pt_id,$FileName))
		$barcode = "<img src='{$FileName}'>";
	else
		$barcode='';

	$pageNum=1;
	$amount = 0;
	$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr></table>";
	$pstr = $pageNo;
	$pstr2 =$pageNo;
	if($mode=='入库')
	{//入库
		$title = "<tr height='36px' align='center'  bgcolor=#f1f1f1><td><b>序号</b></td><td><b>名称</b></td><td><b>品牌</b></td><td><b>规格型号</b></td><td><b>数量</b></td><td><b>单位</b></td><td><b>单价<br>(外币)</b></td><td><b>&nbsp;外币&nbsp;<br>&nbsp;币种&nbsp;</b></td><td><b>&nbsp外币&nbsp;<br>&nbsp;比价&nbsp;</b></td><td><b>单价<br>(人民币)</b></td><td><b>小计<br>人民币</b></td><td><b>过期日</b></td><td><b>备注</b></td></tr>";
		$tail = $table_noborder ."<tr height=36px valign=bottom align=center><td width=25%>会计主管：{$vet['admin']}</td><td width=25%>会计：{$vet['audit']}</td><td width=25%>库管员：{$vet['user']}</td><td width=25%>经手人：{$vet['claimant']}</td></tr></table><p>";

		$curency = getOptionDepart('curency',$con);
		if($curency=='') $curency='美元';

		$hb_name = getMoneyMark($curency);
		if($hb_name===FALSE)
			$hb_name="¤";

		$pstr.= "<center>{$barcode}<br><br><b><h3>".$_SESSION['zy_depart_name']."入库单</h3></b>（ @SN@ ）<br></center>";
		$pstr.= $table_noborder;
		$pstr.= "<tr height='32px;' valign=bottom><td align='left' width=33%>库房：".$station_name."</td><td align=center>入库日期：#DD#</td><td align='right' width=33%>{$year}年 第 {$bn} 号</td></tr>";
		$pstr .= "<tr height=4px></tr></table>";
		$pstr.= $table;
		$pstr.= $title;

		$sql = "select a.sp_id as id,a.source as source,a.operator as operator,a.shuliang as shuliang,a.shuliang2 as shuliang2,a.date as `date`,a.date2 as date2,b.name as name,a.brand as brand,a.model as model,a.jiage as price,a.jiage2 as jiage2,a.unit as unit ,a.memo as memo,a.jiage_other as jiage_other,a.curency as curency,a.rate as rate from zy_spruku a inner join zy_spxinxi b on a.sp_id=b.id where a.billno='{$billno}' and b.st_id={$st_id} and a.st_id={$st_id} order by `date` desc,a.billno desc";

		$result = mysqli_query($con,$sql);
		if(!$result) "Error:".mysqli_error($con)."<br>{$sql}";
		$k = 0;
		$m=0;
		$c=0;
		$sum =0;
		$num =0;
		$outdate = '';
		$rec=mysqli_num_rows($result);
		$ps= getPageSize(TABLE_IMPORT,$rec);
		$firstPage =$ps[0];
		$otherPage = $ps[1];
		$totalPage = $ps[2];

		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
			{
				$m = 1;
				$c = 0;
				++$pageNum;
				//if($rec-$k>=1)
				if($pageNum<=$totalPage)
				{
					$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr><tr height=2px></tr></table>";
					$pstr.= "</table>".$NewPage.$pageNo.$table.$title;
				}
			}
			++$k;
			++$c;
			if($k==1)
			{
				 $source = $row['source'];
				 $outdate = $row['date'];
			}
			$pstr.=  "<tr  height='36px;' align='center'><td>" .$k."</td>";
			$pstr.=  "<td>" .$row['name']. "</td>";
			$pstr.=  "<td>" .$row['brand']. "</td>";
			$pstr.=  "<td>" .$row['model']. "</td>";

			$sql = intval($row['shuliang2']);
			if($sql!= $row['shuliang2']) $sql=$row['shuliang2'];
			$amount +=$sql;

			$pstr.=  "<td>" .$sql."</td>";
			$pstr.=  "<td>" .$row['unit']. "</td>";
			if($row['curency']=='人民币'||$row['curency']=='')
			{
				$pstr.='<td>-</td>';
				$pstr.='<td>-</td>';
				$pstr.='<td>-</td>';
				$jiage_other = $row['price'];

				if($row['jiage_other']>0)
					$sum+=$row['jiage_other']*$row['shuliang2']+$row['jiage2'];
				else //兼容旧数据
					$sum+=$row['price']*$row['shuliang2'];
			}
			else
			{
				$jiage_other = $row['jiage_other'] + round($row['jiage2']/$row['shuliang2'],2);
				$pstr.=  "<td>" .$jiage_other. "</td>"; //外币单价
				$pstr.=  "<td>" .$row['curency']. "</td>";
				$pstr.=  "<td>" .$row['rate']. "</td>";
				$jiage_other = $row['price'];//已转成人民币单价，含其他费用
				$sum+=$row['jiage_other']*$row['rate']*$row['shuliang2']+$row['jiage2']*$row['rate'];
			}
			$pstr.=  "<td>" .number_format($jiage_other,2). "</td>";//人民币单价
			$money = round($jiage_other*$row['shuliang2'],2);

			$pstr.= "<td>" .number_format($money,2). "</td>";//人民币价格小计
			$pstr.= "<td>" .$row['date2']. "</td>";
			if(USE_MEMO)
				$pstr.= "<td align=left>　{$row['memo']}</td></tr>";
			else
				$pstr.= "<td></td></tr>";
		}
		$str =number_format($sum,2);
		$pstr.="<tr height=36px bgcolor=#f1f1f1 align=center><td colspan=4><b>合计</b></td><td colspan=5>数量合计：{$amount}</td><td colspan=4>金额总计：{$str} 元（人民币）</td></tr>";
		$pstr.=  "</table>";
		$pstr.=   $tail;

		$pstr2 = '';
	}
	else
	{//出库单
		$today = date("Y-m-d");
		$discount = getOptionDepart('discount',$con);
		if($discount=='') $discount=1;
		$expire = 0;

		$title = "<tr height='36px' align='center'  bgcolor=#f1f1f1><td><b>序号</b></td><td><b>名称</b></td><td><b>品牌</b></td><td><b>规格型号</b></td><td><b>数量</b></td><td><b>单位</b></td><td width=16%><b>备注</b></td></tr>";
		$tail = $table_noborder ."<tr height=32px valign=bottom align=center><td width=25%>会计主管：{$vet['admin']}</td><td width=25%>会计：{$vet['audit']}</td><td width=25%>库管员：{$vet['user']}</td><td width=25%>经手人：{$vet['claimant']}</td></tr></table><p>";

		$pstr.= "<center>{$barcode}<br><br><b><h3>".$_SESSION['zy_depart_name']."领物单@PP@</h3></b>（ @SN@ ）<br></center>";
		$pstr.= $table_noborder;
		$pstr.= "<tr height='36px;' valign=bottom><td align='left' width=23%>库房：".$station_name."</td><td align=center width=20%>出库： #DD#</td><td width=32% align='center'>金额：@MM@ 元 (人民币) </td><td align='right' width=25%>{$year}年 第 {$bn} 号</td></tr>";
		$pstr.= "<tr height=4px></tr></table>";
		$pstr.= $table;
		$pstr.= $title;

		$pstr2.= "<br><br><center><b><h3>{$station_name}出库申请结算单@PP@</h3></b><p><font color=gray>( 本单不用签批，交费/出库后交出纳、会计 )</font><br>";
		$pstr2.=$table_noborder;
		$pstr2.=  "<tr height='36px;' algin='left' valign=bottom>";
		$pstr2.=  "<td align=left>出库日期：#DD#</td>";
		$pstr2.=  "<td align=center>总 件 数：@CheckOutNum@</td>";
		$pstr2.=  "<td align=center>领 物 人：@buyer@</td>";
		$pstr2.=  "<td align=right>申请单号：{$year}-{$task_id}</td></tr>";
		$pstr2.= "<tr height=4px></tr></table>";

		$pstr2.= $table;
		$title2=  "<tr height='36px' align='center'><td><b>序号</b></td><td><b>物品名称</b></td><td><b>品牌</b></td><td><b>型号</b></td><td><b>出库数量</b></td><td><b>单位</b></td><td><b>单价</b></td><td><b>总价小计</b></td><td><b>存放位置</b></td></tr>";
		$pstr2.=$title2;

		//获取出库月汇率
		$a =array();
		$a=getFlowerVets(FLOW_INFO_FULL,$con,$pt_id);
		$m = $a['admin'];
		$m=substr($m,-14,2);
		$rate = getOptionDepart('exRate'.$m,$con);
		if($rate=='') $rate=1;

		$sql = "select a.sp_id as id,a.purpose as purpose,a.ruku_id as ruku_id,a.shuliang as shuliang,a.buyer as buyer,a.date as `date`,a.billno as billno,c.box as box,b.name as name,c.date2 as date2,c.brand as brand,c.model as model,c.jiage as price,a.memo as memo,c.unit as unit from (zy_spchuku a inner join zy_spxinxi b on a.sp_id=b.id)  inner join zy_spruku c on a.ruku_id=c.id where a.st_id={$st_id} and b.st_id={$st_id} and c.st_id={$st_id} and a.billno='{$billno}'  order by `date` desc,billno desc";
		//echo $sql;
		$result = mysqli_query($con,$sql);
		if(!$result) "Error:".mysqli_error($con)."<br>{$sql}";
		$k = 0;
		$m = 0;
		$c = 0 ;
		$sum =0;
		$num =0;
		$rec=mysqli_num_rows($result);
		$ps= getPageSize(TABLE_CHECKOUT,$rec);
		$firstPage =$ps[0];
		$otherPage = $ps[1];
		$totalPage = $ps[2];

		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			if( ($m==0 && $c==$firstPage) || ($m==1 && $c==$otherPage) )
			{
				$m = 1;
				$c = 0;
				++$pageNum;
				//if($rec-$k>=1)
				if($pageNum<=$totalPage)
				{
					$pageNo = "<table width='848px' border=0><tr><td align=right>第 {$pageNum} 页　共 @PageNum@ 页</td></tr><tr height=2px></tr></table>";
					$pstr.= "</table>".$NewPage.$pageNo.$table.$title;
					$pstr2.= "</table>".$NewPage.$pageNo.$table.$title2;
				}
			}
			$e = $row['date2']<$today?1:0;
			if($e==1)
			{
				$expire=1;
			}
			++$k;
			++$c;
			if($k==1)
			{
				$outdate= $row['date'];
				$buyer=$row['buyer'];
				$purpose = $row['purpose'];
			}
			$pstr.=  "<tr  height='36px;' align='center'><td>" .$k."</td>";
			$pstr.=  "<td>" .$row['name']. "</td>";
			$pstr.=  "<td>" .$row['brand']. "</td>";
			$pstr.=  "<td>" .$row['model']. "</td>";
			$sql = intval($row['shuliang']);
			if($sql!= $row['shuliang']) $sql=$row['shuliang'];
			$pstr.=  "<td>" .$sql."</td>";
			$pstr.=  "<td>" .$row['unit']. "</td>";
			if(USE_MEMO)
				$pstr.= "<td align=left>　{$row['memo']}</td></tr>";
			else
				$pstr.= "<td></td></tr>";

			$pstr2.=  "<tr  height='36px;' align='center'><td>" .$k."</td>";
			$pstr2.=  "<td>" .$row['name']. "</td>";
			$pstr2.=  "<td>" .$row['brand']. "</td>";
			$pstr2.=  "<td>" .$row['model']. "</td>";
			$pstr2.=  "<td>" .$sql. "</td>";
			$num +=$row['shuliang'];

			$pstr2.=  "<td>" .$row['unit']. "</td>";
			$pstr2.=  "<td align=center>" .number_format($row['price'],2). "　</td>";

			$money = number_format($e==1?$row['price']*$row['shuliang']*$discount:$row['price']*$row['shuliang'],2,'.','');
			$sum +=$money;
			if($e==1)
				$pstr2.= "<td align=center>*" .$money. "　</td>";
			else
				$pstr2.= "<td align=center>" .$money. "　</td>";
			$pstr2.= "<td>" .$row['box']. "</td></tr>";
		}
		$pstr.=  "</table>";
		$pstr.=   $tail;

		$pstr =str_replace('@MM@',number_format($sum,2),$pstr);
		$pstr2 =str_replace('@PageNum@',"{$pageNum}",$pstr2);
		$pstr2= str_replace('@CheckOutNum@',$num,$pstr2);
		$pstr2 = str_replace('@buyer@',$buyer,$pstr2);
		$pstr2 = str_replace("#DD#",$outdate,$pstr2) ;

		$str = number_format($sum/$rate,2);
		$sum = number_format($sum,2);
		$curency = getOptionDepart('curency',$con);
		if($curency=='') $curency='美元';
		if($expire==1)
			$pstr2.= "<tr height=36px><td colspan=4><b>人民币合计</b><font color=gray>(含过期品折扣)：</font> {$sum} 元</td><td colspan=3><b>折合{$curency}</b>：{$str}元</td><td colspan=2>本月汇率：{$rate}</td></tr>";
		else
			$pstr2.= "<tr height=36px><td colspan=4><b>人民币合计</b>：{$sum} 元</td><td colspan=3><b>折合{$curency}</b>：{$str}元</td><td colspan=2>本月汇率：{$rate}</td></tr>";
		$pstr2.=  "</table>";
		if( $purpose=='')
		{
			$pstr = str_replace('@PP@',$purpose,$pstr);
			$pstr2 = str_replace('@PP@',$purpose,$pstr2);
		}
		else
		{
			$pstr = str_replace('@PP@','（'.$purpose.'）',$pstr);
			$pstr2 = str_replace('@PP@','（'.$purpose.'）',$pstr2);
		}
	}
	if($result) mysqli_free_result($result);
	$pstr = str_replace("#DD#",$outdate,$pstr) ;
	$pstr =str_replace('@PageNum@',"{$pageNum}",$pstr);

	$y = str_replace('@SN@','<b>第二联　库管存</b>',$pstr) ;
	$m = str_replace('@SN@','<b>第三联　经手人</b>',$pstr) ;
	$pstr = str_replace('@SN@','<b>第一联　会计存</b>',$pstr) ;
	if($doublePrint==1 && ($pageNum%2)==1 )
	{//双面打印且总页数为奇数页
		$extra=   "<p>　　".$NewPage;
		$pstr = $pstr . $NewPage . $extra . $y . $NewPage . $extra . $m;
		if($mode=='出库') $pstr.=$NewPage. $extra;
	}
	else
	{
		$pstr = $pstr . $NewPage .$y .$NewPage. $m;
		if($mode=='出库') $pstr.=$NewPage;
	}
	$pstr .= $pstr2;
	mysqli_close($con);
	return $pstr;
}
function MessageBox($info,$url="")
{//提示信息后转到指定网址（如有）
	echo "<script type='text/JavaScript'>";
	echo "alert('$info');";
	if($url!='') echo("window.location.href='$url';");
	echo "</script>";
}
function JumpToUrl($url="")
{//转到指定网址（如有）
	echo "<script type='text/JavaScript'>";
	if($url!='') echo("window.location.href='$url';");
	echo "</script>";
}
//获取待签名字符串
//json post调用支持函数
function getPreSignString($array)
{
	$prestr='';

	if(empty($array))
		return $prestr;
	else
	{
		foreach($array as $key=>$value){
			$v = trim($value);
			if(!empty($v) && strtolower($key)!='sign') {
				$prestr.=$key.'='.$value.'&';
			}
		}

		if(!empty($prestr)){
			$length=strlen($prestr);
			$prestr=substr($prestr,0,$length-1);//去掉最后一个‘&’
		}

		return $prestr;
	}
}

function PrintTable($str,$url,$tablename,$forcePaperMode=PAPER_SYSTEM,$ajaxPrint=false)
{//forcePaperMode:纸张方向　0=系统设定　1=强制竖向　2=强制横向
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	try
	{
		$pstr = '<html><head><META content="text/html; charset=utf-8" http-equiv=Content-Type>';
		$pstr = $pstr .'<LINK rel=stylesheet type=text/css href="css/css.css">';
		$pstr = $pstr . "<style> .bottom{position:fixed;bottom:0;}";

		$paperLayout = getOptionDepart('paperLayout');
		$paperLayout = $paperLayout==''?1:$paperLayout;
		$paperMarginLeft = getOptionPortal('paperMarginLeft');
		$paperMarginLeft = $paperMarginLeft==''?25:$paperMarginLeft;

		$paperMarginRight = getOptionPortal('paperMarginRight');
		$paperMarginRight = $paperMarginRight==''?10:$paperMarginRight;

		$paperMarginTop = getOptionPortal('paperMarginTop');
		$paperMarginTop = $paperMarginTop==''?10:$paperMarginTop;

		$paperMarginBottom = getOptionPortal('paperMarginBottom');
		$paperMarginBottom = $paperMarginBottom==''?10:$paperMarginBottom;

		if($paperLayout==0 && $forcePaperMode!=PAPER_FORCE_LANDSCAPE)
			$pstr .= "@page { size: portrait;margin-left:{$paperMarginLeft}mm;margin-right:{$paperMarginRight}mm;margin-top:{$paperMarginTop}mm;margin-Bottom:{$paperMarginBottom}mm;}";
		else
			$pstr .= "@page { size: landscape;margin-left:{$paperMarginLeft}mm;margin-right:{$paperMarginRight}mm;margin-top:{$paperMarginTop}mm;margin-Bottom:{$paperMarginBottom}mm;}";
		$pstr.= "</style>";

		$pstr = $pstr . "<script language='javascript' type='text/javascript'>";
		$pstr = $pstr . "  function mPrint()";
		$pstr = $pstr . "  {";
		$pstr = $pstr . "	window.print();";
		$pstr = $pstr . "  }";
		$pstr = $pstr . "</script>";
		$pstr = $pstr . "</head>";
		$pstr = $pstr . "<BODY onload='mPrint()'>";

		session_start();
		//获取表格页脚
		$str = str_replace("{FOOTER}",$_SESSION['zy_depart_name'],$str);
		$str = str_replace("\'","'",$str);
		$a = "\\"."\"";
		$str = str_replace($a,"'",$str);

		$pstr = $pstr . $str;
		$pstr = $pstr . "</body></html>";

		$path = $_SERVER['PHP_SELF'];
		if( strncmp($path,'/code/inc',9)==0 )
		{//从include中调用
			$file='../../data';
		}
		else if(strncmp($path,'/code/template',14)==0)
		{//从template中调用
			$file='../../data';
		}
		else
		{//从code中调用
			$file='../data';
		}

		$FileName = "{$file}/temp/{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}{$_SESSION['zy_admin_id']}{$tablename}";
		if( $_SESSION['winOs']==1 )
			$FileName= iconv("UTF-8", "GB2312//IGNORE",$FileName);
		if (is_file ($FileName))
		{
			unlink ($FileName); //存在，就删除
		}
		if(false===file_put_contents($FileName,$pstr))
		{
			logInfo("写入文件{$FileName}失败");
		}
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage());
	}

	if( $_SESSION['winOs']==1 )
		$FileName= iconv("GB2312", "UTF-8//IGNORE",$FileName);

	if($ajaxPrint)
	{
		echo "{\"url\":\"{$url}\",";
		echo "\"print\":\"1\",";
		echo "\"file\":\"{$FileName}\"}";
	}
	else
	{
		if( $_SESSION['isSafari'])
			echo "<script language=\"JavaScript\">alert('请确认打印机准备好，点确定打印');</script>";

		if($url!='')
		{
			echo "<script language=\"JavaScript\">window.location.href='{$url}';window.open('{$FileName}','打印窗口');</script>";
		}
		else
		{
			echo "<script language='JavaScript'>window.location.href='{$FileName}';</script>";
		}
	}
}
function autoBackup($con)
{
	$filename = getOption("backupNo",$con);
	if($filename=='') $filename = 0;
	if($filename==(int)2)
		updateOption("backupNo",0,$con);
	else
		updateOption("backupNo",(int)$filename+1,$con);
	$filename = sprintf("%02d",$filename);
	$filename = "../../data/backup/{$_SESSION['zy_depart_id']}{$_SESSION['zy_station_id']}-{$filename}.sql";
	backup($filename,$con);
}

function backupPortal($con)
{
	date_default_timezone_set('PRC');
	$day = getOptionPortal('backupWeekDay',$con);
	if($day==date('w')) return true;
	updateOptionPortal('backupWeekDay',date('w'),$con);

	mysqli_query($con,"set names 'utf8'");
	mysqli_select_db($con,'portal');
	mysqli_query($con,"start transaction");
	$mysql = "set charset utf8;\r\n";
	$mysql .= "use `portal`;";
	$tables=array('config','department','member','memsyn','stations');
	for($i=0;$i<count($tables);$i++)
	{
		$q2 = mysqli_query($con,"show create table `{$tables[$i]}`");
		$sql = mysqli_fetch_array($q2,MYSQLI_ASSOC);
		$mysql .= "\r\ntruncate table `{$tables[$i]}`;\r\n";

		$str = str_replace('CREATE TABLE ','create table if not exists ',$sql['Create Table']);
		$mysql .=  $str. ";\r\n";
		$q3 = mysqli_query($con,"select * from `{$tables[$i]}`");
		while ($data = mysqli_fetch_assoc($q3)) {
			$keys = array_keys($data);
			$keys = array_map("addslashes", $keys);
			$keys = join("`,`", $keys);
			$keys = "`" . $keys . "`";
			$vals = array_values($data);
			$vals = array_map("addslashes", $vals);
			$vals = join("','", $vals);
			$vals = "'" . $vals . "'";
			$mysql .= "insert into `{$tables[$i]}`({$keys}) values({$vals});\r\n";
		}
	}
	mysqli_query($con,"commit");
	if($q3) mysqli_free_result($q3);
	$file_name="./data/portal/potal-weekday-".date("w")."-bak.sql";

	if( $_SESSION['winOs']==1 )
	$file_name= iconv("UTF-8", "GB2312//IGNORE",$file_name);

	if(!file_put_contents($file_name,$mysql,LOCK_EX)) MessageBox('backup portal error!');

	//测试用
	//$file_name="./data/portal/warehouse-weekday-".date("w")."-bak.sql";
	//backup($file_name,$con);
}

function backup($filename,$con)
{
	mysqli_query($con,"set names 'utf8'");
	$mysql = "set charset utf8;\r\n";
	$mysql .= "use `{$_SESSION['zy_dbase']}`;\r\n";
	$mysql .="start transaction;\r\n";
	mysqli_query($con,"start transaction");
	mysqli_select_db($con,$_SESSION['zy_dbase']);
	$q1 = mysqli_query($con,"show tables");
	if(!$q1)
	{
		echo 'backup error1.<br>';
		die(mysqli_error($con));
	}
	//备份当前库中所有表
	while ($t = mysqli_fetch_array($q1,MYSQLI_NUM)) {
		$table = $t[0];
		if($table=='zy_spfenlei') continue;

		$mysql .= "\r\ndelete from `{$table}`  where st_id={$_SESSION['zy_station_id']} ;\r\n";
		$q3 = mysqli_query($con,"select * from `{$table}` where st_id={$_SESSION['zy_station_id']}");
		if($q3)
		while ($data = mysqli_fetch_assoc($q3)) {
			$keys = array_keys($data);
			$keys = array_map("addslashes", $keys);
			$keys = join("`,`", $keys);
			$keys = "`" . $keys . "`";
			$vals = array_values($data);
			$vals = array_map("addslashes", $vals);
			$vals = join("','", $vals);
			$vals = "'" . $vals . "'";
			$mysql .= "insert into `{$table }`({$keys}) values({$vals});\r\n";
		}
	}
	mysqli_query($con,"commit");
	if($q3) mysqli_free_result($q3);
	$mysql.="commit;\r\n";

	mysqli_query($con,"start transaction");
	$mysql.="start transaction;\r\n";
	$mysql .="delete from permittask where st_id={$_SESSION['zy_station_id']};\r\n";
	$mysql .="delete from handlelist where st_id={$_SESSION['zy_station_id']};\r\n";

	$q3 = mysqli_query($con,"select * from `permittask` where st_id={$_SESSION['zy_station_id']}");
	while ($data = mysqli_fetch_assoc($q3)) {
		$keys = array_keys($data);
		$keys = array_map("addslashes", $keys);
		$keys = join("`,`", $keys);
		$keys = "`" . $keys . "`";
		$vals = array_values($data);
		$vals = array_map("addslashes", $vals);
		$vals = join("','", $vals);
		$vals = "'" . $vals . "'";
		$mysql .= "insert into `permittask`({$keys}) values({$vals});\r\n";
	}
	if($q3) mysqli_free_result($q3);

	$q3 = mysqli_query($con,"select * from `handlelist` where st_id={$_SESSION['zy_station_id']}");
	if($q3)
	while ($data = mysqli_fetch_assoc($q3)) {
		$keys = array_keys($data);
		$keys = array_map("addslashes", $keys);
		$keys = join("`,`", $keys);
		$keys = "`" . $keys . "`";
		$vals = array_values($data);
		$vals = array_map("addslashes", $vals);
		$vals = join("','", $vals);
		$vals = "'" . $vals . "'";
		$mysql .= "insert into `handlelist`({$keys}) values({$vals});\r\n";
	}
	if($q3) mysqli_free_result($q3);
	mysqli_query($con,"commit");
	$mysql.="commit;\r\n";
	//synology不用进行编码转换
	if( $_SESSION['winOs']==1 )
	{
		$filename= iconv("UTF-8", "GB2312//IGNORE", $filename);
	}
	file_put_contents($filename,$mysql,LOCK_EX);
}
/**
 * 将数值金额转换为中文大写金额
 * @param $amount float 金额(支持到分)
 * @param $type   int   补整类型,0:到角补整;1:到元补整
 * @return mixed 中文大写金额
 */
function cny($amount, $type = 1) {
	// 判断输出的金额是否为数字或数字字符串
	if(!is_numeric($amount)){
		return "要转换的金额只能为数字!";
	}

	// 金额为0,则直接输出"零元整"
	if($amount == 0) {
		return "零元整";
	}

	// 金额不能为负数
	if($amount < 0) {
		return "要转换的金额不能为负数!";
	}

	// 金额不能超过万亿,即12位
	if(strlen($amount) > 12) {
		return "要转换的金额不能为万亿及更高金额!";
	}

	// 预定义中文转换的数组
	$digital = array('零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖');
	// 预定义单位转换的数组
	$position = array('仟', '佰', '拾', '亿', '仟', '佰', '拾', '万', '仟', '佰', '拾', '元');
	if($type==2) //仅转大写数字
	{
		$position[11]='';
	}
	// 将金额的数值字符串拆分成数组
	$amountArr = explode('.', $amount);

	// 将整数位的数值字符串拆分成数组
	$integerArr = str_split($amountArr[0], 1);

	// 将整数部分替换成大写汉字
	$result = '';
	$integerArrLength = count($integerArr);	 // 整数位数组的长度
	$positionLength = count($position);		 // 单位数组的长度
	for($i = 0; $i < $integerArrLength; $i++) {
		// 如果数值不为0,则正常转换
		if($integerArr[$i] != 0){
			$result = $result . $digital[$integerArr[$i]] . $position[$positionLength - $integerArrLength + $i];
		}else{
			// 如果数值为0, 且单位是亿,万,元这三个的时候,则直接显示单位
			if(($positionLength - $integerArrLength + $i + 1)%4 == 0){
				$result = $result . $position[$positionLength - $integerArrLength + $i];
			}
		}
	}

	// 如果小数位也要转换
	if($type == 0) {
		// 将小数位的数值字符串拆分成数组
		$decimalArr = str_split($amountArr[1], 1);
		// 将角替换成大写汉字. 如果为0,则不替换
		if($decimalArr[0] != 0){
			$result = $result . $digital[$decimalArr[0]] . '角';
		}
		// 将分替换成大写汉字. 如果为0,则不替换
		if($decimalArr[1] != 0){
			$result = $result . $digital[$decimalArr[1]] . '分';
		}
	}else if($type==1){
		$result = $result . '整';
	}else{
		$result = str_replace('元整','',$result);
	}
	return $result;
}
/**
 * 替换系统 strtotime, Y2K38问题
 */
function _strtotime($dt = null, $modify = '')
{
    $d = null;
    if (empty($dt))
    {
        $d = new DateTime();
    }
    else if (is_numeric($dt))
    {
        $d = new DateTime('@' . $dt);
    }
    else
    {
        $d = new DateTime($dt);
    }

    $d -> setTimeZone(new DateTimeZone('PRC'));
    if ($modify != '')
    {
        $d -> modify($modify);
    }

    return $d -> format('U');
}

/**
 * 替换系统 date, Y2K38问题
 */
function _date($format = 'Y-m-d H:i:s', $dt = null)
{
    $d = new DateTime('@' . _strtotime($dt));
    $d -> setTimeZone(new DateTimeZone('PRC'));

    return $d -> format($format);
}

function thumbnail($src,$dst,$newwidth,$newheight,$percent=1)
{
	if(filesize($src)>40*1024)
	{
		$imgInfo = getimagesize($src);
		$imgType = image_type_to_extension($imgInfo[2], false);
		$fun = "imagecreatefrom{$imgType}";

		$image = $fun($src);

		$width=$imgInfo[0];
		$height=$imgInfo[1];
 		if($percent==1)
		{//指定长度和宽度，并等比缩放
 			if($width>$height){
				$height=round($newwidth/($width/$height));
				$width=$newwidth;
			}else {
				$width = round($newheight * ($width / $height));
				$height = $newheight;
			}
 		}
		else
		{//按比例缩小
			$width*=$percent;
			$height*=$percent;
		}
		//在内存中建立一张图片
		$images2 = imagecreatetruecolor($width, $height);
		if (!$images2) { $images2 = imageCreate($width, $height); }
		ImageCopyResized($images2,$image,0,0,0,0,$width,$height,$imgInfo[0],$imgInfo[1]);
		//将原图复制到新建图片中
		imagedestroy($image);

		if($dst=='')
		{//直接显示
			header("Content-type: ".$imgInfo['mime']);
			imagejpeg($images2);
		}
		else
		{//保存到新文件
			imagejpeg($images2, $dst, 92); //10代码输出图片的质量 0-100 100质量最高
		}
		//销毁
		imagedestroy($images2);
	}
	else
	{
		if(!move_uploaded_file($src, $dst))
    	exit('上传失败');
	}
}

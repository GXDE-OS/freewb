<?php
	//从csv导入基础信息
	header("Content-Type: text/html; charset=utf-8");
	session_start();
	include "../conn/conn.php";
	include "dbtool.php";
	mysqli_query($con,"set names 'utf8'");
	$mysql = "set charset utf8;\r\n";

	$action = $_GET['action'];
	if ($action == 'import')
	{ //导入CSV
		$filename = $_FILES['fileField']['tmp_name'];
		if (empty ($filename))
		{
		    echo "<script language=\"JavaScript\">alert(\"请选择要导入的CSV文件\");window.location.href='../addspxinxi.php';</script>";
		    die;
		}

		$result = getCsvData($filename);
		$len_result = count($result);

		if($len_result==0)
		{
		    echo "<script language=\"JavaScript\">alert(\"数据文件没内容，请查\");window.location.href='../addspxinxi.php';</script>";
		    exit;
		}
		//csv格式:　序号　名称
		$utf8 = is_utf8($result[0][1]);
		//从1开始跳过标题栏

		$m=0;
		$data = "序号,名称,非法字符\r\n";
		for ($i = 1; $i < $len_result; $i++)
		{ //循环获取各字段值
		    $name = $utf8?$result[$i][1]:iconv('gb2312', 'utf-8', $result[$i][1]);
		    if(strlen($name)<2 ) continue;

			if(mb_strlen($name)>12)
			{
				++$m;
				$data.=$m.','.$name;
				$data.=',类名长度超过12个字符';
				$data.="\r\n";
				continue;
			}
		    $data_values .= "('{$name}'),";
		}
		$data_values = substr($data_values,0,-1); //去掉最后一个逗号

		mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
		$k=0;
		if($data_values!='')
		try
		{
			//创建临时表
			$table = "zy_{$_SESSION['zy_depart_id']}_{$_SESSION['$_zy_station_id']}_{$_SESSION['zy_admin_id']}_spxinxi";
			$sql = "create TEMPORARY table `{$table}` (
				`name` char(64) DEFAULT '',
				`dep_id` int(11) DEFAULT {$_SESSION['zy_depart_id']},
				`st_id` int(5) DEFAULT {$_SESSION['zy_station_id']}
				) ENGINE=Memory DEFAULT CHARSET=utf8;";
			$result = mysqli_query($con,$sql);

			$sql = "insert into `{$table}`(name) values $data_values";
			$result = mysqli_query($con,$sql);

			//查找A表中，而B表中没有的记录
			$sql="insert into zy_spxinxi(name,dep_id,st_id) select distinct name,dep_id,st_id from `{$table}` where name not in (select name from zy_spxinxi where st_id={$_SESSION['zy_station_id']})";
			$result = mysqli_query($con,$sql);

			$sql = "select row_count()";
			$result = mysqli_query($con,$sql);
			$row = mysqli_fetch_array($result,MYSQLI_NUM);
			$k=$row[0];
		}
		catch(Exception $e)
		{
			logInfo($e->getMessage()."\r\n".$sql);
			die($e->getMessage());
		}
		mysqli_close($con);

		$str="成功新增{$k}条数据";
		if($m>0)
		{
			$filename = $_SESSION['zy_station_name'].$_SESSION['zy_admin_id']."_物品类别名批量添加结果.csv";
			file_put_contents('../../data/temp/'.$filename,$data);
			$str.="，{$m}条含标点符号未添加<br>详情见自动保存的结果文件。";
		}
		else
		{
			$str .= "。";
		}
		$str = base64_encode($str);
		if($m>0)
		{
			$str.='&web='.base64_encode($filename);
		}	
		echo "<script language=\"JavaScript\">window.location.href=\"../addspxinxi.php?info={$str}\";</script>";
	}

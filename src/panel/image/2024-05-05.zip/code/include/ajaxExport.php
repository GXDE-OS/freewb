<?php
	header("Content-Type: text/html; charset=utf-8");
	Header ( "Content-type: application/octet-stream" );

	//请求范围的度量单位--字节
	Header ( "Accept-Ranges: bytes" );
	//接收参数
	$method = $_GET['source'];
	if($method=='入库' && $_GET['complex']=='id')
		$name_id = isset($_GET['constr'])?$_GET['constr']:0;
	else
		$name_id = isset($_GET['name_id'])?$_GET['name_id']:0;


	$station=$_GET['name'];
	if($method=='出库'||$method=='入库'||$method=='过期')
	{
		$date1 = $_GET['date1'];
		$date2 = $_GET['date2'];
	}
	$name = "{$station}_{$method}查询结果.xls";
	Header ( "Content-Disposition: attachment; filename=" . $name );
	session_start();
	include "../conn/conn.php";
	include "const.php";
	include "dbtool.php";

	error_reporting(E_ALL | ~E_NOTICE);
	ini_set('display_errors', TRUE);
	ini_set('display_startup_errors', TRUE);
	date_default_timezone_set('PRC');
	require_once '../../Classes/PHPExcel.php';
	header("Access-Control-Allow-Origin: *"); // 允许任意域名发起的跨域请求

	$complex = $_GET['complex'];
	//设置文件属性
	$objPHPExcel = new PHPExcel();
	$objPHPExcel->getProperties()->setCreator("freeime")
			 ->setLastModifiedBy("freeime")
			 ->setTitle("freeime warehouse manage system")
			 ->setSubject("")
			 ->setDescription("Document for Office 2003 XLS, generated using PHP classes.")
			 ->setCategory("freeime warehouse manage system");

	//名称,品牌,规格型号,入库数量,单位,进货单价,相关费用,存放位置,生产日期,采购方式,采购日期,过期日期,补充信息
	//标题合并单元格设置字体
	$tail = 'I';
	if($complex=='full')
	{
		if($method=='入库')
			$tail = 'D';
		else
			$tail = 'E';
	}
	else if($method=='库存')
		$tail='O';
	else if($method=='入库')
		$tail='P';
	else if($method=='出库')
		$tail='T';
	else if($method=='统计')
		$tail='E';

	//导航栏及内容设置居中
	for($i='A';$i<=$tail;$i++)
	$objPHPExcel->getActiveSheet()->getStyle($i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	//设置单元格宽度
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(6);
	$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
	$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
	$objPHPExcel->getActiveSheet()->getColumnDimension($tail)->setWidth(15);

	if( $complex=='full'||isset($_GET['level']))
	{
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
	}
	else if($method!='库存'&&$method!='统计'&&$method!='入库')
	{
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
	}
	else if($method=='库存')
	{
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
	}
	$month = array();
	$monthNow = date('n');
	for($i=1;$i<$monthNow;$i++)
		$month[$i] = "{$i}月底";
	$yearNow=date('Y')-1;
	for(;$i<=12;$i++)
		$month[$i] = "{$yearNow}年{$i}月底";

	//导航栏加粗
	$objPHPExcel->getActiveSheet()->getStyle("A1:{$tail}1")->getFont()->setBold(true);
	// 设置行高
	$k = ord($tail)-ord('A');
	$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);

	//设置标题栏
	//名称,品牌,规格型号,入库数量,单位,进货单价,相关费用,存放位置,生产日期,采购方式,采购日期,过期日期,补充信息
	if($complex=='full'||(isset($_GET['level'])&&$_GET['level']==0))
	{
		if($method=='入库')
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1','入库单号')
			->setCellValue('B1','入库人')
			->setCellValue('C1','入库日期')
			->setCellValue('D1','备注');
		else
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1','出库单号')
			->setCellValue('B1','出库用途')
			->setCellValue('C1','经手人')
			->setCellValue('D1','数量')
			->setCellValue('E1','金额')
			->setCellValue('F1','出库日期')
			->setCellValue('G1','备注');
	}
	else if($method=='入库')
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','名称')
		->setCellValue('B1','品牌')
		->setCellValue('C1','规格型号')
		->setCellValue('D1','入库数量')
		->setCellValue('E1','单位')
		->setCellValue('F1','进货单价')
		->setCellValue('G1','相关费用')
		->setCellValue('H1','存放位置')
		->setCellValue('I1','生产日期')
		->setCellValue('J1','采购方式')
		->setCellValue('K1','采购日期')
		->setCellValue('L1','过期日期')
		->setCellValue('M1','补充信息')
		->setCellValue('N1','币种单价')
		->setCellValue('O1','支付币种')
		->setCellValue('P1','币种比价');
	else if($method=='出库')
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','序号')
		->setCellValue('B1','物品名称')
		->setCellValue('C1','品牌')
		->setCellValue('D1','型号')
		->setCellValue('E1','数量')
		->setCellValue('F1','单位')
		->setCellValue('G1','进货单价')
		->setCellValue('H1','相关费用')
		->setCellValue('I1','存放位置')
		->setCellValue('J1','生产日期')
		->setCellValue('K1','采购方式')
		->setCellValue('L1','采购日期')
		->setCellValue('M1','过期日期')
		->setCellValue('N1','补充信息')
		->setCellValue('O1','币种单价')
		->setCellValue('P1','支付币种')
		->setCellValue('Q1','币种比价')
		->setCellValue('R1','经手人')
		->setCellValue('S1','用途')
		->setCellValue('T1','出库日期');
	else if($method=='过期')
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','序号')
		->setCellValue('B1','物品名称')
		->setCellValue('C1','数量')
		->setCellValue('D1','单位')
		->setCellValue('E1','规格')
		->setCellValue('F1','单价')
		->setCellValue('G1','总价')
		->setCellValue('H1','入库日期')
		->setCellValue('I1','过期日期');
	else if($method=='统计')
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','序号')
		->setCellValue('B1','物品名称')
		->setCellValue('C1','出库次数')
		->setCellValue('D1','出库数量')
		->setCellValue('E1','库存量');
	else//库存
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','序号')
		->setCellValue('B1','物品名称')
		->setCellValue('C1','目前库存')
		->setCellValue('D1',$month[1])
		->setCellValue('E1',$month[2])
		->setCellValue('F1',$month[3])
		->setCellValue('G1',$month[4])
		->setCellValue('H1',$month[5])
		->setCellValue('I1',$month[6])
		->setCellValue('J1',$month[7])
		->setCellValue('K1',$month[8])
		->setCellValue('L1',$month[9])
		->setCellValue('M1',$month[10])
		->setCellValue('N1',$month[11])
		->setCellValue('O1',$month[12]);
	$s=2;
	$k=2;
	$i=1;
	$dep_id=$_SESSION['zy_depart_id'];
	$st_id=$_GET['warehouse'];
	if( $method=='出库')
	{
		if($complex!='' && $name_id==0 && $complex!='audit')
		{
			$constr = trim($_GET['constr']);
			if($complex=='full')
			{
				$constr = '1';
			}
			else if($complex=='billno')
			{
				$constr = "c.`{$complex}`='{$constr}'";
			}
			else if(strtolower($complex)=='buyer')
			{
				$constr = (isset($_GET['level'])&&$_GET['level']==0)?"c.claimant='{$constr}'":"c.`{$complex}`='{$constr}'";
			}
			else if($complex=='chart')
			{
				$constr=' 1=1 ';
			}
			else if($complex=='outdate')
			{
				$constr = (isset($_GET['level'])&&$_GET['level']==0)?"left(applyTime,10)='{$constr}'":"c.`date`='{$constr}'";
			}
			else if( $complex=='purpose')
			{
				$constr = "c.`{$complex}`='{$constr}'";
			}
			else
			{
				$constr = "c.`{$complex}`={$constr}";
			}

			$date_range='';
			if(isset($_GET['date_start']) && $_GET['date_start']!='')
			{//export list
				$date_start=$_GET['date_start'];
				$date_end = $_GET['date_end'];
				$date_range = (isset($_GET['level'])&&$_GET['level']==0)?" and left(applyTime,10)>='{$date_start}' and left(applyTime,10)<='{$date_end}'":" and c.date>='{$date_start}' and c.date<='{$date_end}'";
			}
			$constr.=$date_range;
			if( $constr=='1' || (isset($_GET['level'])&&$_GET['level']==0))
			{
				$sql = "select billno,claimant,left(applyTime,10) as permit_date,purpose,memo,sum_total,money_total from permittask c where st_id={$st_id} and method='出库' and permited=".FLOW_TASK_OVER." and {$constr} order by billno desc limit 1024";
			}
			else
			{
				$sql="select r.jiage,r.jiage2,r.madeDate,r.box,r.orderDate,r.date2,r.source,r.memo,r.jiage_other,r.curency,r.rate,c.shuliang as shuliang,c.purpose as purpose,c.date as date,c.Buyer as Buyer,x.name as name,r.brand as brand,r.model as model,r.unit as unit from (zy_spchuku c inner join zy_spxinxi x on c.sp_id=x.id) inner join zy_spruku r on r.id=c.ruku_id  where c.st_id={$st_id} and r.st_id={$st_id} and x.st_id={$st_id} and {$constr}  order by c.`date` desc";
			}
		}
		else
		{
			$constr = ($name_id==0)?' ':"c.sp_id = {$name_id} and ";
			$sql="select c.shuliang as shuliang,c.purpose as purpose,c.date as date,c.Buyer as Buyer,x.name as name,r.brand as brand,r.model as model,r.unit as unit from (zy_spchuku c inner join zy_spxinxi x on c.sp_id=x.id) inner join zy_spruku r on r.id=c.ruku_id  where c.st_id={$st_id} and r.st_id={$st_id} and x.st_id={$st_id} and {$constr} c.`date`>='{$date1}' and c.`date`<='{$date2}' order by c.`date` desc";

		}
	}
	else if( $method=='入库')
	{
		if($complex!='' && $name_id==0 && $complex!='audit')
		{
			$constr = trim($_GET['constr']);
			if($complex=='full')
			{
				$constr = '1';
			}
			else if($complex=='Buyer' || $complex=='date')
			{
				$constr = "r.`{$complex}`='{$constr}'";
			}
			else
			{
				$constr = "r.`{$complex}`={$constr}";
			}

			if($constr=='1')
			{
				$sql = "select billno,claimant,applyTime from permittask where st_id={$st_id} and permited=".FLOW_TASK_OVER." and method='入库' order by billno desc limit 30";
			}
			else
			{
				$sql="select * from zy_spruku r inner join zy_spxinxi x on r.sp_id=x.id where r.st_id={$st_id} and x.st_id={$st_id} and {$constr}  order by r.`date` desc";
			}
		}
		else
		{
			$constr = ($name_id==0)?'':" r.sp_id = {$name_id} ";
			$sql="select * from zy_spruku r inner join zy_spxinxi x on r.sp_id=x.id where r.st_id={$st_id} and x.st_id={$st_id} ";
			if($constr!='')
				$sql .="and {$constr} ";
			if($date1!='')
			{
				$sql.="and r.`date`>='{$date1}' and r.`date`<='{$date2}' ";
			}
			$sql.="order by r.`date` desc";
		}
	}
	else if( $method=='过期')
	{
		$constr = ($name_id==0)?' ':"r.sp_id = {$name_id} and ";
		$sql = "select x.name as name,r.brand as brand,r.shuliang as shuliang,r.unit as unit,r.model as model,r.jiage as jiage,r.date as date1,r.date2 as date2 from zy_spruku r inner join zy_spxinxi x on r.sp_id=x.id where r.st_id={$st_id} and x.st_id={$st_id} and {$constr} date(date2)>='{$date1}' and date(date2)<='{$date2}' and shuliang>0  order by date2";
	}
	else if( $method=='统计')
	{
		$ms = $_GET['range'];
		$nodate = date("Y-m-d");
		$exdate = date("Y-m-d",strtotime("-{$ms} month"));

		$sql = "select a.name AS name,count(*) as times,sum(b.shuliang) as num,c.kucun as kucun FROM zy_spkucun c,`zy_spchuku` b inner join zy_spxinxi a where c.st_id={$st_id} and b.st_id={$st_id} and a.st_id={$st_id} and a.id=b.sp_id and a.id=c.sp_id and b.date>'{$exdate}' and b.date<='{$nodate}' group by c.sp_id order by num desc";
	}
	else
	{//库存
		$constr = ($name_id==0)?' ':" r.sp_id = {$name_id} and ";
		$sql="select * from zy_spkucun r inner join zy_spxinxi x on r.sp_id=x.id where {$constr} r.st_id={$st_id} and x.st_id={$st_id} order by x.id";
	}
//echo $sql;
	mysqli_query($con,"start transaction");
	try
	{
		$result = mysqli_query($con,$sql);
	}
	catch(Exception $e)
	{
		logInfo($e->getMessage()."\r\n".$sql);
	}
	if($complex=='full'||(isset($_GET['level'])&&$_GET['level']==0))
	{
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			if($method=='入库')
			{
				$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$k,$row['billno'])
				->setCellValue('B'.$k,$row['claimant'])
				->setCellValue('C'.$k,substr($row['applyTime'],0,10))
				->setCellValue('D'.$k,'');
			}
			else if($method=='出库')
			{
				$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$k,$row['billno'])
				->setCellValue('B'.$k,$row['purpose'])
				->setCellValue('C'.$k,$row['claimant'])
				->setCellValue('D'.$k,substr($row['sum_total'],0,10))
				->setCellValue('E'.$k,substr($row['money_total'],0,10))
				->setCellValue('F'.$k,$row['permit_date'])
				->setCellValue('G'.$k,'');

			}
			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
	}
	else
	if( $method=='入库' )
	{
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			//名称,品牌,规格型号,入库数量,单位,进货单价,相关费用,存放位置,生产日期,采购方式,采购日期,过期日期,补充信息,外币单价,外币币种，外币比价
			$num = intval($row['shuliang2']);
			if($num!=$row['shuliang2']) $num=$row['shuliang2'];
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A'.$k,$row['name'])
			->setCellValue('B'.$k,$row['brand'])
			->setCellValue('C'.$k,$row['model'])
			->setCellValue('D'.$k,$num)
			->setCellValue('E'.$k,$row['unit'])
			->setCellValue('F'.$k,$row['jiage'])
			->setCellValue('G'.$k,$row['jiage2'])
			->setCellValue('H'.$k,$row['box'])
			->setCellValue('I'.$k,$row['madeDate'])
			->setCellValue('J'.$k,$row['source'])
			->setCellValue('K'.$k,$row['orderDate'])
			->setCellValue('L'.$k,$row['date2'])
			->setCellValue('M'.$k,$row['memo'])
			->setCellValue('N'.$k,$row['jiage_other'])
			->setCellValue('O'.$k,$row['curency'])
			->setCellValue('P'.$k,$row['rate']);

			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
		//$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$k,$sql);
	}
	else if( $method=='出库' )
	{
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			$num = intval($row['shuliang']);
			if($num!=$row['shuliang']) $num=$row['shuliang'];
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A'.$k,$i)
			->setCellValue('B'.$k,$row['name'])
			->setCellValue('C'.$k,$row['brand'])
			->setCellValue('D'.$k,$row['model'])
			->setCellValue('E'.$k,$num)
			->setCellValue('F'.$k,$row['unit'])
			->setCellValue('G'.$k,$row['jiage'])
			->setCellValue('H'.$k,$row['jiage2'])
			->setCellValue('I'.$k,$row['box'])
			->setCellValue('J'.$k,$row['madeDate'])
			->setCellValue('K'.$k,$row['source'])
			->setCellValue('L'.$k,$row['orderDate'])
			->setCellValue('M'.$k,$row['date2'])
			->setCellValue('N'.$k,$row['memo'])
			->setCellValue('O'.$k,$row['jiage_other'])
			->setCellValue('P'.$k,$row['curency'])
			->setCellValue('Q'.$k,$row['rate'])
			->setCellValue('R'.$k,$row['Buyer'])
			->setCellValue('S'.$k,$row['purpose'])
			->setCellValue('T'.$k,$row['date']);
			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
	}
	else if( $method=='过期' )
	{
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			$num = intval($row['shuliang']);
			if($num!=$row['shuliang']) $num=$row['shuliang'];
			$money = $row['shuliang']*$row['jiage'];
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A'.$k,$i)
			->setCellValue('B'.$k,$row['name'])
			->setCellValue('C'.$k,$num)
			->setCellValue('D'.$k,$row['unit'])
			->setCellValue('E'.$k,$row['model'])
			->setCellValue('F'.$k,$row['jiage'])
			->setCellValue('G'.$k,$money)
			->setCellValue('H'.$k,$row['date1'])
			->setCellValue('I'.$k,$row['date2']);
			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
	}
	else if( $method=='统计' )
	{
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			$num=intval($row['num']);
			if($num!=$row['num']) $num=$row['num'];
			$kucun=intval($row['kucun']);
			if($kucun!=$row['kucun']) $kucun=$row['kucun'];

			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A'.$k,$i)
			->setCellValue('B'.$k,$row['name'])
			->setCellValue('C'.$k,$row['times'])
			->setCellValue('D'.$k,$num)
			->setCellValue('E'.$k,$kucun);
			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
	}
	else
	{//库存
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
		{
			$kucun=array();
			for($d=1;$d<13;$d++)
			{
				$kucun[$d] = intval($row['kucun'.$d]);
				if($kucun[$d]!=$row['kucun'.$d]) $kucun=$row['kucun'.$d];
			}
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A'.$k,$i)
			->setCellValue('B'.$k,$row['name'])
			->setCellValue('C'.$k,$row['kucun'])
			->setCellValue('D'.$k,$kucun[1])
			->setCellValue('E'.$k,$kucun[2])
			->setCellValue('F'.$k,$kucun[3])
			->setCellValue('G'.$k,$kucun[4])
			->setCellValue('H'.$k,$kucun[5])
			->setCellValue('I'.$k,$kucun[6])
			->setCellValue('J'.$k,$kucun[7])
			->setCellValue('K'.$k,$kucun[8])
			->setCellValue('L'.$k,$kucun[9])
			->setCellValue('M'.$k,$kucun[10])
			->setCellValue('N'.$k,$kucun[11])
			->setCellValue('O'.$k,$kucun[12]);
			$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(20);
			++$k;
			++$i;
		}
	}
	mysqli_query($con,"commit");
	if($result) mysqli_free_result($result);
	mysqli_close($con);
	  //生成xls文件

	// Set active sheet index to the first sheet, so Excel opens this as the first sheet
	$objPHPExcel->setActiveSheetIndex(0);
	$file_name = "../../data/temp/".$_SESSION['zy_depart_name'].$station.'_'.$method.'_查询结果'.$_SESSION['zy_admin_id'].'.xls';
	if( $_SESSION['winOs']==1 )
		$file_name= iconv("UTF-8", "GB2312//IGNORE",$file_name);
	// Save Excel 95 file
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
	$objWriter->save($file_name);

	//以只读和二进制模式打开文件
	$file = fopen ( $file_name, "rb" );
	//这是一个文件流格式的文件
	//ob_end_clean();//清除缓冲区,避免乱码
	//读取文件内容并直接输出到浏览器
	echo fread ( $file, filesize ( $file_name ) );
	fclose ( $file );
?>

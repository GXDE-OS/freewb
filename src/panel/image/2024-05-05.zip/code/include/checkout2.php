<?php
	//电子或纸页已批，分配出库单号，并执行电子出库
	header("Content-Type: text/html; charset=utf-8; ");
	session_start();
	$root = $_SERVER['DOCUMENT_ROOT'];
	if ($_SESSION['zy_admin_id'] == NULL) {
		echo "<script language=\"JavaScript\">window.location.href='/index.php';</script>";
	}

	include "../conn/conn.php";
	include "dbtool.php";
	include "const.php";

	function InsertName($con,$name,$to_st_id)
	{
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
		try
		{
			$sql="select id from zy_spxinxi where st_id={$to_st_id} and name=\"{$name}\" lock in share mode";
			$res = mysqli_query($con,$sql);
			if(mysqli_num_rows($res)==0)
			{
				mysqli_free_result($res);
				$sql="insert into zy_spxinxi(name,st_id,dep_id) values('{$name}',{$to_st_id},{$_SESSION['zy_depart_id']})";
				$res=mysqli_query($con,$sql);
				if(!$res)
					throw new Exception(mysqli_error($con));
			}
		}
		catch(Exception $e)
		{
			mysqli_query($con,"rollback");
			mysqli_close($con);
			$str = 'InsertName:'.$e->getMessage() . "\r\n{$sql}";
			logInfo($str);
			echo($str);
			exit;
		}
	}

	function InsertRuku($con,$from_task_id,$from_st_id,$to_st_id,$sum_total,$money_total)
	{
		$billnoYear = getOptionDepart('BillNoYear',$con,$_SESSION['zy_depart_id'],$to_st_id);
		if($billnoYear=='')
		{
			$applyNo = getOption('applyNo',$con,$_SESSION['zy_depart_id'],$to_st_id);
			if($applyNo!=''&&$applyNo>1)
				$billnoYear=date('Y')-1;
			else
				$billnoYear=date('Y');
			updateOptionDepart('BillNoYear',"{$billnoYear}",$con,$_SESSION['zy_depart_id']);
		}
		//自动入库，取新号
		$task_id = getUpdateOption('applyNoImport',$con,$_SESSION['zy_depart_id'],$to_st_id);
		//会检测是否跨年并更新BillNoYear,所以要再读一次
		$billnoYear = getOptionDepart('BillNoYear',$con,$_SESSION['zy_depart_id'],$to_st_id);

		$claimant = '系统移库';
		$claimant_id = 99999;
		$pt_id = $claimant_id.$to_st_id.$_SESSION['zy_depart_id'].$billnoYear.$task_id;

		$importDate = date('Y-m-d  H:i:s');
		$vet="系统自动审核 [系统] (000) ";
		$vet.= $importDate;

		$billno = getUpdateOption('LastInBillNo',$con,$_SESSION['zy_depart_id'],$to_st_id);
		$str = sprintf('%05d',$billno);
		$str = $billnoYear.$str;
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
		try
		{
			$sql="select name from portal.stations where id={$from_st_id} limit 1";
			$result = mysqli_query($con,$sql);
			$row = mysqli_fetch_object($result);
			$st_name = $row->name;
			if($result) mysqli_free_result($result);

			$sql="insert into permittask(id,task_id,st_id,to_st_id,dep_id,claimant,claimantId,permited,applyTime,purpose,method,guest_vet,user_vet,audit_vet,admin_vet,memo,billno,sum_total,money_total)  values('{$pt_id}',{$task_id},{$to_st_id},{$from_st_id},{$_SESSION['zy_depart_id']},'{$claimant}','{$claimant_id}',".FLOW_TASK_OVER.",'{$importDate}','他库移入','入库','发起：{$vet}','库管：{$vet}','会计：{$vet}','主管：{$vet}','移自{$st_name}','{$str}',{$sum_total},{$money_total})";
			$result = mysqli_query($con,$sql);

			//将要移库的出库数据导入到waitimport表中
			$sql="select r.*,w.amount,x.id as new_sp_id from (zy_spruku r inner join waithandlelist w on r.id=w.ruku_id) inner join zy_spxinxi x on x.name=w.sp_name where w.st_id={$from_st_id} and w.task_id={$from_task_id} and x.st_id={$to_st_id} order by id lock in share mode";

			$result = mysqli_query($con,$sql);
			$fields="task_id,sp_id,shuliang,shuliang2,`date`,orderDate,brand,model,unit,date2,box,source,madeDate,dep_id,st_id,jiage,jiage2,amount,operator,keeper,billno,orderbill,memo,curency,rate";
			while($row=mysqli_fetch_object($result))
			{
				$orderBill = $row->orderBill==''?' ':$row->orderbill;
				$memo = $row->memo ==''?' ':$row->memo;
				$sql="insert into waitimport({$fields}) values({$task_id},{$row->new_sp_id},{$row->amount},{$row->amount},'{$row->date}','{$row->orderDate}','{$row->brand}','{$row->model}','{$row->unit}','{$row->date2}','{$row->box}','移自[{$st_name}]','{$row->madeDate}',{$_SESSION['zy_depart_id']},{$to_st_id},{$row->jiage},{$row->jiage2},0,'','',0,'{$orderBill}','{$memo}','人民币',1)";
				$res=mysqli_query($con,$sql);
			}
			//数据入库
			Import($str,$con,$_SESSION['zy_depart_id'],$to_st_id,$pt_id,$task_id);
		}
		catch(Exception $e)
		{
			mysqli_query($con,"rollback");
			mysqli_close($con);
			$str = 'InsertRuku: '.$e->getMessage() . "\r\n{$sql}";
			logInfo($str);
			echo($str);
			exit;
		}
	}

	$id = $_POST['id'];
	$task_id = $_POST['task_id'];
	$claimant = $_POST['claimant'];
	$dep_id = $_POST['dep_id'];
	$st_id = $_POST['st_id'];
	$purpose = $_POST['purpose'];
	$to_st_id=0;

	$i=strpos($purpose,'物品移库');
	if($i===false)
		$move_it=0;
	else
		$move_it=1;

	//get and update checkout bill no
	$BillNo = getUpdateOption('LastBillNo',$con,$dep_id,$st_id);
	$billnoYear = getOptionDepart('BillNoYear',$con);
	if($billnoYear=='')
	{
		$billnoYear=date('Y');
		updateOptionDepart('BillNoYear',"{$billnoYear}",$con);

	}
	$BillNo = sprintf('%05d',$BillNo);
	$str = $billnoYear.$BillNo;
	date_default_timezone_set("PRC");
	mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
	try
	{
		if($move_it)
		{
			$sql="select to_st_id,sum_total,money_total from permittask where id='{$id}' limit 1 lock in share mode;";
			$result = mysqli_query($con,$sql);
			$row=mysqli_fetch_object($result);
			$to_st_id=$row->to_st_id;
			$sum_total = $row->sum_total;
			$money_total = $row->money_total;
			if($result)	mysqli_free_result($result);
		}

		$today = date("Y-m-d");
		$sql="select * from waithandlelist where st_id={$st_id} and task_id={$task_id} order by id lock in share mode";
		$result = mysqli_query($con,$sql);
		$ItemNum = mysqli_num_rows($result);

		mysqli_query($con,"start transaction");
		for($i=0;$i<$ItemNum;$i++)
		{//更新出库记录
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			if($move_it) InsertName($con,$row['sp_name'],$to_st_id);
			$sql = "insert into zy_spchuku(id,sp_id,ruku_id,shuliang,`date`,Buyer,BillNo,purpose,memo,jiage,dep_id,st_id) values(0,{$row['sp_id']},{$row['ruku_id']},{$row['amount']},'{$today}','{$claimant}','{$str}','{$purpose}',\"{$row['memo']}\",0,{$dep_id},{$st_id})";
			$res = mysqli_query($con,$sql);
			if(!$res) throw new Exception(mysqli_error($con));
		}
		if($result) mysqli_free_result($result);

		//入到新库中
		if($move_it) InsertRuku($con,$task_id,$st_id,$to_st_id,$sum_total,$money_total);

		//更新permitTask中相关申请单状态为已出库
		//库管：同意，送会计核 [孟庆曦] (811) 2022-11-11 05:02:54
		$extra = '';
		if($move_it)
			$info ="系统：库管书面出库 [系统移库] (000) ".date('Y-m-d H:i:s');
		else
			$info ="系统：库管书面出库 [系统] (000) ".date('Y-m-d H:i:s');

		if($_POST['permit']==FLOW_WAIT_AUDIT_PERMIT)
		{
			$extra=" audit_vet='{$info}', admin_vet='{$info}',";
		}
		else if($_POST['permit']==FLOW_WAIT_ADMIN_PERMIT)
		{
			$extra=" admin_vet='{$info}',";
		}

		$today=date('Y-m-d H:i:s');
		$sql="update permittask set {$extra} billno='{$str}',applyTime='{$today}',permited=".FLOW_TASK_OVER." where id='{$id}';";
		$result = mysqli_query($con,$sql);
		if(!$result) throw new Exception(mysqli_error($con));


		//删除waitpermittask中记录
		$sql="delete from waitpermittask where pt_id='{$id}';";
		$result = mysqli_query($con,$sql);
		if(!$result) throw new Exception(mysqli_error($con));


		//删除waithandlelist中记录
		$sql="delete from waithandlelist where st_id={$st_id} and task_id={$task_id} ;";
		$result = mysqli_query($con,$sql);
		if(!$result) throw new Exception(mysqli_error($con));

		mysqli_query($con,"commit");

		$sql = "select name from portal.stations where id={$to_st_id}";
		$result = mysqli_query($con,$sql);
		$row = mysqli_fetch_object($result);
		$to_st_name = $row->name;
		if($result) mysqli_free_result($result);
		mysqli_close($con);
	}
	catch(Exception $e)
	{
			mysqli_query($con,"rollback");
			mysqli_close($con);
			$str = $e->getMessage() . "\r\n{$sql}";
			logInfo($str);
			echo($str);
			exit;
	}

	$info=",";
	if($move_it)
		$info = "并移至[{$to_st_name}]<br><br>";

	if( $_POST['print']==1)
	{
		echo "{\"url\":\"pt_id={$id}&task_id={$task_id}&purpose={$purpose}&dep_id={$dep_id}&st_id={$st_id}&method=出库\",";
		echo "\"info\":\"　物品完成电子出库{$info}单号:<font color=red>".(int)$BillNo."</font>，打印流转审批单么？\"}";
	}
	else
	{
		echo "{\"info\":\"　物品完成电子出库{$info}单号:<font color=red>".(int)$BillNo."</font>，请在审批单上填写\",\"url\":\"\"}";
	}
?>

